<?php

namespace App\Services;

use DomainException;
use Illuminate\Support\Facades\DB;

/** A branch-scoped, monotonic projection. Never rewrites source events. */
final class VahdatTracking
{
    private const ORDER = ['issued' => 0, 'in_transit' => 1, 'received' => 2, 'delivered' => 3];

    private static function validId(mixed $value): string
    {
        if (!is_string($value) || strlen($value) > 90 || !preg_match('/^VH-[A-Za-z0-9_-]{4,87}$/', $value)) {
            throw new DomainException('Invalid waybill identifier');
        }
        return $value;
    }

    private static function timestamp(mixed $value): ?int
    {
        if ($value === null) return null;
        if (!is_numeric($value) || (int)$value < 1000000000000 || (int)$value > 9999999999999) {
            throw new DomainException('Invalid operation timestamp');
        }
        return (int)$value;
    }

    private static function track(string $id, string $origin, string $destination,
                                  string $status, bool $verified, array $values): void
    {
        $record = DB::table('vahdat_sync_waybill_tracking')->where('waybill_id', $id)->lockForUpdate()->first();
        $update = array_merge($values, ['updated_at' => now()]);
        if (!$record) {
            DB::table('vahdat_sync_waybill_tracking')->insert(array_merge([
                'waybill_id' => $id,
                'origin_branch_id' => $origin,
                'destination_branch_id' => $destination,
                'status' => $status,
                'verified_origin' => $verified,
                'created_at' => now(),
            ], $update));
            return;
        }
        if ($record->origin_branch_id !== $origin || $record->destination_branch_id !== $destination) {
            throw new DomainException('Inconsistent waybill branch identity');
        }
        // Do not let a delayed issuance overwrite a previously accepted receipt/delivery.
        if (self::ORDER[$status] > self::ORDER[$record->status]) $update['status'] = $status;
        if ($verified) $update['verified_origin'] = true;
        // Delayed messages must not clear existing tracking information.
        foreach ($update as $key => $value) {
            if ($value === null) unset($update[$key]);
        }
        DB::table('vahdat_sync_waybill_tracking')->where('waybill_id', $id)->update($update);
    }

    public static function apply(string $kind, array $payload, object $source, object $target): void
    {
        $origin = $source->id;
        $destination = $target->id;
        if ($kind === 'waybill_issued') {
            $bill = $payload['waybill'] ?? [];
            $id = self::validId($bill['id'] ?? null);
            self::track($id, $origin, $destination, 'issued', true,
                ['issued_at' => self::timestamp($bill['created_at'] ?? null)]);
        } elseif ($kind === 'manifest_created') {
            $manifest = $payload['manifest'] ?? [];
            $bills = $payload['waybills'] ?? [];
            $driver = $payload['driver'] ?? [];
            $driverName = trim((string)($driver['first_name'] ?? '') . ' ' . (string)($driver['last_name'] ?? ''));
            if (mb_strlen($driverName) > 180) throw new DomainException('Driver name too long');
            foreach ($bills as $bill) {
                $id = self::validId($bill['id'] ?? null);
                self::track($id, $origin, $destination, 'in_transit', true, [
                    'issued_at' => self::timestamp($bill['created_at'] ?? null),
                    'handover_at' => self::timestamp($manifest['created_at'] ?? null),
                    'manifest_id' => mb_substr((string)($manifest['id'] ?? ''), 0, 90),
                    'driver_name' => $driverName,
                ]);
            }
        } elseif ($kind === 'waybill_received' || $kind === 'waybill_delivered') {
            // Source is destination branch, target is original branch for return messages.
            $id = self::validId($payload['waybill_id'] ?? null);
            $at = $kind === 'waybill_received' ? 'received_at' : 'delivered_at';
            self::track($id, $target->id, $source->id,
                $kind === 'waybill_received' ? 'received' : 'delivered', false,
                [$at => self::timestamp($payload[$at] ?? null)]);
        }
    }
}
