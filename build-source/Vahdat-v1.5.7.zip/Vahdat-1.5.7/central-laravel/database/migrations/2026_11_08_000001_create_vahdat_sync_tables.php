<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // Separate tables: no changes to Autobenz ticket-sales schema.
        Schema::create('vahdat_sync_branches', function (Blueprint $table) {
            $table->string('id', 48)->primary();
            $table->string('name', 180)->unique();
            $table->char('token_sha256', 64);
            $table->boolean('enabled')->default(true);
            $table->timestamps();
        });
        Schema::create('vahdat_sync_events', function (Blueprint $table) {
            $table->bigIncrements('sequence');
            $table->string('event_id', 80)->unique();
            $table->string('source_branch', 48);
            $table->string('target', 180);
            $table->string('kind', 60);
            $table->json('payload');
            $table->char('payload_sha256', 64);
            $table->unsignedBigInteger('happened_at');
            $table->timestamp('created_at')->useCurrent();
            $table->index(['target', 'sequence']);
            $table->index(['source_branch', 'sequence']);
        });
    }
    public function down(): void
    {
        Schema::dropIfExists('vahdat_sync_events');
        Schema::dropIfExists('vahdat_sync_branches');
    }
};
