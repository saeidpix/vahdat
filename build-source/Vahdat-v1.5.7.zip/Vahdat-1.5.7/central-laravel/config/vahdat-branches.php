<?php
// Fail closed: only explicitly listed authenticated Laravel user IDs can administer branches.
return [
    'admin_user_ids' => array_values(array_filter(array_map(
        'trim', explode(',', (string) env('VAHDAT_BRANCH_ADMIN_USER_IDS', ''))
    ), fn($x) => $x !== '')),
];
