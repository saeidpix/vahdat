# -*- coding: utf-8 -*-
"""Five-office star network integration tests. Pure stdlib, localhost only."""
import json
import pathlib
import sqlite3
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer

import sync_engine as se
from test_sync import ManagedConnection, SCHEMA
from test_branches_155 import central_demo

ROOT = pathlib.Path(__file__).resolve().parents[1]
PLAN = json.loads((ROOT/'central-laravel/config/vahdat-five-branch-plan.json').read_text(encoding='utf-8'))
BRANCHES = {b['id']: b['name'] for b in PLAN['branches']}
ROUTES = {}
for pair in PLAN['routes']:
    ROUTES.setdefault(pair['origin'], []).append(pair['destination'])
TOKENS = {id: (name, f'DEMO-ONLY-LOCALHOST-KEY-{id}-1234567890123456789')
          for id, name in BRANCHES.items()}


class FiveBranchNetworkTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory(); self.addCleanup(temp.cleanup)
        self.root = pathlib.Path(temp.name)
        self.hub_db = str(self.root/'demo-hub.sqlite3')
        central_demo.init_db(self.hub_db)
        self.hub = ThreadingHTTPServer(('127.0.0.1', 0),
                                       central_demo.handler_for(self.hub_db, TOKENS, ROUTES))
        threading.Thread(target=self.hub.serve_forever, daemon=True).start()
        self.addCleanup(self.hub.server_close); self.addCleanup(self.hub.shutdown)
        self.branches = {id: self.make_branch(id) for id in BRANCHES}
        self.issue_seq = 0

    def make_branch(self, id):
        p = self.root/id; p.mkdir()
        db = str(p/'data.sqlite3')
        with sqlite3.connect(db) as c:
            c.executescript(SCHEMA)
            se.migrate(c)
        config = dict(enabled=True, branch_id=id, branch_name=BRANCHES[id],
                      hub_url=f'http://127.0.0.1:{self.hub.server_port}', token=TOKENS[id][1])
        (p/'sync-config.json').write_text(json.dumps(config, ensure_ascii=False), encoding='utf-8')
        def connect():
            c = sqlite3.connect(db, timeout=3, factory=ManagedConnection)
            c.row_factory = sqlite3.Row
            return c
        return connect,p

    def sync(self, id):
        return se.sync_once(*self.branches[id])

    def add_bill(self, origin, target):
        self.issue_seq += 1
        ident = f'VH-1762600000000-{self.issue_seq:06d}'
        with self.branches[origin][0]() as c:
            num = c.execute('SELECT COUNT(*) FROM waybills').fetchone()[0] + 1
            c.execute('''INSERT INTO waybills(id, origin, destination, sender, receiver, phone,
                pieces, prepaid, post_fare, storage_fee, other_fee, total, created_at, number)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)''', (ident, BRANCHES[origin], BRANCHES[target],
                'فرستنده', 'گیرنده', '09120000000', 1, 100000, 0, 0, 0, 100000,
                1762600000000 + self.issue_seq, num))
            se.queue_waybill(c, ident)
        return ident

    def test_plan_is_exact_star_5_branches_8_routes(self):
        self.assertEqual(len(BRANCHES), 5)
        self.assertEqual(len(PLAN['routes']), 8)
        self.assertEqual(set(BRANCHES), {'tehran', 'amol', 'babol', 'qaemshahr', 'sari'})
        self.assertEqual(set(ROUTES['tehran']), {'amol', 'babol', 'qaemshahr', 'sari'})
        for id in BRANCHES:
            if id != 'tehran': self.assertEqual(ROUTES[id], ['tehran'])

    def test_five_catalogs_limit_destinations_correctly(self):
        for id in BRANCHES:
            self.assertTrue(self.sync(id)['ok'])
            with self.branches[id][0]() as c:
                got = set(se.permitted_destinations(c, se.load_config(self.branches[id][1])))
                expect = {BRANCHES[i] for i in ROUTES[id]}
                self.assertEqual(got, expect)

    def test_all_eight_routes_deliver_only_to_correct_office(self):
        for origin, targets in ROUTES.items():
            for dest in targets:self.add_bill(origin, dest)
        for id in BRANCHES:self.assertTrue(self.sync(id)['ok'], id)
        # Re-pull after all sends so early polling cannot miss later messages.
        for id in BRANCHES:self.assertTrue(self.sync(id)['ok'], id)
        with sqlite3.connect(self.hub_db) as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM hub_events').fetchone()[0], 8)
        for id in BRANCHES:
            with self.branches[id][0]() as c:
                incoming = c.execute('SELECT origin FROM waybills WHERE origin_here=0').fetchall()
                self.assertEqual(len(incoming), 4 if id == 'tehran' else 1)
                self.assertTrue(all(row['origin'] == 'تهران' for row in incoming) if id != 'tehran'
                                else all(row['origin'] in set(BRANCHES.values())-{'تهران'} for row in incoming))

    def test_no_city_to_city_leak_and_outbox_survives_rejection(self):
        for id in BRANCHES: self.assertTrue(self.sync(id)['ok'])
        self.add_bill('amol', 'babol')
        result = self.sync('amol')
        self.assertFalse(result['ok'])
        with self.branches['amol'][0]() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM sync_outbox WHERE sent_at IS NULL').fetchone()[0], 1)
        self.assertTrue(self.sync('babol')['ok'])
        with self.branches['babol'][0]() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM waybills WHERE origin_here=0').fetchone()[0], 0)

    def test_receipt_returns_to_tehran(self):
        bill = self.add_bill('tehran', 'qaemshahr')
        self.assertTrue(self.sync('tehran')['ok'])
        self.assertTrue(self.sync('qaemshahr')['ok'])
        with self.branches['qaemshahr'][0]() as c:
            c.execute('UPDATE waybills SET received_at=? WHERE id=?', (1762600007890, bill))
            row = c.execute('SELECT * FROM waybills WHERE id=?', (bill,)).fetchone()
            se.queue_received(c, row, row['received_at'])
        self.assertTrue(self.sync('qaemshahr')['ok'])
        self.assertTrue(self.sync('tehran')['ok'])
        with self.branches['tehran'][0]() as c:
            self.assertEqual(c.execute('SELECT received_at FROM waybills WHERE id=?', (bill,)).fetchone()[0], 1762600007890)

    def test_offline_queue_flush_and_retry_is_idempotent(self):
        bill = self.add_bill('sari', 'tehran')
        p = self.branches['sari'][1]/'sync-config.json'
        old = json.loads(p.read_text(encoding='utf-8'))
        broken = dict(old, hub_url='http://127.0.0.1:1')
        p.write_text(json.dumps(broken, ensure_ascii=False), encoding='utf-8')
        self.assertFalse(self.sync('sari')['ok'])
        with self.branches['sari'][0]() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM sync_outbox WHERE sent_at IS NULL').fetchone()[0], 1)
        p.write_text(json.dumps(old, ensure_ascii=False), encoding='utf-8')
        self.assertTrue(self.sync('sari')['ok'])
        self.assertTrue(self.sync('tehran')['ok'])
        with self.branches['tehran'][0]() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM waybills WHERE id=?', (bill,)).fetchone()[0], 1)
        with self.branches['sari'][0]() as c:
            c.execute('UPDATE sync_outbox SET sent_at=NULL'); c.commit()
        self.assertTrue(self.sync('sari')['ok'])
        with sqlite3.connect(self.hub_db) as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM hub_events').fetchone()[0], 1)

    def test_invalid_branch_secret_cannot_read_catalog(self):
        p = self.branches['babol'][1]/'sync-config.json'
        config = json.loads(p.read_text(encoding='utf-8'))
        config['token'] = 'incorrect-token-with-32-or-more-characters'
        p.write_text(json.dumps(config, ensure_ascii=False), encoding='utf-8')
        self.assertFalse(self.sync('babol')['ok'])

if __name__ == '__main__': unittest.main()
