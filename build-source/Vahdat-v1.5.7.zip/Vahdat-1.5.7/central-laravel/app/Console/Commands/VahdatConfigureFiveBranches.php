<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Throwable;

/**
 * One-time, audit-friendly setup for Tehran <-> Amol/Babol/Qaemshahr/Sari.
 * Defaults to preview only. Never overwrites existing branch tokens.
 */
final class VahdatConfigureFiveBranches extends Command
{
    protected $signature = 'vahdat:configure-five-branches
        {--apply : Save configuration (default only previews)}
        {--replace-routes : Explicitly disable extra existing routes involving these five branches}';

    protected $description = 'Review or apply the five Autobenz Vahdat branches and eight directed routes';

    public function handle(): int
    {
        $filename = base_path('config/vahdat-five-branch-plan.json');
        if (!is_file($filename)) {
            $this->error('Missing private branch plan: '.$filename);
            return self::FAILURE;
        }
        try {
            $plan = json_decode((string) file_get_contents($filename), true, 512, JSON_THROW_ON_ERROR);
        } catch (Throwable $e) {
            $this->error('Invalid branch plan JSON.');
            return self::FAILURE;
        }
        $branches = $plan['branches'] ?? [];
        $routes = $plan['routes'] ?? [];
        $ids = array_column($branches, 'id');
        $names = array_column($branches, 'name');
        if (count($branches) !== 5 || count($routes) !== 8 || count(array_unique($ids)) !== 5
            || count(array_unique($names)) !== 5 || !in_array('tehran', $ids, true)) {
            $this->error('The five-branch plan is incomplete or inconsistent.');
            return self::FAILURE;
        }
        foreach ($routes as $route) {
            if (!in_array($route['origin'] ?? '', $ids, true)
                || !in_array($route['destination'] ?? '', $ids, true)
                || $route['origin'] === $route['destination']
                || ($route['origin'] !== 'tehran' && $route['destination'] !== 'tehran')) {
                $this->error('Unexpected route in the five-branch plan.');
                return self::FAILURE;
            }
        }
        if (!Schema::hasTable('vahdat_sync_branches') || !Schema::hasTable('vahdat_sync_routes')) {
            $this->error('Run the Vahdat sync database migrations on a staging copy first.');
            return self::FAILURE;
        }
        $expected = array_fill_keys(array_map(
            fn ($r) => $r['origin'].'>'.$r['destination'], $routes
        ), true);
        if (count($expected) !== 8) {
            $this->error('Duplicate route in plan.');
            return self::FAILURE;
        }
        $existingBranches = DB::table('vahdat_sync_branches')->get(['id', 'name', 'enabled']);
        $byId = $existingBranches->keyBy('id');
        foreach ($branches as $b) {
            $existing = $byId->get($b['id']);
            if ($existing && $existing->name !== $b['name']) {
                $this->error("Existing branch ID {$b['id']} belongs to another name. Nothing changed.");
                return self::FAILURE;
            }
            if ($existing && !$existing->enabled) {
                $this->error("Branch {$b['id']} is disabled; enable it deliberately in the admin panel first.");
                return self::FAILURE;
            }
            if ($existingBranches->first(fn ($x) => $x->name === $b['name'] && $x->id !== $b['id'])) {
                $this->error('One branch name is already assigned to another ID. Nothing changed.');
                return self::FAILURE;
            }
        }
        $existingRoutes = DB::table('vahdat_sync_routes')->where('enabled', true)
            ->where(fn ($q) => $q->whereIn('origin_id', $ids)->orWhereIn('destination_id', $ids))
            ->get(['origin_id', 'destination_id']);
        $extras = $existingRoutes->filter(fn ($r) => !isset($expected[$r->origin_id.'>'.$r->destination_id]));
        if ($extras->count()) {
            $this->warn('There are '.$extras->count().' active routes involving these branches not in the plan.');
            if ($this->option('apply') && !$this->option('replace-routes')) {
                $this->error('No changes. Review them, then use --replace-routes explicitly if safe.');
                return self::FAILURE;
            }
        }
        $this->table(['Branch ID', 'Name', 'State'], array_map(fn ($b) => [
            $b['id'], $b['name'], $byId->has($b['id']) ? 'already exists' : 'will create'
        ], $branches));
        $this->table(['From', 'To'], array_map(fn ($r) => [$r['origin'], $r['destination']], $routes));
        if (!$this->option('apply')) {
            $this->info('PREVIEW ONLY. No database records or secrets have been changed.');
            return self::SUCCESS;
        }
        // Generate secrets on the destination server at deployment time (never put them in ZIP/Git).
        // Prewrite with strict permissions so a failed secret-file write never leaves unusable tokens.
        $new = array_values(array_filter($branches, fn ($b) => !$byId->has($b['id'])));
        $credentials = [];
        foreach ($new as $b) {
            $credentials[$b['id']] = [
                'name' => $b['name'],
                'token' => bin2hex(random_bytes(32)),
            ];
        }
        $secretPath = null;
        if ($credentials) {
            $dir = storage_path('app/private/vahdat');
            if (!is_dir($dir) && !mkdir($dir, 0700, true) && !is_dir($dir)) {
                $this->error('Unable to create private credentials folder. No changes.');
                return self::FAILURE;
            }
            @chmod($dir, 0700);
            $secretPath = $dir.'/five-branch-keys-'.date('Ymd-His').'-'.bin2hex(random_bytes(5)).'.json';
            $oldUmask = umask(0077);
            $stream = fopen($secretPath, 'x');
            umask($oldUmask);
            if (!$stream) {
                $this->error('Unable to create a private credentials file. No changes.');
                return self::FAILURE;
            }
            try {
                $written = fwrite($stream, json_encode($credentials, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR));
                if ($written === false || $written !== strlen(json_encode($credentials, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR)))
                    throw new \RuntimeException('Failed writing complete branch credentials');
            } catch (Throwable $e) {
                fclose($stream);
                @unlink($secretPath);
                $this->error('Unable to store new branch credentials. No changes.');
                return self::FAILURE;
            }
            fclose($stream);
            @chmod($secretPath, 0600);
        }
        try {
            DB::transaction(function () use ($new, $credentials, $routes, $ids, $extras) {
                foreach ($new as $b) {
                    DB::table('vahdat_sync_branches')->insert([
                        'id' => $b['id'], 'name' => $b['name'],
                        'token_sha256' => hash('sha256', $credentials[$b['id']]['token']),
                        'enabled' => true, 'created_at' => now(), 'updated_at' => now(),
                    ]);
                }
                if ($extras->count()) {
                    // Existing events and acknowledgments remain in the database.
                    DB::table('vahdat_sync_routes')->where(function ($q) use ($ids) {
                        $q->whereIn('origin_id', $ids)->orWhereIn('destination_id', $ids);
                    })->where('enabled', true)->update(['enabled' => false, 'updated_at' => now()]);
                }
                foreach ($routes as $r) {
                    DB::table('vahdat_sync_routes')->updateOrInsert([
                        'origin_id' => $r['origin'], 'destination_id' => $r['destination'],
                    ], ['enabled' => true, 'updated_at' => now()]);
                }
            }, 3);
        } catch (Throwable $e) {
            if ($secretPath) @unlink($secretPath);
            $this->error('Failed to apply network plan. Transaction rolled back. '.$e->getMessage());
            return self::FAILURE;
        }
        $this->info('Saved five branch identities and eight directed routes. Existing tokens were preserved.');
        if ($secretPath) {
            $this->warn('One-time branch credentials (PRIVATE, not web accessible): '.$secretPath);
            $this->warn('Store them securely on the matching branch servers; exclude this file from backups shared publicly.');
        } else {
            $this->warn('No new branches. Existing tokens are not reissued; rotate one branch key in the admin panel if needed.');
        }
        return self::SUCCESS;
    }
}
