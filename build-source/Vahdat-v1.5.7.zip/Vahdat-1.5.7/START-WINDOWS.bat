@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  where py >nul 2>nul
  if not errorlevel 1 (
    py -3.11 -m venv .venv
  ) else (
    python -m venv .venv
  )
  if errorlevel 1 (
    echo Python 3.11 x64 is needed to run this source version.
    pause
    exit /b 1
  )
)
".venv\Scripts\python.exe" -m pip install -r windows\requirements.txt
if errorlevel 1 (
  echo Could not install Python dependencies. Check internet connection.
  pause
  exit /b 1
)
echo Running Vahdat at http://127.0.0.1:8765
".venv\Scripts\python.exe" windows\app.py
pause
