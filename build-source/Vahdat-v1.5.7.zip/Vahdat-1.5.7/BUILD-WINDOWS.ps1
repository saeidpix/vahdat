# Build Vahdat Windows on Windows 10/11 x64; creates portable EXE and Inno Setup installer.
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$python = Get-Command py -ErrorAction SilentlyContinue
if ($python) { & py -3.11 --version; if ($LASTEXITCODE -ne 0) { throw 'Python 3.11 x64 is required. Install it from python.org' }; $py = 'py' }
else {
  $python = Get-Command python -ErrorAction SilentlyContinue
  if (-not $python) { throw 'Python 3.11 x64 is required. Install it and re-run BUILD-WINDOWS.bat' }
  & python --version
  $py = 'python'
}
if (-not (Test-Path '.venv\Scripts\python.exe')) {
  if ($py -eq 'py') { & py -3.11 -m venv .venv } else { & python -m venv .venv }
  if ($LASTEXITCODE -ne 0) { throw 'Could not create Python virtual environment.' }
}
$pythonExe = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
& $pythonExe -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw 'pip bootstrap failed' }
& $pythonExe -m pip install -r windows\requirements.txt pyinstaller==6.16.0
if ($LASTEXITCODE -ne 0) { throw 'dependency install failed' }
& $pythonExe -m unittest discover -s windows -p 'test_*.py' -v
if ($LASTEXITCODE -ne 0) { throw 'Unit tests failed; installer was NOT created.' }
if (Get-Command node -ErrorAction SilentlyContinue) {
  & node windows\test_ui.cjs
  if ($LASTEXITCODE -ne 0) { throw 'JavaScript smoke tests failed' }
  & node windows\test_settings_156.cjs
  if ($LASTEXITCODE -ne 0) { throw 'Settings UI tests failed' }
}
& $pythonExe -c "from PIL import Image; Image.open('app/src/main/res/drawable/brand_logo.png').convert('RGBA').save('windows/assets/logo.ico',format='ICO',sizes=[(16,16),(32,32),(48,48),(64,64),(128,128)])"
if ($LASTEXITCODE -ne 0) { throw 'Could not make icon' }
Copy-Item 'app\src\main\res\drawable\brand_logo.png' 'windows\assets\logo.png' -Force
& (Join-Path $PSScriptRoot '.venv\Scripts\pyinstaller.exe') --noconfirm --clean --onefile --noconsole --name VahdatServer --icon 'windows\assets\logo.ico' --add-data 'windows\ui.html;.' --add-data 'windows\financial-report-print.html;.' --add-data 'windows\assets\logo.png;.' --add-data 'windows\assets;assets' windows\app.py
if ($LASTEXITCODE -ne 0 -or -not (Test-Path 'dist\VahdatServer.exe')) { throw 'Portable EXE build failed' }
Write-Host 'Portable Windows EXE is ready: dist\VahdatServer.exe' -ForegroundColor Green
$inno = Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6\ISCC.exe'
if (Test-Path $inno) {
  & $inno 'windows\install.iss'
  if ($LASTEXITCODE -ne 0) { throw 'Inno Setup failed' }
  Write-Host 'Setup ready: dist\installer\Vahdat-Setup-Windows-v1.5.6-beta.exe' -ForegroundColor Green
} else {
  Write-Host 'Inno Setup 6 was not found. Install it and re-run this script to create Setup.' -ForegroundColor Yellow
}
