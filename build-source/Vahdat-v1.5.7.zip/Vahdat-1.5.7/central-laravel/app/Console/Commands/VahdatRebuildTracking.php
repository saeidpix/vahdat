<?php

namespace App\Console\Commands;

use App\Services\VahdatTracking;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

/** Backfill tracking from the immutable relay log, no financial or ticket tables touched. */
final class VahdatRebuildTracking extends Command
{
    protected $signature = 'vahdat:rebuild-tracking';
    protected $description = 'Recalculate branch shipment status from already accepted Vahdat sync events';

    public function handle(): int
    {
        $branches = DB::table('vahdat_sync_branches')->get()->keyBy('id');
        $byName = DB::table('vahdat_sync_branches')->get()->keyBy('name');
        $ok = 0;
        $skipped = 0;
        DB::table('vahdat_sync_events')->orderBy('sequence')
            ->chunkById(250, function ($events) use ($branches, $byName, &$ok, &$skipped) {
                foreach ($events as $event) {
                    if (!in_array($event->kind,
                        ['waybill_issued', 'manifest_created', 'waybill_received', 'waybill_delivered'], true)) {
                        continue;
                    }
                    $origin = $branches->get($event->source_branch);
                    $target = $branches->get($event->target_branch_id ?? '')
                        ?: $byName->get($event->target);
                    if (!$origin || !$target) {
                        $skipped++;
                        $this->warn('Unknown branch for sync sequence ' . $event->sequence);
                        continue;
                    }
                    try {
                        $payload = is_array($event->payload) ? $event->payload
                            : json_decode((string) $event->payload, true, 512, JSON_THROW_ON_ERROR);
                        DB::transaction(function () use ($event, $payload, $origin, $target) {
                            VahdatTracking::apply($event->kind, $payload, $origin, $target);
                        });
                        $ok++;
                    } catch (\Throwable $error) {
                        $skipped++;
                        $this->warn('Tracking skipped sequence ' . $event->sequence . ': ' . $error->getMessage());
                    }
                }
            }, 'sequence');
        $this->info("Tracking replay complete. applied={$ok}; skipped={$skipped}.");
        return $skipped === 0 ? self::SUCCESS : self::FAILURE;
    }
}
