# -*- coding: utf-8 -*-
"""Tests for stable branch IDs, destination access lists and offline catalog caching."""
import json
import pathlib
import sqlite3
import sys
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer

sys.path.insert(0,str(pathlib.Path(__file__).parent))
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'tools'))
import sync_engine as se
import central_demo
from test_sync import SCHEMA, ManagedConnection

TOKENS={
 'tehran':('تهران','alpha-token-32-chars-abcdefghijklmnopqrstuvwxyz'),
 'qaemshahr':('قائم‌شهر','beta-token-32-chars-abcdefghijklmnopqrstuvwxyz'),
 'sari':('ساری','gamma-token-32-chars-abcdefghijklmnopqrstuvwxyz'),
}

class BranchCatalogTests(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup);self.root=pathlib.Path(tmp.name)
        db=str(self.root/'hub.sqlite3');central_demo.init_db(db)
        self.routes={'tehran':['qaemshahr'],'qaemshahr':[],'sari':[]}
        self.server=ThreadingHTTPServer(('127.0.0.1',0),central_demo.handler_for(db,TOKENS,self.routes))
        threading.Thread(target=self.server.serve_forever,daemon=True).start()
        self.addCleanup(self.server.server_close);self.addCleanup(self.server.shutdown)
        self.tehran=self.make('tehran');self.qaem=self.make('qaemshahr');self.sari=self.make('sari')
    def make(self,id):
        path=self.root/id;path.mkdir()
        conn=sqlite3.connect(str(path/'data.sqlite3'))
        try:conn.executescript(SCHEMA);se.migrate(conn)
        finally:conn.close()
        (path/'sync-config.json').write_text(json.dumps(dict(enabled=True,branch_id=id,
            branch_name=TOKENS[id][0],hub_url=f'http://127.0.0.1:{self.server.server_port}',
            token=TOKENS[id][1]),ensure_ascii=False),encoding='utf-8')
        def connect():
            c=sqlite3.connect(str(path/'data.sqlite3'),timeout=4,factory=ManagedConnection)
            c.row_factory=sqlite3.Row;return c
        return connect,path
    def issue(self,destination):
        conn,_=self.tehran
        with conn() as c:
            c.execute('''INSERT INTO waybills(id,origin,destination,sender,receiver,phone,pieces,
                prepaid,post_fare,storage_fee,other_fee,total,created_at,number)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',(
                'VH-1762600000000-ABC123','تهران',destination,'علی','رضا','09120000000',
                1,200000,0,0,0,200000,1762600000000,42))
            se.queue_waybill(c,'VH-1762600000000-ABC123');c.commit()
    def test_stable_id_routing_never_leaks_to_third_branch(self):
        self.assertTrue(se.sync_once(*self.tehran)['ok'])
        with self.tehran[0]() as c:
            self.assertEqual(se.permitted_destinations(c,se.load_config(self.tehran[1])),['قائم‌شهر'])
            self.assertEqual(se.branch_target(c,'قائم‌شهر'),'qaemshahr')
        self.issue('قائم‌شهر')
        with self.tehran[0]() as c:
            self.assertEqual(c.execute('SELECT target FROM sync_outbox').fetchone()[0],'qaemshahr')
        self.assertTrue(se.sync_once(*self.tehran)['ok'])
        self.assertTrue(se.sync_once(*self.qaem)['ok'])
        self.assertTrue(se.sync_once(*self.sari)['ok'])
        with self.qaem[0]() as c:self.assertEqual(c.execute('SELECT COUNT(*) FROM waybills').fetchone()[0],1)
        with self.sari[0]() as c:self.assertEqual(c.execute('SELECT COUNT(*) FROM waybills').fetchone()[0],0)
    def test_unauthorized_destination_stays_in_outbox(self):
        self.assertTrue(se.sync_once(*self.tehran)['ok'])
        self.issue('ساری')
        result=se.sync_once(*self.tehran)
        self.assertFalse(result['ok'])
        with self.tehran[0]() as c:self.assertEqual(c.execute('SELECT COUNT(*) FROM sync_outbox WHERE sent_at IS NULL').fetchone()[0],1)
        self.assertTrue(se.sync_once(*self.sari)['ok'])
        with self.sari[0]() as c:self.assertEqual(c.execute('SELECT COUNT(*) FROM waybills').fetchone()[0],0)
    def test_catalog_permission_update_and_offline_cache(self):
        self.assertTrue(se.sync_once(*self.tehran)['ok'])
        self.routes['tehran']=['sari']
        self.assertTrue(se.sync_once(*self.tehran)['ok'])
        with self.tehran[0]() as c:
            self.assertEqual(se.permitted_destinations(c,se.load_config(self.tehran[1])),['ساری'])
        p=self.tehran[1]/'sync-config.json';j=json.loads(p.read_text(encoding='utf-8'))
        j['hub_url']='http://127.0.0.1:1';p.write_text(json.dumps(j,ensure_ascii=False),encoding='utf-8')
        self.assertFalse(se.sync_once(*self.tehran)['ok'])
        with self.tehran[0]() as c:
            self.assertEqual(se.permitted_destinations(c,se.load_config(self.tehran[1])),['ساری'])
    def test_receipt_returns_without_reverse_shipping_permission(self):
        self.issue('قائم‌شهر')
        self.assertTrue(se.sync_once(*self.tehran)['ok'])
        self.assertTrue(se.sync_once(*self.qaem)['ok'])
        with self.qaem[0]() as c:
            c.execute('UPDATE waybills SET received_at=? WHERE id=?',(1762600000600,'VH-1762600000000-ABC123'))
            row=c.execute('SELECT * FROM waybills').fetchone()
            se.queue_received(c,row,row['received_at']);c.commit()
            self.assertEqual(c.execute('SELECT target FROM sync_outbox').fetchone()[0],'tehran')
        self.assertTrue(se.sync_once(*self.qaem)['ok'])
        self.assertTrue(se.sync_once(*self.tehran)['ok'])
        with self.tehran[0]() as c:
            self.assertEqual(c.execute('SELECT received_at FROM waybills').fetchone()[0],1762600000600)

    def test_configured_branch_identity_cannot_impersonate_other_branch(self):
        p=self.tehran[1]/'sync-config.json';j=json.loads(p.read_text(encoding='utf-8'))
        j['branch_name']='ساری';p.write_text(json.dumps(j,ensure_ascii=False),encoding='utf-8')
        res=se.sync_once(*self.tehran)
        self.assertFalse(res['ok'])
        self.assertIn('هویت شعبه',res['error'])

if __name__=='__main__':unittest.main()
