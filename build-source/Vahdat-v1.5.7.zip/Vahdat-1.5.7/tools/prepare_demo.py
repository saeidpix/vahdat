# -*- coding: utf-8 -*-
"""Create localhost-only demo configs in isolated folders, never in ProgramData."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent/'demo-data'
settings=[('tehran','تهران','alpha-key-long-enough-for-testing-123456789',8765),
          ('destination','قائم‌شهر','beta-key-long-enough-for-testing-123456789',8766)]
for branch_id,branch_name,token,port in settings:
    target=ROOT/branch_id/'Vahdat';target.mkdir(parents=True,exist_ok=True)
    config=target/'sync-config.json'
    config.write_text(json.dumps(dict(enabled=True,branch_id=branch_id,branch_name=branch_name,
                        hub_url='http://127.0.0.1:18885',token=token),ensure_ascii=False,indent=2),encoding='utf-8')
print('Separate branch data folders ready:',ROOT)
print('DEMO ONLY: tokens are public examples and must never be used on the actual host.')
