# -*- coding: utf-8 -*-
"""Regression tests for the A4-landscape financial print pipeline."""
import pathlib, sys, tempfile, unittest
sys.path.insert(0,str(pathlib.Path(__file__).parent))
import app as v

class FinancialPrintTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        v.DATA=pathlib.Path(self.temp.name);v.DB=v.DATA/'report-test.sqlite3';v.init()
        self.c=v.app.test_client()
        self.assertEqual(self.c.get('/api/reports-v2?include_items=1').status_code,401)
        res=self.c.post('/api/auth/bootstrap',json={
            'name':'مدیر آزمون','mobile':'09120000000','password':'SecurePassword123!'})
        self.assertEqual(res.status_code,200,res.json)
        self.csrf=self.c.get('/api/auth/status').json['csrf']
    def post(self,url,**data):
        return self.c.post(url,json=data,headers={'X-CSRF-Token':self.csrf})

    def test_print_page_is_served_and_api_reads_exact_same_rows_as_totals(self):
        view=self.c.get('/reports/print?mode=all')
        self.assertEqual(view.status_code,200)
        self.assertIn('financial-report-print.js',view.get_data(as_text=True))
        css=self.c.get('/assets/financial-report-print.css').get_data(as_text=True)
        self.assertIn('size:A4 landscape',css)
        self.assertIn('table-header-group',css)
        self.assertEqual(self.c.get('/assets/financial-report-print.js').status_code,200)
        # Legacy odd-priced waybills must never create an inconsistent printed footer.
        for pre,post in [(125,0),(201,99)]:
            res=self.post('/api/waybills',destination='قائم‌شهر',receiver='گیرنده نمونه',
                          pieces=2,prepaid=pre,post_fare=post,storage_fee=10,other_fee=5)
            self.assertEqual(res.status_code,201,res.json)
        compact=self.c.get('/api/reports-v2?mode=all').json
        detail=self.c.get('/api/reports-v2?mode=all&include_items=1').json
        self.assertNotIn('items',compact)
        self.assertEqual(detail['totals'],compact['totals'])
        self.assertEqual(len(detail['items']),2)
        self.assertEqual(detail['branch_name'],'تهران')
        self.assertEqual(detail['generated_by'],'مدیر آزمون')
        self.assertIn('generated_at_fa',detail)
        self.assertEqual(detail['totals']['driver_share'],sum(x['driver_share'] for x in detail['items']))
        self.assertEqual(detail['totals']['company_share'],sum(x['company_share'] for x in detail['items']))
        for key in ('prepaid','post_fare','storage_fee','other_fee','total'):
            self.assertEqual(detail['totals'][key],sum(x[key] for x in detail['items']))
        self.assertEqual(detail['totals']['total'],455)
        self.assertEqual(detail['totals']['driver_share'],212)
        self.assertEqual(detail['totals']['company_share'],213)

    def test_report_print_uses_server_permissions(self):
        res=self.post('/api/users',name='کاربر بدون گزارش',mobile='09121111111',
                      role='warehouse',password='SecurePassword111')
        self.assertEqual(res.status_code,201,res.json)
        self.post('/api/auth/logout')
        res=self.c.post('/api/auth/login',json={'mobile':'09121111111','password':'SecurePassword111'})
        self.assertEqual(res.status_code,200)
        self.assertEqual(self.c.get('/api/reports-v2?mode=all&include_items=1').status_code,403)

    def test_invalid_jalali_date_is_rejected_before_data_is_returned(self):
        res=self.c.get('/api/reports-v2?mode=date&date=1404/12/30&include_items=1')
        self.assertEqual(res.status_code,400)
        self.assertIn('error',res.json)

if __name__=='__main__':unittest.main()
