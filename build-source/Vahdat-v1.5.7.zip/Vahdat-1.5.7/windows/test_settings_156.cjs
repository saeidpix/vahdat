/* Settings UI unit regression: no browser or internet required. */
'use strict';
const fs=require('fs');
const path=require('path');
const vm=require('vm');
const assert=require('assert');
const script=fs.readFileSync(path.join(__dirname,'assets/settings-ui.js'),'utf8');
const settingsCss=fs.readFileSync(path.join(__dirname,'assets/settings.css'),'utf8');
const html=fs.readFileSync(path.join(__dirname,'ui.html'),'utf8');
assert(html.includes('/assets/settings-ui.js'));
assert(html.includes('/assets/settings.css'));
assert(settingsCss.includes('@media(max-width:620px)'));

const context={
  settingsForm:async()=>{},
  state:{settings:{}},
  currentPerms:['backup','settings'],
  printOptions:{},
  esc:s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;'),
  fmt:v=>String(v),
  icon:s=>`[${s}]`,
  title:s=>`<h2>${s}</h2>`,
  set:s=>{context.rendered=s},
  renderDest:()=>{context.destinationsRendered=true},
  apiCall:async url=>url==='/api/settings'?context.config:context.printResponse,
};
vm.createContext(context);
new vm.Script(script,{filename:'settings-ui.js'}).runInContext(context);
(async()=>{
 context.config={origin:'تهران',branch_id:'THR',destinations:['قائم‌شهر','ساری'],central_managed:false};
 context.printResponse={on_issue:false,on_handover:true,on_receive:false};
 await context.settingsForm();
 for(const item of ['سعید فداییان','www.saeidpix.ir','09126862669','مدیریت مقصدها','چاپ فوری']){
  if(item==='مدیریت مقصدها')continue;
  assert(context.rendered.includes(item),`Missing ${item}`);
 }
 assert(context.rendered.includes('id="newdest"'));
 assert(context.rendered.includes('id="on_handover" checked'));
 assert(context.rendered.includes('href="/api/backup"'));
 assert(context.destinationsRendered);
 context.config.central_managed=true;
 await context.settingsForm();
 assert(!context.rendered.includes('id="newdest"'));
 assert(context.rendered.includes('مقصدها از مرکز مدیریت می‌شوند'));
 context.currentPerms=['settings'];
 await context.settingsForm();
 assert(!context.rendered.includes('href="/api/backup"'));
 console.log('Settings v1.5.6 PASS: layout, credits, local/central routes, print controls, backup permission');
})().catch(e=>{console.error(e);process.exitCode=1});
