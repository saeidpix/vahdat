/* Vahdat Mobile Navigation v1.5.1 — responsive only, access remains server-authorized. */
'use strict';
(function(){
  const primary=['home','new','scan','list'];
  const side=document.querySelector('.side');
  if(!side)return;
  primary.forEach(p=>document.getElementById('nav-'+p)?.classList.add('mobile-primary'));
  function updateMobileCount(){
    const visible=primary.filter(p=>{const el=document.getElementById('nav-'+p);return el&&!el.hidden;}).length;
    side.style.setProperty('--mobile-nav-count',String(Math.max(1,visible+1)));
  }
  const oldUpdateNav=updateNav;
  updateNav=function(){oldUpdateNav();updateMobileCount()};
  updateMobileCount();
  const more=document.createElement('button');
  more.type='button';more.className='mobile-more';more.id='nav-more';more.setAttribute('aria-label','بیشتر، سایر بخش‌ها');
  more.setAttribute('aria-controls','mobileMoreDrawer');more.setAttribute('aria-expanded','false');
  more.innerHTML='<span class="sym">'+icon('settings')+'</span><span class="text">بیشتر</span>';
  side.appendChild(more);
  const overlay=document.createElement('div');overlay.className='mobile-menu-overlay';overlay.id='mobileMoreDrawer';overlay.hidden=true;
  overlay.innerHTML='<section class="mobile-menu" role="dialog" aria-modal="true" aria-label="بخش‌های دیگر"><div class="mobile-menu-heading"><h2>بخش‌های دیگر</h2><button class="mobile-menu-close" type="button" aria-label="بستن منو">× بستن</button></div><div class="mobile-menu-list"></div></section>';
  document.body.appendChild(overlay);
  const menu=overlay.querySelector('.mobile-menu-list');
  function canSee(entry){return !entry.hidden && (typeof allow==='function'?allow(entry.id.slice(4)):true)}
  function fill(){
    menu.replaceChildren();
    Array.from(side.querySelectorAll('.nav')).filter(e=>e.id!=='logoutButton'&&!primary.includes(e.id.slice(4))&&canSee(e)).forEach(e=>{
      const p=e.id.slice(4),b=document.createElement('button');b.type='button';b.className='mobile-menu-link'+(state.page===p?' current':'');
      b.innerHTML=e.querySelector('.sym')?.outerHTML||'';
      const t=document.createElement('span');t.textContent=e.querySelector('.text')?.textContent||p;b.appendChild(t);
      b.onclick=()=>{close();go(p)};menu.appendChild(b);
    });
    const logout=side.querySelector('#logoutButton');
    if(logout && !logout.hidden){let b=document.createElement('button');b.type='button';b.className='mobile-menu-link logout';b.textContent='خروج از حساب';b.onclick=()=>{close();logOut()};menu.appendChild(b)}
  }
  function close(restoreFocus=false){overlay.hidden=true;document.body.classList.remove('mobile-menu-open');more.setAttribute('aria-expanded','false');if(restoreFocus)more.focus()}
  function open(){fill();overlay.hidden=false;document.body.classList.add('mobile-menu-open');more.setAttribute('aria-expanded','true');overlay.querySelector('.mobile-menu-close').focus()}
  more.addEventListener('click',()=>overlay.hidden?open():close(true));
  overlay.querySelector('.mobile-menu-close').addEventListener('click',()=>close(true));
  overlay.addEventListener('click',e=>{if(e.target===overlay)close(true)});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!overlay.hidden)close(true)});
  const oldNav=nav;
  nav=function(p){oldNav(p);if(!overlay.hidden)close();more.classList.toggle('active',!primary.includes(p)&&p!=='home');
      more.setAttribute('aria-current',!primary.includes(p)&&p!=='home'?'page':'false')};
  window.addEventListener('resize',()=>{if(window.innerWidth>520&&!overlay.hidden)close()});

  /* Add semantic table labels before switching desktop table rows into mobile cards. */
  function enhanceTables(){
    document.querySelectorAll('#page .tablewrap table').forEach(table=>{
      const headers=[...table.querySelectorAll('thead th')].map(x=>x.textContent.trim());
      table.querySelectorAll('tbody tr').forEach(tr=>{
        [...tr.children].filter(el=>el.tagName==='TD').forEach((td,i)=>{
          const label=headers[i]||'عملیات';
          if(td.dataset.label!==label)td.dataset.label=label;
        });
      });
    });
    const submit=document.querySelector('#handoverSummary');
    const handButton=document.querySelector('button[onclick="saveHandover()"]');
    if(submit&&handButton){
      const count=document.querySelectorAll('.hand-select:checked').length;
      handButton.disabled=count===0;
      handButton.title=count===0?'ابتدا بارنامه‌ها را انتخاب کنید':'';
    }
  }
  const page=document.getElementById('page');
  new MutationObserver(enhanceTables).observe(page,{subtree:true,childList:true});
  page.addEventListener('change',e=>{if(e.target.matches('.hand-select'))enhanceTables()});
  enhanceTables();
})();
