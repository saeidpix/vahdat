# -*- coding: utf-8 -*-
"""DEVELOPMENT-ONLY HTTP simulator of branch routing and sync. NEVER expose publicly."""
import argparse
import hmac
import json
import sqlite3
from contextlib import closing
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse


def init_db(db):
    c=sqlite3.connect(db)
    c.executescript('''
    CREATE TABLE IF NOT EXISTS hub_events (
      sequence INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT NOT NULL UNIQUE,
      source_branch TEXT NOT NULL,target TEXT NOT NULL,kind TEXT NOT NULL,
      payload TEXT NOT NULL, created_at INTEGER NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_hub_target ON hub_events(target,sequence);
    ''');c.commit();c.close()


def handler_for(db,tokens,routes=None):
    # tokens: {id: (Persian display name, demo secret)}. Routes use STABLE IDs.
    # A demo that omits routes permits all distinct branches to preserve old tests.
    if routes is None:routes={source:[x for x in tokens if x!=source] for source in tokens}
    def resolve(value):
        for id,(name,_) in tokens.items():
            if value==id or value==name:return id,name
        return None,None
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def send(self,code,obj):
            raw=json.dumps(obj,ensure_ascii=False).encode('utf-8')
            self.send_response(code);self.send_header('Content-Type','application/json; charset=utf-8')
            self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
        def authorized(self):
            branch=self.headers.get('X-Vahdat-Branch','')
            key=self.headers.get('Authorization','').removeprefix('Bearer ')
            expected=tokens.get(branch)
            if not expected or not hmac.compare_digest(key,expected[1]):
                self.send(401,{'error':'Invalid test branch token'});return None
            return branch
        def do_POST(self):
            sender=self.authorized()
            if sender is None:return
            path=urlparse(self.path).path
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=1_000_000:self.send(413,{});return
            try:
                data=json.loads(self.rfile.read(length))
                if path=='/api/v1/branches/sync/heartbeat':
                    self.send(200,{'ok':True});return
                if path!='/api/v1/branches/sync/push':self.send(404,{});return
                events=data['events']
                if not isinstance(events,list) or len(events)>100:raise ValueError('Batch limit')
                accepted=[]
                with closing(sqlite3.connect(db)) as c,c:
                    for e in events:
                        kind=e['kind'];payload=e['payload']
                        target_id,target_name=resolve(str(e['target']))
                        if not target_id or target_id==sender:raise ValueError('Unknown destination')
                        reverse=kind in ('waybill_received','waybill_delivered') or (kind=='settlement_created' and payload['settlement']['side']=='dest')
                        route_source,route_target=(target_id,sender) if reverse else (sender,target_id)
                        if route_target not in routes.get(route_source,[]):raise ValueError('Route not permitted')
                        if kind not in ('waybill_issued','manifest_created','waybill_received','waybill_delivered','settlement_created'):
                            raise ValueError('Unsupported event kind')
                        if kind in ('waybill_issued','manifest_created'):
                            b=payload['waybill'] if kind=='waybill_issued' else payload['manifest']
                            if kind=='waybill_issued' and b['origin']!=tokens[sender][0]:raise ValueError('Wrong source')
                            if b['destination']!=target_name:raise ValueError('Wrong destination')
                        eid=str(e['id'])
                        old=c.execute('SELECT source_branch,target,kind,payload FROM hub_events WHERE id=?',(eid,)).fetchone()
                        serialized=json.dumps(payload,ensure_ascii=False,sort_keys=True)
                        if old and (old[0]!=tokens[sender][0] or old[1]!=target_name or old[2]!=kind or old[3]!=serialized):
                            raise ValueError('Duplicate ID with different payload')
                        c.execute('INSERT OR IGNORE INTO hub_events(id,source_branch,target,kind,payload,created_at) VALUES(?,?,?,?,?,?)',
                                  (eid,tokens[sender][0],target_name,kind,serialized,int(e['created_at'])))
                        accepted.append(eid)
                self.send(200,{'accepted':accepted})
            except (ValueError,KeyError,TypeError,sqlite3.DatabaseError) as exc:self.send(400,{'error':str(exc)})
        def do_GET(self):
            sender=self.authorized()
            if sender is None:return
            path=urlparse(self.path)
            if path.path=='/api/v1/branches/sync/catalog':
                destinations=[{'id':id,'name':tokens[id][0]} for id in routes.get(sender,[]) if id in tokens]
                peerids=set(routes.get(sender,[]))|{id for id,allowed in routes.items() if sender in allowed}
                peers=[{'id':id,'name':tokens[id][0]} for id in sorted(peerids) if id in tokens]
                self.send(200,{'branch':{'id':sender,'name':tokens[sender][0]},'destinations':destinations,'peers':peers});return
            if path.path!='/api/v1/branches/sync/pull':self.send(404,{});return
            qs=parse_qs(path.query)
            try:cursor=max(0,int(qs.get('cursor',['0'])[0]));limit=min(200,max(1,int(qs.get('limit',['200'])[0])))
            except (ValueError,OverflowError):self.send(400,{'error':'Bad cursor'});return
            with closing(sqlite3.connect(db)) as c,c:
                c.row_factory=sqlite3.Row
                max_seq=c.execute('SELECT COALESCE(MAX(sequence),0) FROM hub_events').fetchone()[0]
                rows=c.execute('''SELECT * FROM hub_events WHERE sequence>? AND sequence<=? AND target=? AND source_branch!=?
                                  ORDER BY sequence LIMIT ?''',(cursor,max_seq,tokens[sender][0],tokens[sender][0],limit)).fetchall()
            ev=[dict(sequence=r['sequence'],id=r['id'],kind=r['kind'],source_branch=r['source_branch'],
                     target=r['target'],payload=json.loads(r['payload'])) for r in rows]
            last=ev[-1]['sequence'] if len(ev)==limit else max(max_seq,cursor)
            self.send(200,{'events':ev,'next_cursor':last})
    return Handler


def main():
    p=argparse.ArgumentParser();p.add_argument('--db',default='hub-demo.sqlite3');p.add_argument('--port',type=int,default=18885)
    p.add_argument('--tehran-token',required=True);p.add_argument('--destination-token',required=True)
    p.add_argument('--destination-name',default='قائم‌شهر');args=p.parse_args()
    init_db(args.db)
    hub=ThreadingHTTPServer(('127.0.0.1',args.port),handler_for(args.db,{
        'tehran':('تهران',args.tehran_token),'destination':(args.destination_name,args.destination_token)}))
    print('Local demo hub listening on 127.0.0.1:',args.port,flush=True)
    hub.serve_forever()
if __name__=='__main__':main()
