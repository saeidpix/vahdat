/* Vahdat 1.5.1-beta operational desktop UI: connects to local Flask/SQLite. */
'use strict';
let csrfToken='', currentUser=null, currentPerms=[], printOptions={};
const PERM_NAV={new:'issue',drivers:'drivers',handover:'handover',scan:'receive',settlement:'settle',list:'list',reports:'reports',users:'users',settings:'settings'};
const ROLE_LABEL={admin:'مدیر سیستم',issuance:'صدور بارنامه',warehouse:'انبار و تحویل',accountant:'حسابداری',viewer:'فقط مشاهده'};
const PERM_LABEL={issue:'صدور بارنامه',drivers:'رانندگان',handover:'تحویل به راننده',receive:'دریافت مقصد',settle:'تسویه راننده',list:'فهرست بارنامه',reports:'گزارش مالی',users:'مدیریت کاربران',settings:'تنظیمات',backup:'دریافت پشتیبان'};
const $$=id=>document.getElementById(id);
const allow=p=>!PERM_NAV[p]||currentPerms.includes(PERM_NAV[p]);
const textMoney=v=>fmt(v)+' تومان';
const amount=id=>num($$(id)?.value||0);
function numericInputs(){document.querySelectorAll('[data-money-input]').forEach(el=>{el.addEventListener('input',()=>{
 const digits=latin(el.value).replace(/\D/g,'').slice(0,15);el.value=digits?fmt(digits):'';
 if(el.closest('#newWaybillForm'))updateIssueTotal();
 if(el.closest('#settleForm'))updateSettleTotal();
 });});}
function moneyInput(id,label,v=0){return '<div class="field"><label for="'+id+'">'+esc(label)+'</label><input type="text" inputmode="numeric" autocomplete="off" data-money-input id="'+id+'" value="'+esc(fmt(v))+'"></div>'}
function apiCall(path,method,body){const opt={method:method||'GET',cache:'no-store',credentials:'same-origin',headers:{}};
 if(method&&method!=='GET'){opt.headers['Content-Type']='application/json';opt.headers['X-CSRF-Token']=csrfToken;opt.body=JSON.stringify(body||{})}
 return fetch(path,opt).then(async r=>{let j={};try{j=await r.json()}catch(_){throw Error('پاسخ سرور قابل خواندن نیست.')}if(!r.ok){if(r.status===401)showAuth();throw Error(j.error||'خطای سرور')}return j;});}
api=(url,opts)=>apiCall(url,opts?.method||'GET',opts?.body?JSON.parse(opts.body):undefined);
post=(url,value)=>apiCall(url,'POST',value);
function loginScreen(setup){document.body.classList.add('is-locked');
 const root=$$('authRoot');root.hidden=false;
 root.innerHTML='<div class="auth-box"><div class="auth-title">اتوبنز وحدت</div><h2>'+(setup?'راه‌اندازی اولیه مدیر سیستم':'ورود به برنامه')+'</h2><p>'+(setup?'ابتدا حساب مدیر را بسازید. این رمز برای ورودهای بعدی استفاده می‌شود.':'با موبایل و رمز عبور وارد شوید. ورود پیامکی در این نسخه فعال نیست.')+'</p><form id="authForm">'+
 (setup?'<label>نام مدیر</label><input id="authName" required maxlength="120" autocomplete="name">':'')+
 '<label>شماره موبایل</label><input id="authMobile" type="tel" dir="ltr" required placeholder="09xxxxxxxxx" inputmode="tel"><label>رمز عبور</label><input id="authPassword" type="password" required minlength="10" autocomplete="'+(setup?'new-password':'current-password')+'"><button class="btn wide" type="submit">'+(setup?'ساخت حساب مدیر':'ورود')+'</button><div id="authError" class="auth-error" role="alert"></div></form></div>';
 $$('authForm').onsubmit=async e=>{e.preventDefault();try{const r=await apiCall('/api/auth/'+(setup?'bootstrap':'login'),'POST',{name:$$('authName')?.value||'',mobile:$$('authMobile').value,password:$$('authPassword').value});if(r.ok)await bootstrapUI()}catch(err){$$('authError').textContent=err.message}};
}
function showAuth(){fetch('/api/auth/status',{cache:'no-store'}).then(x=>x.json()).then(j=>loginScreen(j.needs_setup)).catch(()=>loginScreen(false));}
function updateNav(){document.querySelectorAll('.nav').forEach(el=>{let p=el.id.slice(4);el.hidden=!allow(p)});
 const btn=$$('logoutButton');if(btn)btn.textContent='خروج · '+(currentUser?.name||'');}
async function bootstrapUI(){try{const j=await apiCall('/api/auth/status');if(!j.authenticated){loginScreen(j.needs_setup);return}
 currentUser=j.user;csrfToken=j.csrf;currentPerms=j.permissions||[];printOptions=j.print_settings||{};
 document.body.classList.remove('is-locked');$$('authRoot').hidden=true;updateNav();await apiCall('/api/settings').then(x=>state.settings=x);await go('home');
 }catch(err){loginScreen(false)}}
async function logOut(){try{await post('/api/auth/logout',{})}catch(_){ }csrfToken='';currentUser=null;showAuth()}
function allowedPage(p){if(!allow(p)){alert('برای این بخش دسترسی ندارید.');return false}return true}
const origGo=go;
go=async function(p){if(!allowedPage(p))return;
 state.page=p;nav(p);
 try{
 if(p==='drivers')await pageDrivers();
 else if(p==='handover')await pageHandover();
 else if(p==='settlement')await pageSettlement();
 else if(p==='scan')pageScan();
 else if(p==='reports')await pageReports();
 else if(p==='users')await pageUsers();
 else await origGo(p);
 }catch(err){fail(err)}
};
const origNewForm=newForm;
newForm=function(){
const choices=(state.settings.destinations||[]);
const dest='<div class="field"><label for="destination">مقصد</label><select id="destination">'+choices.map(d=>'<option>'+esc(d)+'</option>').join('')+'</select>'+(choices.length?'':'<small class="muted">مقصد مجاز تعریف نشده؛ مدیر کل باید ابتدا مسیر ارسال این شعبه را فعال کند.</small>')+'</div>';
set(title('صدور بارنامه')+'<form id="newWaybillForm" onsubmit="createWaybill(event)" class="issuance">'+
 card(section('box','مشخصات بار')+'<div class="origin">'+icon('route')+'<span>مبدأ</span><strong>'+esc(state.settings.origin||'تهران')+'</strong></div><div class="fields">'+dest+
 field('pieces','تعداد بسته','۱','inputmode="numeric" pattern="[0-9۰-۹]+"')+
 field('sender','نام فرستنده','')+field('senderPhone','موبایل فرستنده','','type="tel"')+
 field('receiver','نام گیرنده','')+field('phone','موبایل گیرنده','','type="tel"')+
 '<div class="field full"><label for="description">شرح بار</label><input id="description" maxlength="600"></div></div>')+
 card(section('money','کرایه و هزینه‌ها (تومان)')+'<div class="fields">'+
 moneyInput('prepaid','پیش‌کرایه مبدأ')+moneyInput('post_fare','پس‌کرایه مقصد')+
 moneyInput('storage_fee','انبارداری')+moneyInput('other_fee','سایر هزینه‌ها')+
 '</div><div class="sum"><span>جمع مبلغ بارنامه</span><span id="fareTotal">۰ تومان</span></div><div class="toolbar issue-actions"><button type="submit" id="issueButton" class="btn" '+(choices.length?'':'disabled')+'>'+icon('new')+'ثبت بارنامه</button></div>','fare-card')+'</form>');numericInputs();updateIssueTotal();
};
function updateIssueTotal(){let t=['prepaid','post_fare','storage_fee','other_fee'].reduce((n,k)=>n+amount(k),0);const e=$$('fareTotal');if(e)e.textContent=textMoney(t)}
async function createWaybill(ev){ev.preventDefault();const btn=$$('issueButton');if(btn.disabled)return;btn.disabled=true;
 try{let d={};['destination','pieces','sender','senderPhone','receiver','phone','description'].forEach(k=>d[k==="senderPhone"?'sender_phone':k]=$$(k)?.value||'');
 ['prepaid','post_fare','storage_fee','other_fee'].forEach(k=>d[k]=amount(k));d.pieces=num(d.pieces)||1;
 if(!d.destination||!d.sender.trim()||!d.receiver.trim())throw Error('مقصد، نام فرستنده و نام گیرنده را وارد کنید.');
 if(d.prepaid%2||d.post_fare%2)throw Error('برای تقسیم دقیق کرایه بین راننده و شرکت، پیش‌کرایه و پس‌کرایه باید عدد زوج باشند.');
 const r=await post('/api/waybills',d);await showBill(r.waybill.id,true);
 if(printOptions.on_issue)triggerPrint();
 }catch(err){fail(err)}finally{if(btn.isConnected)btn.disabled=false}}
function triggerPrint(){const root=$$('manifestPrintRoot');if(root)root.innerHTML='';const imgs=[...document.querySelectorAll('.print-card img')];Promise.all(imgs.map(i=>i.complete?Promise.resolve():new Promise(resolve=>{i.onload=resolve;i.onerror=resolve}))).then(()=>window.print())}
const originalShowBill=showBill;
showBill=async function(id,showQR){const oldPrint=$$('manifestPrintRoot');if(oldPrint)oldPrint.innerHTML='';await originalShowBill(id,showQR);
 const b=(await apiCall('/api/waybills/'+encodeURIComponent(id))).waybill;
 const info=document.querySelector('#page .grid2 .card');
 if(info){let add='';if(b.sender_phone)add+=row('موبایل فرستنده',b.sender_phone);if(b.description)add+=row('شرح بار',b.description);
 info.insertAdjacentHTML('beforeend',add)};
};
// Existing three-copy print template is retained and enhanced with sender/receiver contact and Code 39.
waybillPrintCopy=function(label,b){
 const val=(name,value,cls='col-6')=>printField(cls,name,value,value==null||value==='');
 return '<section class="print-slip"><div class="print-head"><div class="print-brand">اتوبنز وحدت</div><div class="print-sep"></div><div class="print-top-meta"><div class="print-number"><span>شماره بارنامه:</span><div class="print-number-box">'+esc(fmt(b.display_number||b.number))+'</div></div><div class="print-copy-badge">'+esc(label)+'</div></div></div><div class="print-body"><div class="print-qrbox"><img alt="QR معتبر بارنامه" src="/api/qr/'+encodeURIComponent(b.id)+'"><strong>QR</strong></div><div class="print-fields">'+
 val('تاریخ:',dateOnly(b.created_at_fa),'col-4')+val('مبدأ:',b.origin,'col-4')+val('مقصد:',b.destination,'col-4')+
 val('فرستنده:',b.sender,'col-8')+val('تلفن:',b.sender_phone,'col-4')+val('گیرنده:',b.receiver,'col-8')+val('تلفن:',b.phone,'col-4')+
 val('شرح بار:',b.description,'col-12 print-description')+val('تعداد بسته:',fmt(b.pieces),'col-4')+
 val('کرایه:',textMoney(b.prepaid+b.post_fare),'col-4')+val('پرداخت:',(b.prepaid&&b.post_fare?'ترکیبی':b.prepaid?'پیش‌کرایه':'پس‌کرایه'),'col-4')+
 val('امضا:','','col-8 print-signature')+val('کد رهگیری:',String(b.display_number||b.number),'col-4 print-tracking')+'</div></div><div class="bill-barcode"><img alt="بارکد خطی" src="/api/barcode/'+encodeURIComponent(b.id)+'"></div></section>';
};
function driverLabel(d){return d.first_name+' '+d.last_name}
async function pageDrivers(){let r=await apiCall('/api/drivers');let items=r.items||[];
set(title('رانندگان')+card(section('route','ثبت راننده')+'<form id="driverForm" onsubmit="saveDriver(event)"><div class="fields">'+field('driverFirst','نام','')+field('driverLast','نام خانوادگی','')+field('driverPhone','موبایل','','type="tel" inputmode="tel"')+'</div><button class="btn">'+icon('new')+'افزودن راننده</button></form>')+
 card(section('list','فهرست رانندگان')+'<div class="tablewrap"><table><thead><tr><th>نام</th><th>موبایل</th></tr></thead><tbody>'+items.map(d=>'<tr><td>'+esc(driverLabel(d))+'</td><td dir="ltr">'+esc(d.mobile)+'</td></tr>').join('')+'</tbody></table></div>'))}
async function saveDriver(e){e.preventDefault();try{await post('/api/drivers',{first_name:$$('driverFirst').value,last_name:$$('driverLast').value,mobile:$$('driverPhone').value});await pageDrivers()}catch(err){fail(err)}}
async function pageHandover(){const [d,b,m]=await Promise.all([apiCall('/api/drivers'),apiCall('/api/waybills'),apiCall('/api/manifests')]);const drivers=d.items.filter(x=>x.enabled);const bills=b.items.filter(x=>!x.manifest_id&&!x.received_at);
 const dests=[...new Set(bills.map(x=>x.destination))];
 set(title('تحویل بار به راننده')+card(section('box','انتخاب راننده و بارنامه‌ها')+
 '<div class="fields"><div class="field"><label for="handDriver">راننده</label><select id="handDriver">'+drivers.map(x=>'<option value="'+esc(x.id)+'">'+esc(driverLabel(x))+'</option>').join('')+'</select></div><div class="field"><label for="handDest">مقصد</label><select id="handDest" onchange="refreshHandoverList()">'+dests.map(x=>'<option>'+esc(x)+'</option>').join('')+'</select></div></div>'+
 (!drivers.length?'<div class="message err">ابتدا در بخش رانندگان یک راننده ثبت کنید.</div>':'')+
 '<form onsubmit="handoverScan(event)" class="scanner-line"><label for="handCode">اسکن بارکد بارنامه یا QR</label><input id="handCode" placeholder="کد را اسکن کنید و Enter بزنید" autocomplete="off" dir="ltr"><button type="submit" class="btn secondary">افزودن</button></form><div id="handScanResult" class="scan-feedback" role="status"></div><div id="handoverList"></div><div id="handoverSummary" class="sum"></div><button class="btn green" onclick="saveHandover()">'+icon('box')+'ثبت تحویل گروهی</button>')+
 card(section('list','محموله‌های تحویل‌شده')+'<div class="tablewrap"><table><thead><tr><th>محموله</th><th>راننده</th><th>بسته</th><th>وضعیت</th><th></th></tr></thead><tbody>'+m.items.map(x=>'<tr><td>'+esc(fmt(x.number))+'</td><td>'+esc(x.first_name+' '+x.last_name)+'</td><td>'+esc(fmt(x.piece_count))+'</td><td>'+esc(x.received_at?'دریافت مقصد':'در اختیار راننده')+'</td><td><button class="btn secondary" data-id="'+esc(x.id)+'" onclick="openSettlement(this.dataset.id)">جزئیات</button></td></tr>').join('')+'</tbody></table></div>'));
 window.handoverCache=bills;refreshHandoverList()}
function refreshHandoverList(){const dest=$$('handDest')?.value||'';const items=(window.handoverCache||[]).filter(x=>x.destination===dest);
 $$('handoverList').innerHTML='<div class="selectbills">'+items.map(b=>'<label class="bill-check"><input type="checkbox" class="hand-select" value="'+esc(b.id)+'" onchange="handoverSummary()"><span><strong>بارنامه '+esc(fmt(b.display_number||b.number))+' — '+esc(b.receiver)+'</strong><small>'+esc(fmt(b.pieces))+' بسته | کرایه '+esc(textMoney(b.prepaid+b.post_fare))+'</small></span></label>').join('')+'</div>'+(items.length?'':'<div class="muted">بارنامه‌ای آماده تحویل نیست.</div>');handoverSummary()}
function handoverSummary(){const ids=[...document.querySelectorAll('.hand-select:checked')].map(e=>e.value);
 const bills=(window.handoverCache||[]).filter(x=>ids.includes(x.id));const pieces=bills.reduce((s,x)=>s+x.pieces,0);
 if($$('handoverSummary'))$$('handoverSummary').innerHTML='<span>'+fmt(bills.length)+' بارنامه / '+fmt(pieces)+' بسته</span><span>سهم راننده: '+textMoney(bills.reduce((s,x)=>s+(x.prepaid+x.post_fare)/2,0))+'</span>'}
async function handoverScan(e){e.preventDefault();const el=$$('handCode');const code=el.value.trim();el.value='';el.focus();if(!code)return;
 try{const j=await post('/api/scan/lookup',{code});let b=j.waybill;let sel=[...document.querySelectorAll('.hand-select')].find(x=>x.value===b.id);
 if(!sel)throw Error('این بارنامه برای مقصد انتخابی آماده تحویل نیست.');sel.checked=true;handoverSummary();$$('handScanResult').textContent='بارنامه '+fmt(b.display_number||b.number)+' انتخاب شد.';
 }catch(err){$$('handScanResult').textContent=err.message}}
async function saveHandover(){try{const ids=[...document.querySelectorAll('.hand-select:checked')].map(x=>x.value);if(!ids.length)throw Error('حداقل یک بارنامه را انتخاب کنید.');
 const r=await post('/api/manifests',{driver_id:$$('handDriver').value,destination:$$('handDest').value,waybill_ids:ids});
 await pageSettlement(r.manifest.id);if(printOptions.on_handover)printManifest(r.manifest,'تحویل به راننده');
 }catch(err){fail(err)}}
async function openSettlement(id){await pageSettlement(id)}
async function pageSettlement(id){let manifests=(await apiCall('/api/manifests')).items||[];
 if(id){const q=await apiCall('/api/manifests/'+encodeURIComponent(id));window.settleManifest=q.manifest}
 else if(!window.settleManifest||!manifests.some(x=>x.id===window.settleManifest.id))window.settleManifest=manifests[0]||null;
 let m=window.settleManifest;
 const opts=manifests.map(x=>'<option value="'+esc(x.id)+'" '+(m&&m.id===x.id?'selected':'')+'>محموله '+esc(fmt(x.number))+' — '+esc(x.first_name+' '+x.last_name)+'</option>').join('');
 let inner='<div class="field"><label>محموله</label><select id="settleManifestSelect" onchange="pageSettlement(this.value)">'+opts+'</select></div>';
 if(m){inner+='<div class="settle-grid">'+
 [ ['origin','مبدأ',m.origin_share,m.origin_remaining,m.paid.origin_cash,m.paid.origin_passenger],
   ['dest','مقصد',m.dest_share,m.dest_remaining,m.paid.dest_cash,m.paid.dest_passenger] ].map(x=>'<div class="card settle-part"><h3>'+x[1]+'</h3>'+row('سهم راننده',textMoney(x[2]))+row('پرداخت پولی انجام‌شده',textMoney(x[4]))+row('تسویه با مسافر',textMoney(x[5]))+row('مانده سهم',textMoney(x[3]))+'</div>').join('')+'</div>'+
 '<form id="settleForm" onsubmit="submitSettlement(event)"><div class="fields"><div class="field"><label for="settleSide">سهم قابل تسویه</label><select id="settleSide" onchange="updateSettleTotal()"><option value="origin">مبدأ</option><option value="dest">مقصد</option></select></div><div></div>'+moneyInput('settleCash','مبلغ نقدی / بانکی')+moneyInput('settlePassenger','مبلغ تسویه با مسافر')+'</div><div class="sum" id="settleCalc"></div><button class="btn green">ثبت تسویه</button></form>'+
 '<div class="hint-note">در این نسخه حساب بدهکار و بستانکار تعریف نشده؛ فقط مبالغ تسویه هر دفتر ثبت می‌شود. انبارداری و سایر هزینه‌ها از این محاسبه خارج‌اند.</div>';
 }else inner+='<div class="muted">هنوز محموله‌ای برای تسویه ثبت نشده است.</div>';
 state.page='settlement';nav('settlement');set(title('تسویه سهم راننده')+card(inner));numericInputs();updateSettleTotal();}
function updateSettleTotal(){let m=window.settleManifest;if(!m)return;const side=$$('settleSide')?.value||'origin';const remaining=m[side+'_remaining'];const value=amount('settleCash')+amount('settlePassenger');const e=$$('settleCalc');
 if(e)e.innerHTML='<span>مبلغ تسویه: '+textMoney(value)+'</span><span>'+(value>remaining?'بیشتر از مانده':('باقی‌مانده: '+textMoney(remaining-value)))+'</span>'}
async function submitSettlement(e){e.preventDefault();try{let m=window.settleManifest;if(!m)throw Error('محموله‌ای انتخاب نشده است.');let side=$$('settleSide').value,cash=amount('settleCash'),passenger=amount('settlePassenger');
 if(cash+passenger===0)throw Error('مبلغی وارد نشده است.');if(cash+passenger>m[side+'_remaining'])throw Error('مبلغ تسویه بیشتر از سهم باقی‌مانده است.');
 await post('/api/manifests/'+encodeURIComponent(m.id)+'/settlements',{side,cash,passenger});await pageSettlement(m.id);
 }catch(err){fail(err)}}
function pageScan(){set(title('اسکن دریافت بار در مقصد')+card(section('scan','ثبت دریافت با بارکدخوان USB یا QR')+
 '<form id="receiveForm" onsubmit="receiveBarcode(event)" class="scanner-line"><label for="receiveCode">بارکدخوان را به کامپیوتر وصل کن، کد را اسکن کن و Enter بزن</label><input id="receiveCode" dir="ltr" autocomplete="off" placeholder="شماره بارنامه، شناسه یا QR"><button class="btn green" type="submit">ثبت دریافت</button></form><div id="receiveFeedback" class="message" role="status">کادر آماده دریافت اسکن است.</div><div id="receiveHistory"></div>'));$$('receiveCode').focus()}
async function receiveBarcode(e){e.preventDefault();const el=$$('receiveCode');const code=el.value.trim();if(!code)return;el.value='';
 try{const r=await post('/api/scan/receive',{code});$$('receiveFeedback').textContent=r.duplicate?'این بارنامه قبلاً دریافت شده است.':'دریافت بارنامه '+fmt(r.waybill.number)+' با '+fmt(r.waybill.pieces)+' بسته ثبت شد.';
 if(!r.duplicate){$$('receiveHistory').insertAdjacentHTML('afterbegin',row('بارنامه '+fmt(r.waybill.number),r.waybill.receiver));if(printOptions.on_receive){await showBill(r.waybill.id);window.addEventListener('afterprint',()=>go('scan'),{once:true});triggerPrint()}}
 }catch(err){$$('receiveFeedback').textContent=err.message}finally{if($$('receiveCode'))$$('receiveCode').focus()}}
function printManifest(m,label){const rows=m.bills.map(x=>'<tr><td>'+esc(fmt(x.number))+'</td><td>'+esc(x.receiver)+'</td><td>'+esc(fmt(x.pieces))+'</td></tr>').join('');
 const out=$$('manifestPrintRoot');out.innerHTML='<div class="manifest-print"><h1>اتوبنز وحدت — رسید '+esc(label)+'</h1><p>شماره محموله: '+fmt(m.number)+' | راننده: '+esc(m.first_name+' '+m.last_name)+' | مقصد: '+esc(m.destination)+'</p><table><thead><tr><th>بارنامه</th><th>گیرنده</th><th>بسته</th></tr></thead><tbody>'+rows+'</tbody></table><h3>جمع: '+fmt(m.waybill_count)+' بارنامه / '+fmt(m.piece_count)+' بسته</h3><p class="sign">امضای تحویل‌دهنده: .............................　　امضای تحویل‌گیرنده: .............................</p></div>';
 window.print();}
/* 1.5.3 – Persian calendar popup and native-independent 24-hour clock. */
const JALALI_MONTHS=['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
const WEEKDAY_LABELS=['ش','ی','د','س','چ','پ','ج'];
const persianDateNumber=v=>String(v).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
const persianPartsFormatter=new Intl.DateTimeFormat('en-US-u-ca-persian-nu-latn',{timeZone:'Asia/Tehran',year:'numeric',month:'numeric',day:'numeric'});
function persianDateParts(value){return Object.fromEntries(persianPartsFormatter.formatToParts(value).filter(x=>['year','month','day'].includes(x.type)).map(x=>[x.type,Number(x.value)]));}
function jalaliYearStart(y){
 for(let day=17;day<=25;day++){const dt=new Date(Date.UTC(y+621,2,day,12));const j=persianDateParts(dt);if(j.year===y&&j.month===1&&j.day===1)return Date.UTC(y+621,2,day,12);}
 throw Error('تقویم شمسی در این مرورگر پشتیبانی نمی‌شود.');
}
function jalaliDaysInMonth(y,m){return m<=6?31:m<=11?30:(jalaliYearStart(y+1)-jalaliYearStart(y))/86400000-336;}
const pad2=n=>String(n).padStart(2,'0');
function normalizeJalali(date){
 const p=String(date||'').split('/').map(Number);
 const y=p[0]||1405,m=p[1]||1,d=p[2]||1;
 return `${y}/${pad2(m)}/${pad2(d)}`;
}
function jalaliLong(date){const [y,m,d]=normalizeJalali(date).split('/').map(Number);return persianDateNumber(d)+' '+JALALI_MONTHS[m-1]+' '+persianDateNumber(y);}
let reportCalendarView={year:1405,month:8}, reportTodayJalali='', reportCalendarTarget='reportDate';
function reportDateValue(id='reportDate'){return $$(id)?.value||reportTodayJalali;}
function jalaliCalendarControl(date,id='reportDate'){
 const canonical=normalizeJalali(date),suffix=id==='reportDate'?'':'End';
 return '<div class="report-calendar-wrap" id="reportCalendarWrap'+suffix+'">'+
 '<input type="hidden" id="'+id+'" value="'+esc(canonical)+'">'+
 '<button type="button" id="reportCalendarOpen'+suffix+'" class="report-date-button" onclick="toggleReportCalendarFor(\''+id+'\')" aria-haspopup="dialog" aria-expanded="false" aria-controls="reportCalendarPanel"><span aria-hidden="true">▦</span><span id="'+id+'Text">'+esc(jalaliLong(canonical))+'</span><span aria-hidden="true">⌄</span></button>'+ (id==='reportDate'?(
 '<div class="report-calendar-backdrop" id="reportCalendarBackdrop" onclick="toggleReportCalendar(false)" hidden></div><div class="report-calendar" id="reportCalendarPanel" role="dialog" aria-label="تقویم شمسی گزارش مالی" hidden><div class="report-calendar-header">'+
 '<button type="button" class="report-calendar-nav" onclick="shiftReportCalendar(-1)" aria-label="ماه قبل">❯</button>'+
 '<select id="calendarMonth" aria-label="ماه شمسی" onchange="changeReportCalendarView()">'+JALALI_MONTHS.map((v,i)=>'<option value="'+(i+1)+'">'+v+'</option>').join('')+'</select>'+
 '<select id="calendarYear" aria-label="سال شمسی" onchange="changeReportCalendarView()">'+Array.from({length:301},(_,i)=>i+1300).map(y=>'<option value="'+y+'">'+persianDateNumber(y)+'</option>').join('')+'</select>'+
 '<button type="button" class="report-calendar-nav" onclick="shiftReportCalendar(1)" aria-label="ماه بعد">❮</button></div>'+
 '<div class="report-calendar-days" id="reportCalendarDays"></div><div class="report-calendar-foot"><button type="button" onclick="selectReportCalendarToday()">امروز</button><button type="button" onclick="toggleReportCalendar(false)">بستن</button></div></div>'):'')+'</div>';
}
function toggleReportCalendarFor(id){
 const panel=$$('reportCalendarPanel'),wrap=$$(id==='reportDate'?'reportCalendarWrap':'reportCalendarWrapEnd');
 if(!panel||!wrap)return;
 const open=!panel.hidden;
 if(open&&reportCalendarTarget===id){toggleReportCalendar(false);return;}
 reportCalendarTarget=id;
 // Keep a single calendar UI, moving it beside whichever date field was clicked.
 wrap.appendChild($$('reportCalendarBackdrop'));wrap.appendChild(panel);
 toggleReportCalendar(true);
}
function reportCalendarRender(){
 const panel=$$('reportCalendarPanel');if(!panel||panel.hidden)return;
 const y=reportCalendarView.year,m=reportCalendarView.month;
 $$('calendarYear').value=String(y);$$('calendarMonth').value=String(m);
 const chosen=reportDateValue(reportCalendarTarget);const total=jalaliDaysInMonth(y,m);
 const start=jalaliYearStart(y)+(m<=6?(m-1)*31:186+(m-7)*30)*86400000;
 const offset=(new Date(start).getUTCDay()+1)%7;
 const cells=WEEKDAY_LABELS.map(day=>'<span class="cal-weekday">'+day+'</span>');
 for(let i=0;i<offset;i++)cells.push('<span class="cal-empty"></span>');
 for(let d=1;d<=total;d++){
  const key=`${y}/${pad2(m)}/${pad2(d)}`;
  const selected=key===chosen, today=key===reportTodayJalali;
  cells.push('<button type="button" class="cal-day'+(selected?' selected':'')+(today?' today':'')+'" aria-label="'+esc(jalaliLong(key))+'" aria-pressed="'+selected+'" onclick="selectReportCalendarDay('+d+')">'+persianDateNumber(d)+'</button>');
 }
 $$('reportCalendarDays').innerHTML=cells.join('');
}
function toggleReportCalendar(force){
 const panel=$$('reportCalendarPanel'),trigger=$$(reportCalendarTarget==='reportDate'?'reportCalendarOpen':'reportCalendarOpenEnd');if(!panel||!trigger||(trigger.disabled&&force!==false))return;
 const open=typeof force==='boolean'?force:panel.hidden;
 if(open){const [y,m]=reportDateValue(reportCalendarTarget).split('/').map(Number);reportCalendarView={year:y,month:m};}
 panel.hidden=!open;const backdrop=$$('reportCalendarBackdrop');if(backdrop)backdrop.hidden=!open;['reportCalendarOpen','reportCalendarOpenEnd'].forEach(x=>{if($$(x))$$(x).setAttribute('aria-expanded',String(open&&$$(x)===trigger))});
 if(open)reportCalendarRender();
}
function changeReportCalendarView(){reportCalendarView={year:Number($$('calendarYear').value),month:Number($$('calendarMonth').value)};reportCalendarRender();}
function shiftReportCalendar(offset){let {year,month}=reportCalendarView;month+=offset;if(month<1){month=12;year--}if(month>12){month=1;year++}if(year<1300||year>1600)return;reportCalendarView={year,month};reportCalendarRender();}
function selectReportCalendarDay(d){
 const date=`${reportCalendarView.year}/${pad2(reportCalendarView.month)}/${pad2(d)}`;
 $$(reportCalendarTarget).value=date;$$(reportCalendarTarget+'Text').textContent=jalaliLong(date);
 if($$('reportMode').value!=='range')$$('reportMode').value='date';
 toggleReportCalendar(false);toggleReportDate();reportTimeValidation();
}
function selectReportCalendarToday(){const [y,m,d]=reportTodayJalali.split('/').map(Number);reportCalendarView={year:y,month:m};selectReportCalendarDay(d);}
document.addEventListener('click',e=>{const panel=$$('reportCalendarPanel'),wrap=$$(reportCalendarTarget==='reportDate'?'reportCalendarWrap':'reportCalendarWrapEnd');if(wrap&&panel&&!panel.hidden&&!wrap.contains(e.target))toggleReportCalendar(false)});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$$('reportCalendarPanel')&&!$$('reportCalendarPanel').hidden){toggleReportCalendar(false); $$(reportCalendarTarget==='reportDate'?'reportCalendarOpen':'reportCalendarOpenEnd')?.focus();}});
function reportTimeControl(id,label,value){
 const [hour,minute]=value.split(':');
 const hours=Array.from({length:24},(_,i)=>'<option value="'+pad2(i)+'" '+(pad2(i)===hour?'selected':'')+'>'+persianDateNumber(pad2(i))+'</option>').join('');
 const minutes=Array.from({length:60},(_,i)=>'<option value="'+pad2(i)+'" '+(pad2(i)===minute?'selected':'')+'>'+persianDateNumber(pad2(i))+'</option>').join('');
 return '<div class="field report-clock-field"><label id="'+id+'Label">'+label+'</label><input type="hidden" id="'+id+'" value="'+value+'">'+
 '<div class="report-clock" role="group" aria-labelledby="'+id+'Label"><span class="report-clock-symbol" aria-hidden="true">◷</span>'+
 '<select id="'+id+'Hour" aria-label="ساعت '+label+'" onchange="updateReportTime(\''+id+'\')">'+hours+'</select>'+
 '<span class="report-clock-colon">:</span><select id="'+id+'Minute" aria-label="دقیقه '+label+'" onchange="updateReportTime(\''+id+'\')">'+minutes+'</select></div></div>';
}
function updateReportTime(id){const hour=$$(id+'Hour').value,minute=$$(id+'Minute').value;$$(''+id).value=hour+':'+minute;reportTimePresetHighlight();reportTimeValidation();}
function reportPreset(name){
 const presets={all:['00:00','23:59'],morning:['08:00','13:59'],afternoon:['14:00','21:59']};
 const v=presets[name];if(!v)return;
 [['reportFrom',v[0]],['reportTo',v[1]]].forEach(([id,time])=>{$$(id).value=time;$$(''+id+'Hour').value=time.slice(0,2);$$(''+id+'Minute').value=time.slice(3)});
 reportTimePresetHighlight();reportTimeValidation();
}
function reportTimePresetHighlight(){document.querySelectorAll('.report-preset').forEach(btn=>{
 const [from,to]=btn.dataset.times.split(',');btn.classList.toggle('active',$$('reportFrom')?.value===from&&$$('reportTo')?.value===to);
 });}
function reportTimeValidation(){
 const from=$$('reportFrom')?.value||'00:00',to=$$('reportTo')?.value||'23:59';
 const mode=$$('reportMode')?.value||'today';
 let ok=true,message='';
 if(mode==='range'){
  const start=reportDateValue(),end=reportDateValue('reportRangeEndDate');
  if(start>end){ok=false;message='تاریخ پایان نباید قبل از تاریخ شروع باشد.';}
  else if(start===end&&from>to){ok=false;message='در یک روز، ساعت پایان نمی‌تواند قبل از ساعت شروع باشد.';}
 }else if(mode!=='all'&&from>to){ok=false;message='ساعت پایان نمی‌تواند قبل از ساعت شروع باشد.';}
 const hint=$$('reportTimeError');if(hint){hint.hidden=ok;hint.textContent=message;}
 ['reportDetailedPrintButton','reportShowButton','reportExcelButton'].forEach(id=>{const el=$$(id);if(el)el.disabled=!ok});
 return ok;
}
function reportFilters(today,employees){
 const empOptions='<option value="">همه کارمندان</option><option value="unassigned">کارمند ثبت‌نشده (سوابق قدیمی)</option>'+
 employees.map(u=>'<option value="'+esc(u.id)+'">'+esc(u.name)+(u.enabled?'':' (غیرفعال)')+'</option>').join('');
 return '<div class="report-filters">'+
 '<div class="field"><label for="reportMode">دوره گزارش</label><select id="reportMode" onchange="toggleReportDate();reportTimeValidation()"><option value="today">امروز</option><option value="date">تاریخ مشخص</option><option value="range">بازه تاریخ شمسی</option><option value="all">همه تاریخ‌ها</option></select></div>'+
 '<div class="field"><label id="reportDateLabel" for="reportCalendarOpen">تاریخ شمسی</label>'+jalaliCalendarControl(today)+'</div>'+
 '<div class="field report-range-end-field" id="reportRangeEndField" hidden><label for="reportCalendarOpenEnd">تا تاریخ شمسی</label>'+jalaliCalendarControl(today,'reportRangeEndDate')+'</div>'+
 '<div class="field report-employee-field"><label for="reportEmployee">کارمند ثبت‌کننده</label><select id="reportEmployee">'+empOptions+'</select></div>'+
 reportTimeControl('reportFrom','از ساعت (تهران)','00:00')+reportTimeControl('reportTo','تا ساعت (تهران)','23:59')+
 '</div><div class="report-time-presets" role="group" aria-label="بازه‌های زمانی آماده">'+
 '<button type="button" class="report-preset" data-times="00:00,23:59" onclick="reportPreset(\'all\')">تمام روز</button>'+
 '<button type="button" class="report-preset" data-times="08:00,13:59" onclick="reportPreset(\'morning\')">صبح</button>'+
 '<button type="button" class="report-preset" data-times="14:00,21:59" onclick="reportPreset(\'afternoon\')">بعدازظهر</button></div><p id="reportTimeError" class="report-time-error" role="alert" hidden></p>';
}
async function pageReports(){
 const [initial,employeeData]=await Promise.all([apiCall('/api/reports-v2?mode=today'),apiCall('/api/report-employees')]);reportTodayJalali=normalizeJalali(initial.today_jalali);reportCalendarTarget='reportDate';
 state.page='reports';nav('reports');set(title('گزارش مالی روز و ساعت')+card(reportFilters(reportTodayJalali,employeeData.items||[])+
 '<div class="report-actions"><button class="btn" id="reportShowButton" onclick="loadV2Report()">نمایش گزارش</button>'+
 '<button class="btn secondary report-print-button" id="reportDetailedPrintButton" type="button" onclick="printDetailedReport()">'+icon('print')+' چاپ کامل گزارش مالی A4 افقی</button>'+
 '<button class="btn secondary" id="reportExcelButton" type="button" onclick="exportReportExcel()">خروجی اکسل XLSX</button></div>'+
 '<p class="report-print-hint">چاپ بر اساس فیلتر تاریخ و ساعت همین صفحه است. ابتدا پیش‌نمایش باز می‌شود.</p>')+'<div id="reportView"></div>');
 toggleReportDate();reportTimePresetHighlight();reportTimeValidation();await loadV2Report(initial);
}
function validateReportFilters(){
 if(!reportTimeValidation()){throw Error('ساعت پایان نمی‌تواند قبل از ساعت شروع باشد.');}
 const mode=$$('reportMode').value;
 return new URLSearchParams({mode:mode,date:reportDateValue(),from_date:reportDateValue(),to_date:reportDateValue('reportRangeEndDate'),from:$$('reportFrom').value,to:$$('reportTo').value,employee_id:$$('reportEmployee')?.value||''});
}
function exportReportExcel(){try{
 const target='/api/reports/export.xlsx?'+validateReportFilters().toString();
 window.location.assign(target);
 }catch(err){fail(err)}
}
function printDetailedReport(){try{
 const target='/reports/print?'+validateReportFilters().toString();
 const tab=window.open(target,'_blank');if(!tab)window.location.assign(target);
 }catch(err){fail(err)}
}
function toggleReportDate(){
 const mode=$$('reportMode')?.value;
 const isRange=mode==='range',noDate=mode==='all';
 const btn=$$('reportCalendarOpen'),end=$$('reportCalendarOpenEnd');
 if(btn)btn.disabled=mode==='today'||noDate;
 if(end)end.disabled=!isRange;
 const endField=$$('reportRangeEndField');if(endField)endField.hidden=!isRange;
 const firstLabel=$$('reportDateLabel');if(firstLabel)firstLabel.textContent=isRange?'از تاریخ شمسی':'تاریخ شمسی';
 if(noDate||mode==='today')toggleReportCalendar(false);
 ['reportFromHour','reportFromMinute','reportToHour','reportToMinute'].forEach(id=>{const el=$$(id);if(el)el.disabled=noDate});
 document.querySelectorAll('.report-preset').forEach(btn=>btn.disabled=noDate);
 if(mode==='today'){
  const input=$$('reportDate');if(input){input.value=reportTodayJalali;$$('reportDateText').textContent=jalaliLong(reportTodayJalali);}
 }
 reportTimeValidation();
}
async function loadV2Report(cached){try{
 const params=validateReportFilters();
 let r=cached||await apiCall('/api/reports-v2?'+params.toString());let t=r.totals;
 let cards=[['پیش‌کرایه',t.prepaid],['پس‌کرایه',t.post_fare],['انبارداری',t.storage_fee],['سایر هزینه‌ها',t.other_fee],['سهم رانندگان',t.driver_share],['سهم شرکت',t.company_share]];
 const dateLabel=r.mode==='all'?'تمام تاریخ‌ها':r.mode==='range'?(persianDateNumber(r.from_date_jalali)+' تا '+persianDateNumber(r.to_date_jalali)):persianDateNumber(r.date_jalali);
 $$('reportView').innerHTML='<div class="report-range-label">گزارش '+esc(dateLabel)+(r.mode==='all'?'':' | از ساعت '+esc(persianDateNumber(r.time_from))+' تا '+esc(persianDateNumber(r.time_to)))+' | کارمند: '+esc(r.employee_name||'همه کارمندان')+'</div>'+ 
 '<div class="finance-grid">'+cards.map(x=>'<div class="stat"><small>'+esc(x[0])+'</small><strong>'+esc(textMoney(x[1]))+'</strong></div>').join('')+'</div>'+
 card(section('reports','خلاصه عملیات')+row('تعداد بارنامه صادرشده',fmt(t.issued))+row('جمع مبلغ بارنامه‌ها',textMoney(t.total))+row('محموله تحویل راننده',fmt(t.handover_count))+row('دریافت محموله در مقصد',fmt(t.received_manifests))+row('تسویه پولی رانندگان',textMoney(t.settled_cash))+row('تسویه با مسافر',textMoney(t.settled_passenger)))+
 card(section('reports','گزارش ساعتی صدور')+'<div class="tablewrap"><table><thead><tr><th>ساعت</th><th>بارنامه</th><th>پیش‌کرایه</th><th>پس‌کرایه</th><th>انبارداری</th><th>سایر هزینه‌ها</th></tr></thead><tbody>'+r.hourly.map(x=>'<tr><td>'+esc(persianDateNumber(x.hour))+'</td><td>'+fmt(x.issued)+'</td><td>'+fmt(x.prepaid)+'</td><td>'+fmt(x.post_fare)+'</td><td>'+fmt(x.storage_fee)+'</td><td>'+fmt(x.other_fee)+'</td></tr>').join('')+'</tbody></table></div>');
 }catch(err){fail(err)}
}
async function pageUsers(){const r=await apiCall('/api/users');const options=Object.keys(ROLE_LABEL).map(k=>'<option value="'+k+'">'+ROLE_LABEL[k]+'</option>').join('');
 set(title('کاربران و دسترسی‌ها')+card(section('settings','افزودن کاربر')+'<form onsubmit="saveUser(event)"><div class="fields">'+field('userName','نام و نام خانوادگی','')+field('userMobile','موبایل','','type="tel"')+
 '<div class="field"><label>نقش و دسترسی</label><select id="userRole">'+options+'</select></div><div class="field"><label>رمز عبور (حداقل ده کاراکتر)</label><input id="userPassword" type="password" minlength="10" autocomplete="new-password"></div></div><button class="btn">افزودن کاربر</button></form>')+
 card(section('list','حساب‌های تعریف‌شده')+'<div class="tablewrap"><table><thead><tr><th>نام</th><th>موبایل</th><th>نقش</th><th>وضعیت</th><th></th></tr></thead><tbody>'+r.items.map(u=>'<tr><td>'+esc(u.name)+'</td><td>'+esc(u.mobile)+'</td><td><select id="role-'+esc(u.id)+'">'+Object.entries(ROLE_LABEL).map(x=>'<option value="'+x[0]+'" '+(x[0]===u.role?'selected':'')+'>'+x[1]+'</option>').join('')+'</select></td><td><input type="checkbox" id="enabled-'+esc(u.id)+'" '+(u.enabled?'checked':'')+'></td><td><details class="permissions-panel"><summary>مجوزها</summary><label><input type="checkbox" id="useCustom-'+esc(u.id)+'" '+(u.custom?'checked':'')+'> دسترسی اختصاصی</label><div class="permission-items">'+Object.entries(PERM_LABEL).map(p=>'<label><input type="checkbox" class="permission-'+esc(u.id)+'" value="'+p[0]+'" '+(u.permissions.includes(p[0])?'checked':'')+'> '+p[1]+'</label>').join('')+'</div></details><button class="btn secondary" data-id="'+esc(u.id)+'" onclick="updateUser(this.dataset.id)">ذخیره</button></td></tr>').join('')+'</tbody></table></div>')+
 '<div class="message">نقش‌ها در سرور اعمال می‌شوند. ورود پیامکی فعلاً فعال نیست؛ کاربر با موبایل و رمز وارد می‌شود.</div>')}
async function saveUser(e){e.preventDefault();try{await post('/api/users',{name:$$('userName').value,mobile:$$('userMobile').value,role:$$('userRole').value,password:$$('userPassword').value});await pageUsers()}catch(err){fail(err)}}
async function updateUser(id){try{const custom=$$('useCustom-'+id).checked;
 const permissions=custom?[...document.querySelectorAll('.permission-'+CSS.escape(id)+':checked')].map(x=>x.value):null;
 await post('/api/users/'+encodeURIComponent(id)+'/change',{role:$$('role-'+id).value,enabled:$$('enabled-'+id).checked,permissions});await pageUsers()}catch(err){fail(err)}}
async function savePrintOptions(){try{const d={};['on_issue','on_handover','on_receive'].forEach(k=>d[k]=$$(k).checked);printOptions=await post('/api/print-settings',d);alert('تنظیمات چاپ ذخیره شد.')}catch(err){fail(err)}}
// Original static menu is preserved, extra operational screens are inserted alongside it.
(function installNav(){const side=document.querySelector('.side');if(!side)return;
 const before=$$('nav-list');[['drivers','رانندگان','route'],['handover','تحویل به راننده','box'],['settlement','تسویه راننده','money']].forEach(([p,t,i])=>{
  const b=document.createElement('button');b.type='button';b.className='nav';b.id='nav-'+p;b.onclick=()=>go(p);
  b.innerHTML='<span class="sym">'+icon(i)+'</span><span class="text">'+t+'</span>';
  side.insertBefore(b,before);});
 const users=document.createElement('button');users.type='button';users.className='nav';users.id='nav-users';users.onclick=()=>go('users');users.innerHTML='<span class="sym">'+icon('settings')+'</span><span class="text">کاربران</span>';side.insertBefore(users,$$('nav-settings'));
 const logout=document.createElement('button');logout.type='button';logout.className='nav nav-logout';logout.id='logoutButton';logout.onclick=logOut;logout.textContent='خروج';side.appendChild(logout);
})();
bootstrapUI();
