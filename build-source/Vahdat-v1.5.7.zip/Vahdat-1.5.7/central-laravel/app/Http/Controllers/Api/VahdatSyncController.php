<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\VahdatTracking;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Throwable;

/** Branch-to-hub relay; the hub is only for synchronization, never local ticket sales. */
final class VahdatSyncController extends Controller
{
    private const KINDS = ['waybill_issued', 'manifest_created', 'waybill_received',
                           'waybill_delivered', 'settlement_created'];

    private function branch(Request $request): ?object
    {
        $id = (string) $request->header('X-Vahdat-Branch', '');
        $token = (string) $request->bearerToken();
        if (!preg_match('/^[a-z][a-z0-9_-]{1,47}$/', $id) || strlen($token) < 32) return null;
        $branch = DB::table('vahdat_sync_branches')->where('id', $id)->where('enabled', true)->first();
        if (!$branch || !hash_equals((string) $branch->token_sha256, hash('sha256', $token))) return null;
        return $branch;
    }

    private function destination(string $target): ?object
    {
        return DB::table('vahdat_sync_branches')->where('enabled', true)
            ->where(fn($q) => $q->where('id', $target)->orWhere('name', $target))->first();
    }

    private function contact(string $id, string $kind): void
    {
        $fields = ['last_seen_at' => now()];
        if ($kind === 'push') $fields['last_push_at'] = now();
        if ($kind === 'pull') $fields['last_pull_at'] = now();
        DB::table('vahdat_sync_branches')->where('id', $id)->update($fields);
    }

    /** Authenticated branch receives only its permitted destinations plus its own identity. */
    public function catalog(Request $request): JsonResponse
    {
        $branch = $this->branch($request);
        if (!$branch) return response()->json(['error' => 'Unauthorized branch'], 401);
        $branches = DB::table('vahdat_sync_routes as r')
            ->join('vahdat_sync_branches as b', 'b.id', '=', 'r.destination_id')
            ->where('r.origin_id', $branch->id)->where('r.enabled', true)->where('b.enabled', true)
            ->orderBy('b.name')->get(['b.id', 'b.name']);
        $inbound = DB::table('vahdat_sync_routes as r')
            ->join('vahdat_sync_branches as b', 'b.id', '=', 'r.origin_id')
            ->where('r.destination_id', $branch->id)->where('b.enabled', true)
            ->get(['b.id', 'b.name']);
        $peers = $branches->concat($inbound)->unique('id')->values();
        $this->contact($branch->id, 'catalog');
        return response()->json(['branch' => ['id' => $branch->id, 'name' => $branch->name],
            'destinations' => $branches->map(fn($b) => ['id' => $b->id, 'name' => $b->name])->all(),
            'peers' => $peers->map(fn($b) => ['id' => $b->id, 'name' => $b->name])->all()]);
    }

    public function heartbeat(Request $request): JsonResponse
    {
        $branch = $this->branch($request);
        if (!$branch) return response()->json(['error' => 'Unauthorized branch'], 401);
        $v = Validator::make($request->all(), [
            'pending' => 'required|integer|min:0|max:10000000',
            'conflicts' => 'required|integer|min:0|max:10000000',
            'provisional' => 'required|integer|min:0|max:10000000',
            'version' => 'nullable|string|max:60',
        ]);
        if ($v->fails()) return response()->json(['error' => 'Bad heartbeat'], 422);
        $s = $v->validated();
        DB::table('vahdat_sync_branches')->where('id', $branch->id)->update([
            'last_seen_at' => now(), 'last_heartbeat_at' => now(),
            'pending_outbox' => $s['pending'], 'conflicts' => $s['conflicts'],
            'provisional_receipts' => $s['provisional'],
            'client_version' => ($s['version'] ?? null),
        ]);
        return response()->json(['ok' => true]);
    }

    public function push(Request $request): JsonResponse
    {
        $branch = $this->branch($request);
        if (!$branch) return response()->json(['error' => 'Unauthorized branch'], 401);
        if (strlen((string) $request->getContent()) > 1000000)
            return response()->json(['error' => 'Batch too large'], 413);
        $validator = Validator::make($request->all(), [
            'events' => 'required|array|min:1|max:100',
            'events.*.id' => 'required|string|max:80|regex:/^E-[0-9a-f]{32}$/',
            'events.*.kind' => 'required|string|in:' . implode(',', self::KINDS),
            'events.*.target' => 'required|string|max:180',
            'events.*.payload' => 'required|array',
            'events.*.created_at' => 'required|integer|min:1',
        ]);
        if ($validator->fails()) return response()->json(['error' => 'Invalid batch'], 422);
        $accepted = [];
        try {
            DB::transaction(function () use ($validator, $branch, &$accepted) {
                foreach ($validator->validated()['events'] as $event) {
                    $kind = $event['kind'];
                    $payload = $event['payload'];
                    $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
                    $hash = hash('sha256', $json);
                    $old = DB::table('vahdat_sync_events')->where('event_id', $event['id'])->first();
                    // An already accepted operation remains ACK-able even if its route was revoked.
                    if ($old) {
                        if ($old->source_branch !== $branch->id || $old->kind !== $kind ||
                            $old->payload_sha256 !== $hash ||
                            !in_array($event['target'], [$old->target_branch_id, $old->target], true))
                            throw new \DomainException('Idempotency key reused with different data');
                        $accepted[] = $event['id'];
                        continue;
                    }
                    $destination = $this->destination($event['target']);
                    if (!$destination || $destination->id === $branch->id)
                        throw new \DomainException('Destination branch unavailable');
                    // Forward route grants shipment; acknowledgements may travel back along
                    // that authorized shipment route without allowing reverse shipments.
                    $backflow = in_array($kind, ['waybill_received', 'waybill_delivered'], true)
                        || ($kind === 'settlement_created' && ($payload['settlement']['side'] ?? '') === 'dest');
                    $routeOrigin = $backflow ? $destination->id : $branch->id;
                    $routeDestination = $backflow ? $branch->id : $destination->id;
                    $route = DB::table('vahdat_sync_routes')->where('origin_id', $routeOrigin)
                        ->where('destination_id', $routeDestination);
                    // Revoking future shipments must not block acknowledgements of cargo already sent.
                    if (!($backflow ? $route->exists() : $route->where('enabled', true)->exists()))
                        throw new \DomainException('Destination route not permitted');
                    if (in_array($kind, ['waybill_issued', 'manifest_created'], true)) {
                        $item = $kind === 'waybill_issued'
                            ? ($payload['waybill'] ?? []) : ($payload['manifest'] ?? []);
                        if (($item['destination'] ?? null) !== $destination->name)
                            throw new \DomainException('Destination mismatch');
                        if ($kind === 'waybill_issued' && ($item['origin'] ?? null) !== $branch->name)
                            throw new \DomainException('Origin mismatch');
                        if ($kind === 'manifest_created') {
                            if (!is_array($payload['waybills'] ?? null))
                                throw new \DomainException('Manifest bills missing');
                            foreach ($payload['waybills'] as $bill) {
                                if (($bill['origin'] ?? null) !== $branch->name ||
                                    ($bill['destination'] ?? null) !== $destination->name)
                                    throw new \DomainException('Manifest route mismatch');
                            }
                        }
                    }
                    if ($kind === 'waybill_received' || $kind === 'waybill_delivered') {
                        if (($payload['destination'] ?? $branch->name) !== $branch->name &&
                            $kind === 'waybill_received') throw new \DomainException('Receipt origin mismatch');
                    }
                    DB::table('vahdat_sync_events')->insert([
                        'event_id' => $event['id'], 'source_branch' => $branch->id,
                        'target' => $destination->name, 'target_branch_id' => $destination->id,
                        'kind' => $kind, 'payload' => $json, 'payload_sha256' => $hash,
                        'happened_at' => (int) $event['created_at'], 'created_at' => now(),
                    ]);
                    VahdatTracking::apply($kind, $payload, $branch, $destination);
                    $accepted[] = $event['id'];
                }
            }, 3);
        } catch (\DomainException $e) {
            return response()->json(['error' => $e->getMessage()], 409);
        } catch (Throwable $e) {
            report($e);
            return response()->json(['error' => 'Unable to store sync events'], 500);
        }
        $this->contact($branch->id, 'push');
        return response()->json(['accepted' => $accepted]);
    }

    public function pull(Request $request): JsonResponse
    {
        $branch = $this->branch($request);
        if (!$branch) return response()->json(['error' => 'Unauthorized branch'], 401);
        $validator = Validator::make($request->query(), [
            'cursor' => 'nullable|integer|min:0', 'limit' => 'nullable|integer|min:1|max:200',
        ]);
        if ($validator->fails()) return response()->json(['error' => 'Bad cursor'], 422);
        $cursor = (int) $request->query('cursor', 0);
        $limit = (int) $request->query('limit', 200);
        // Read max before rows: a concurrent insert cannot be skipped by cursor advancement.
        $max = (int) DB::table('vahdat_sync_events')->max('sequence');
        $events = DB::table('vahdat_sync_events as e')
            ->join('vahdat_sync_branches as src', 'src.id', '=', 'e.source_branch')
            ->where('e.sequence', '>', $cursor)->where('e.sequence', '<=', $max)
            ->where(fn($q) => $q->where('e.target_branch_id', $branch->id)
                ->orWhere(fn($legacy) => $legacy->whereNull('e.target_branch_id')->where('e.target', $branch->name)))
            ->where('e.source_branch', '!=', $branch->id)
            ->orderBy('e.sequence')->limit($limit)
            ->get(['e.sequence', 'e.event_id', 'e.kind', 'e.payload',
                   'e.source_branch', 'src.name as source_name']);
        $items = $events->map(fn($r) => [
            'sequence' => (int) $r->sequence, 'id' => $r->event_id,
            'kind' => $r->kind, 'source_branch_id' => $r->source_branch,
            'source_branch' => $r->source_name,
            'payload' => json_decode($r->payload, true),
        ])->all();
        $next = count($items) === $limit ? (int) end($items)['sequence'] : max($cursor, $max);
        $ack = min($cursor, $max);
        DB::table('vahdat_sync_branches')->where('id', $branch->id)
            ->where('last_ack_cursor', '<', $ack)->update(['last_ack_cursor' => $ack]);
        DB::table('vahdat_sync_branches')->where('id', $branch->id)->update([
            'last_seen_at' => now(), 'last_pull_at' => now(),
        ]);
        return response()->json(['events' => $items, 'next_cursor' => $next]);
    }
}
