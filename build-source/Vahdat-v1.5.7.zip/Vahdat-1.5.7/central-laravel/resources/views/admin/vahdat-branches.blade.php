<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>مدیریت شعبه‌ها | اتوبنز وحدت</title>
<style>
:root{--navy:#183357;--blue:#2868d8;--green:#0f856d;--ink:#26394f;--muted:#71829a;--border:#dce5f0;--bg:#f3f6fb}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.8 Tahoma,'Segoe UI',sans-serif}button,input{font:inherit}button{cursor:pointer}a{color:var(--blue)}
header{background:linear-gradient(125deg,#102744,#224774);color:white;padding:22px max(22px,calc((100vw - 1190px)/2));border-bottom:3px solid #e4ba55}
header h1{margin:0;font-size:24px}header p{margin:3px 0 0;color:#c8d6e8;font-size:13px}main{max-width:1210px;margin:auto;padding:24px 14px 70px}
.summary{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}.sumcard,.panel,.branch{background:#fff;border:1px solid var(--border);border-radius:16px;box-shadow:0 4px 16px #0a234008}.sumcard{padding:17px 20px}.sumcard strong{font-size:25px;display:block;color:var(--navy)}.muted{color:var(--muted);font-size:12px}
.panel{padding:22px;margin-top:20px}.panel h2{font-size:19px;margin:0 0 16px}.createform{display:grid;grid-template-columns:1fr 1fr auto;gap:12px;align-items:end}label{font-size:13px;font-weight:700;display:block;margin-bottom:5px;color:#425873}input[type=text]{width:100%;min-height:43px;padding:9px 12px;border:1px solid #cddbed;border-radius:9px;background:#fbfdff}input:focus{outline:2px solid #b2ccff;outline-offset:0}.btn{min-height:43px;border:0;border-radius:10px;padding:9px 18px;background:var(--blue);color:#fff;font-weight:bold;white-space:nowrap}.btn.ghost{background:#edf3ff;color:#1b518d;border:1px solid #d1e0f7}.btn.warn{background:#fff6e9;color:#a14c21;border:1px solid #f6dbb8}.btn.small{min-height:36px;font-size:12px;padding:6px 12px}.alerts{margin-bottom:16px;background:#e9f7f0;color:#126044;padding:13px 16px;border-radius:11px;border:1px solid #bce4d0}.alerts.error{background:#fff1f1;color:#8e2525;border-color:#edc2c2}.secret{padding:17px;border:2px dashed #d4ad55;background:#fffaf0;border-radius:12px;margin:15px 0;word-break:break-all}.secret code{direction:ltr;display:block;background:#fff;border:1px solid #e9d8a6;padding:10px;margin-top:8px;border-radius:8px;text-align:left;user-select:all;font-family:Consolas,monospace;font-size:14px}.tip{font-size:12px;color:#80642b}
.listhead{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:25px 2px 12px}.listhead h2{margin:0;font-size:20px}.list{display:grid;gap:16px}.branch{padding:20px}.branchhead{display:flex;gap:14px;justify-content:space-between;align-items:center;flex-wrap:wrap}.branchhead h3{font-size:19px;margin:0}.branchid{font:12px Consolas,monospace;background:#f1f5f9;border-radius:8px;padding:4px 10px;direction:ltr}.status{display:inline-flex;align-items:center;gap:6px;border-radius:20px;background:#f0f3f8;color:#516178;font-size:12px;padding:3px 9px;font-weight:bold}.status.online{background:#e3f7ef;color:#0d765b}.status.offline{background:#fff2e7;color:#995823}.status.disabled{background:#f2f2f3;color:#5e6470}.metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin:18px 0;padding:13px;border:1px solid var(--border);background:#f9fbff;border-radius:10px}.metric span{display:block;color:#708198;font-size:11px}.metric strong{display:block;font-size:16px}.controls{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px}.controls h4{margin:0 0 10px;font-size:14px}.settingsrow{display:flex;align-items:center;gap:12px;margin-top:9px}.settingsrow input[type=text]{flex:1}.checkboxes{display:flex;flex-wrap:wrap;gap:9px;margin-bottom:12px}.choice{display:flex;align-items:center;gap:7px;border:1px solid #dce6f2;border-radius:10px;background:#fff;padding:7px 11px;font-size:13px}.choice input{accent-color:var(--blue)}.footline{margin-top:18px;display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;border-top:1px solid var(--border);padding-top:14px}.dangertext{font-size:12px;color:#a84d32}.hide{display:none}
@media(max-width:800px){.controls{grid-template-columns:1fr}.metrics{grid-template-columns:repeat(3,minmax(0,1fr))}.createform{grid-template-columns:1fr 1fr}.createform button{grid-column:1/-1}}@media(max-width:520px){header{padding:17px}.summary{grid-template-columns:repeat(3,minmax(0,1fr));gap:7px}.sumcard{padding:9px}.sumcard strong{font-size:18px}.sumcard .muted{font-size:10px}.panel,.branch{padding:14px}.createform{grid-template-columns:1fr}.createform button{grid-column:auto}.metrics{grid-template-columns:repeat(2,minmax(0,1fr))}}
</style>
</head>
<body>
<header><h1>اتوبنز وحدت | مدیریت شعبه‌ها</h1><p>ثبت شعبه، مقصدهای مجاز، کلید ارتباط و وضعیت همگام‌سازی</p></header>
<main>
@if (session('branch_notice'))<div class="alerts">{{ session('branch_notice') }}</div>@endif
@if ($errors->any())<div class="alerts error" role="alert">{{ $errors->first() }}</div>@endif
@if ($secret = session('new_branch_secret'))
<div class="secret" role="status"><strong>کلید ارتباط شعبه {{ $secret['id'] }}</strong>
<p>این کلید فقط همین یک بار نمایش داده می‌شود. آن را فقط در فایل تنظیمات سرور شعبه وارد کنید؛ در پیام‌رسان یا اسکرین‌شات منتشر نکنید.</p>
<code id="oneTimeSecret">{{ $secret['token'] }}</code><p class="tip">با خروج از این صفحه، کلید خام دیگر قابل بازیابی نیست؛ فقط امکان صدور کلید جدید وجود دارد.</p></div>
@endif
<div class="summary">
  <div class="sumcard"><span class="muted">کل شعبه‌ها</span><strong>{{ number_format($total) }}</strong></div>
  <div class="sumcard"><span class="muted">متصل در حدود ۱۰۰ ثانیه اخیر</span><strong id="onlineCount">{{ number_format($onlineCount) }}</strong></div>
  <div class="sumcard"><span class="muted">عملیات معوق گزارش‌شده و دریافتی</span><strong id="totalPending">{{ number_format($totalPending) }}</strong></div>
</div>
<section class="panel"><h2>افزودن شعبه جدید</h2>
<form class="createform" method="post" action="{{ route('vahdat.branches.store') }}">@csrf
 <div><label for="newId">شناسه انگلیسی ثابت شعبه</label><input id="newId" name="id" type="text" dir="ltr" maxlength="48" required pattern="[a-z][a-z0-9_-]{1,47}" placeholder="qaemshahr" value="{{ old('id') }}"><div class="muted">بعد از ثبت تغییر نمی‌کند؛ فقط حروف کوچک، عدد، _ و -</div></div>
 <div><label for="newName">نام فارسی شعبه</label><input id="newName" name="name" type="text" maxlength="180" required placeholder="قائم‌شهر" value="{{ old('name') }}"></div>
 <button class="btn" type="submit">افزودن و ایجاد کلید امن</button>
</form></section>
<div class="listhead"><h2>شعبه‌های ثبت‌شده</h2><span class="muted">آخرین ارتباط از سرور شعبه دریافت می‌شود؛ اطلاعات نمایشی نیستند.</span></div>
<div class="list">
@forelse ($rows as $item)
@php($b = $item['branch'])
<article class="branch" data-branch="{{ $b->id }}">
 <div class="branchhead"><div><h3>{{ $b->name }}</h3><span class="branchid">{{ $b->id }}</span></div>
 <span class="status {{ !$b->enabled ? 'disabled' : ($item['online'] ? 'online' : 'offline') }}" data-status>{{ !$b->enabled ? 'غیرفعال' : ($item['online'] ? 'متصل' : 'آفلاین/نامشخص') }}</span></div>
 <div class="metrics">
  <div class="metric"><span>آخرین ارتباط</span><strong style="font-size:12px" data-last-seen="{{ $b->last_seen_at }}">{{ $b->last_seen_at ? 'در حال تبدیل تاریخ…' : 'هنوز متصل نشده' }}</strong></div>
  <div class="metric"><span>عملیات ارسال‌نشده در شعبه</span><strong data-metric="pending_outbox">{{ $b->pending_outbox ?? 'نامشخص' }}</strong></div>
  <div class="metric"><span>دریافتی در انتظار تأیید شعبه</span><strong data-metric="pending_incoming">{{ $item['pending_incoming'] }}</strong></div>
  <div class="metric"><span>بارنامه‌های صادرشده امروز</span><strong data-metric="shipments_sent_today">{{ $item['shipments_sent_today'] }}</strong></div>
  <div class="metric"><span>بارنامه‌های ورودی در انتظار دریافت</span><strong data-metric="shipments_expected">{{ $item['shipments_expected'] }}</strong></div>
  <div class="metric"><span>بارنامه‌های در راه به شعبه</span><strong data-metric="shipments_in_transit">{{ $item['shipments_in_transit'] }}</strong></div>
  <div class="metric"><span>بارنامه‌های دریافت‌شده امروز</span><strong data-metric="shipments_received_today">{{ $item['shipments_received_today'] }}</strong></div>
  <div class="metric"><span>ثبت دریافت امروز</span><strong>{{ $item['received_today'] }}</strong></div>
  <div class="metric"><span>مغایرت‌های گزارش‌شده</span><strong data-metric="conflicts">{{ $b->conflicts ?? 'نامشخص' }}</strong></div>
 </div>
 <div class="controls">
  <section><h4>نام و وضعیت شعبه</h4>
   <form method="post" action="{{ route('vahdat.branches.update', $b->id) }}">@csrf
    <label>نام نمایشی</label><input type="text" name="name" value="{{ $b->name }}" required maxlength="180">
    <div class="settingsrow"><input type="hidden" name="enabled" value="0">
    <label class="choice"><input type="checkbox" name="enabled" value="1" {{ $b->enabled ? 'checked' : '' }}>فعال باشد</label>
    <button class="btn small ghost" type="submit">ذخیره شعبه</button></div>
   </form>
   <p class="dangertext">غیرفعال‌کردن شعبه، اتصال آن را قطع می‌کند؛ بارنامه‌های قبلی حذف نمی‌شوند.</p>
  </section>
  <section><h4>شعبه‌های مجاز برای ارسال بار از {{ $b->name }}</h4>
   <form method="post" action="{{ route('vahdat.branches.routes', $b->id) }}">@csrf
    <div class="checkboxes">
      @foreach($branches as $dest)
        @if($dest->id !== $b->id)
          <label class="choice"><input type="checkbox" name="destinations[]" value="{{ $dest->id }}" {{ in_array($dest->id, $item['allowed'], true) ? 'checked' : '' }} {{ !$dest->enabled ? 'disabled' : '' }}>{{ $dest->name }}</label>
        @endif
      @endforeach
    </div>
    <button class="btn small" type="submit">ذخیره مقصدهای مجاز</button>
    <p class="muted">فقط این مقصدها در فرم صدور شعبه ظاهر خواهند شد. پاسخ دریافت بار از مسیر برگشت مجاز خواهد بود.</p>
   </form>
  </section>
 </div>
 <div class="footline"><span class="muted">نسخه برنامه شعبه: {{ $b->client_version ?: 'نامشخص' }}</span>
  <form method="post" action="{{ route('vahdat.branches.rotate', $b->id) }}" onsubmit="return confirm('کلید قبلی فوراً باطل می‌شود و باید روی سرور شعبه کلید جدید ثبت شود. ادامه می‌دهید؟')">@csrf
   <button type="submit" class="btn small warn">تعویض کلید ارتباط</button>
  </form>
 </div>
</article>
@empty
<div class="panel"><p>هنوز هیچ شعبه‌ای ثبت نشده است. نخستین شعبه را از فرم بالا ایجاد کنید.</p></div>
@endforelse
</div>
<p class="muted" style="margin-top:20px">«متصل» فقط به معنی ارتباط اخیر با مرکز است، نه تضمین سلامت کامل شعبه. شمار عملیات محلی بر اساس آخرین گزارش همان شعبه است و ممکن است قدیمی باشد. آمار ارسال و دریافت بر اساس بارنامه‌های معتبر ثبت‌شده در مرکز است و تا همگام‌سازی شعبه‌ها کامل نمی‌شود. ساعت‌ها به وقت تهران نمایش داده می‌شوند.</p>
</main>
<script>
const num=x=>Number(x??0).toLocaleString('fa-IR');
function faDate(value){if(!value)return 'هنوز متصل نشده';const t=new Date(value.replace(' ','T')+(value.includes('Z')?'':'Z'));return isNaN(t.getTime())?'نامشخص':t.toLocaleString('fa-IR-u-ca-persian',{timeZone:'Asia/Tehran',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false});}
function paintDates(){document.querySelectorAll('[data-last-seen]').forEach(el=>{el.textContent=faDate(el.dataset.lastSeen)})}paintDates();
async function refresh(){try{
const r=await fetch(@json(route('vahdat.branches.status')),{credentials:'same-origin',cache:'no-store',headers:{'Accept':'application/json'}});if(!r.ok)return;
const p=await r.json();let online=0,pending=0;
for(const b of p.branches){const node=[...document.querySelectorAll('[data-branch]')].find(x=>x.dataset.branch===b.id);if(!node)continue;
if(b.online)online++;pending+=(b.pending_outbox||0)+(b.pending_incoming||0);
const st=node.querySelector('[data-status]');st.textContent=!b.enabled?'غیرفعال':b.online?'متصل':'آفلاین/نامشخص';st.className='status '+(!b.enabled?'disabled':b.online?'online':'offline');
const seen=node.querySelector('[data-last-seen]');seen.dataset.lastSeen=b.last_seen_at||'';seen.textContent=faDate(b.last_seen_at);
for(const k of ['pending_incoming','pending_outbox','conflicts','shipments_sent_today','shipments_expected','shipments_in_transit','shipments_received_today']){const el=node.querySelector(`[data-metric="${k}"]`);if(el)el.textContent=b[k]===null?'نامشخص':num(b[k]);}}
document.getElementById('onlineCount').textContent=num(online);document.getElementById('totalPending').textContent=num(pending);
}catch(_){}}
setInterval(refresh,30000);
</script>
</body></html>
