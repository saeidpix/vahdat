<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('vahdat_sync_branches', function (Blueprint $table) {
            $table->timestamp('last_seen_at')->nullable();
            $table->timestamp('last_push_at')->nullable();
            $table->timestamp('last_pull_at')->nullable();
            $table->timestamp('last_heartbeat_at')->nullable();
            $table->timestamp('token_rotated_at')->nullable();
            $table->unsignedBigInteger('last_ack_cursor')->default(0);
            $table->unsignedInteger('pending_outbox')->nullable();
            $table->unsignedInteger('conflicts')->nullable();
            $table->unsignedInteger('provisional_receipts')->nullable();
            $table->string('client_version', 60)->nullable();
        });
        Schema::create('vahdat_sync_routes', function (Blueprint $table) {
            $table->string('origin_id', 48);
            $table->string('destination_id', 48);
            $table->boolean('enabled')->default(true);
            $table->timestamps();
            $table->primary(['origin_id', 'destination_id']);
            $table->foreign('origin_id')->references('id')->on('vahdat_sync_branches')->cascadeOnDelete();
            $table->foreign('destination_id')->references('id')->on('vahdat_sync_branches')->cascadeOnDelete();
        });
        Schema::table('vahdat_sync_events', function (Blueprint $table) {
            $table->string('target_branch_id', 48)->nullable()->after('target');
            $table->index(['target_branch_id', 'sequence'], 'vahdat_events_target_branch_seq');
        });
        // Preserve previous events. Their Persian names are translated to stable branch IDs once.
        foreach (DB::table('vahdat_sync_branches')->get(['id', 'name']) as $branch) {
            DB::table('vahdat_sync_events')->whereNull('target_branch_id')
                ->where('target', $branch->name)->update(['target_branch_id' => $branch->id]);
        }
    }
    public function down(): void
    {
        Schema::table('vahdat_sync_events', function (Blueprint $table) {
            $table->dropIndex('vahdat_events_target_branch_seq');
            $table->dropColumn('target_branch_id');
        });
        Schema::dropIfExists('vahdat_sync_routes');
        Schema::table('vahdat_sync_branches', function (Blueprint $table) {
            $table->dropColumn(['last_seen_at', 'last_push_at', 'last_pull_at', 'last_heartbeat_at',
                'token_rotated_at', 'last_ack_cursor', 'pending_outbox', 'conflicts',
                'provisional_receipts', 'client_version']);
        });
    }
};
