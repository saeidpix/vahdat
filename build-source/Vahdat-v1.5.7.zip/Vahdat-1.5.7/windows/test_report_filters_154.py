# -*- coding: utf-8 -*-
"""Run after Windows dependencies are installed: python windows/test_report_filters_154.py"""
import datetime as dt
import io
import pathlib
import sys
import tempfile
import unittest
import zipfile
import xml.etree.ElementTree as ET
sys.path.insert(0,str(pathlib.Path(__file__).parent))
import app as v

class Reports154Tests(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        v.DATA=pathlib.Path(tmp.name)
        v.DB=v.DATA/'test154.sqlite3'
        v.init()
        self.client=v.app.test_client()
        setup=self.client.post('/api/auth/bootstrap',json=dict(name='مدیر آزمون',mobile='09120000000',password='SecurePassword123!'))
        self.assertEqual(setup.status_code,200,setup.get_data(as_text=True))
        status=self.client.get('/api/auth/status').json
        self.uid=status['user']['id']
        self.headers={'X-CSRF-Token':status['csrf']}

    def test_range_employee_excel(self):
        payload=dict(destination='قائم‌شهر',sender='شرکت تست',receiver='گیرنده',pieces=2,prepaid=100000,post_fare=50000,storage_fee=5000,other_fee=1000)
        issue=self.client.post('/api/waybills',json=payload,headers=self.headers)
        self.assertEqual(issue.status_code,201,issue.get_data(as_text=True))
        bid=issue.json['waybill']['id']
        date_ms=issue.json['waybill']['created_at']
        y,m,d=v.local_date(date_ms)[:3]
        day=f'{y:04}/{m:02}/{d:02}'
        args=dict(mode='range',from_date=day,to_date=day,employee_id=self.uid)
        view=self.client.get('/api/reports-v2',query_string={**args,'include_items':'1'})
        self.assertEqual(view.status_code,200,view.get_data(as_text=True))
        self.assertEqual(view.json['totals']['issued'],1)
        self.assertEqual(view.json['totals']['total'],156000)
        self.assertEqual(view.json['items'][0]['created_by_name'],'مدیر آزمون')
        excel=self.client.get('/api/reports/export.xlsx',query_string=args)
        self.assertEqual(excel.status_code,200,excel.get_data(as_text=True)[:250])
        self.assertIn('spreadsheetml.sheet',excel.mimetype)
        with zipfile.ZipFile(io.BytesIO(excel.data)) as zip:
            self.assertIsNone(zip.testzip())
            for name in ('xl/workbook.xml','xl/worksheets/sheet1.xml','xl/worksheets/sheet2.xml','xl/worksheets/sheet3.xml'):
                ET.fromstring(zip.read(name))
        bad=self.client.get('/api/reports-v2',query_string=dict(mode='range',from_date=day,to_date='1400/01/01'))
        self.assertEqual(bad.status_code,400)

    def test_employee_endpoint_requires_reports_permission(self):
        req=self.client.get('/api/report-employees')
        self.assertEqual(req.status_code,200)
        self.assertTrue(any(x['id']==self.uid for x in req.json['items']))

if __name__=='__main__':unittest.main()
