/* Autobenz Vahdat 1.5.6 — settings presentation; existing APIs and authorization are retained. */
'use strict';
settingsForm = async function settingsRedesigned() {
  const settings = await apiCall('/api/settings');
  state.settings = settings;
  const central = !!settings.central_managed;
  let ps = null;
  let printError = '';
  try {
    ps = await apiCall('/api/print-settings');
    printOptions = ps;
  } catch (err) {
    printError = err.message || 'دریافت تنظیمات چاپ ممکن نشد.';
  }
  const destinations = Array.isArray(settings.destinations) ? settings.destinations : [];
  const branchName = settings.origin || '—';
  const branchId = settings.branch_id || '—';

  const destinationEditor = central
    ? '<div class="settings-notice is-info">'+icon('route')+'<div><strong>مقصدها از مرکز مدیریت می‌شوند</strong><p>فهرست زیر از مرکز دریافت و روی همین سرور ذخیره شده است؛ هنگام قطعی اینترنت نیز قابل استفاده خواهد بود.</p></div></div>'
    : '<div class="settings-add-destination"><div class="field"><label for="newdest">افزودن مقصد</label><input id="newdest" type="text" maxlength="120" placeholder="نام شهر مقصد را وارد کنید" autocomplete="off" onkeydown="if(event.key===\'Enter\'){event.preventDefault();addDest()}"></div><button type="button" class="btn secondary" onclick="addDest()">'+icon('new')+'افزودن</button></div>';

  const destinationActions = central
    ? '<p class="settings-helper">برای تغییر مسیرهای مجاز، از پنل مدیریت مرکزی شعبه‌ها استفاده کنید.</p>'
    : '<div class="settings-actions"><button class="btn" type="button" onclick="saveDest()">'+icon('save')+'ذخیره مقصدها</button><span>افزودن یا حذف مقصد تا زمان ذخیره روی سرور اعمال نمی‌شود.</span></div>';

  const printCard = ps ?
    '<div class="settings-print-options">'+[
      ['on_issue', 'صدور بارنامه', 'پس از ثبت موفق بارنامه، پنجره چاپ آن باز شود.'],
      ['on_handover', 'تحویل بار به راننده', 'پس از ثبت تحویل گروهی، رسید محموله آماده چاپ شود.'],
      ['on_receive', 'دریافت بار در مقصد', 'پس از ثبت دریافت، پنجره چاپ رسید باز شود.']
    ].map(function(option) {
      const checked = !!ps[option[0]];
      return '<label class="settings-print-choice" for="'+option[0]+'"><span class="settings-choice-copy"><strong>'+esc(option[1])+'</strong><small>'+esc(option[2])+'</small></span><input type="checkbox" id="'+option[0]+'" '+(checked?'checked':'')+' aria-label="'+esc(option[1])+'"><span class="settings-switch" aria-hidden="true"></span></label>';
    }).join('')+'</div><div class="settings-actions"><button class="btn" type="button" onclick="savePrintOptions()">'+icon('save')+'ذخیره تنظیمات چاپ</button></div>'
    : '<div class="settings-notice is-warning">'+icon('print')+'<div><strong>تنظیمات چاپ بارگذاری نشد</strong><p>'+esc(printError)+'</p><button type="button" class="btn secondary" onclick="settingsForm()">تلاش دوباره</button></div></div>';

  const backupButton = (typeof currentPerms !== 'undefined' && currentPerms.includes('backup'))
    ? '<a class="btn secondary settings-backup-link" href="/api/backup">'+icon('backup')+'دریافت نسخه پشتیبان</a>'
    : '<p class="settings-helper">دریافت فایل پشتیبان به مجوز مخصوص نیاز دارد.</p>';

  const html = title('تنظیمات')+
    '<div class="vahdat-settings">'+
      '<div class="settings-intro"><div><span class="settings-eyebrow">پیکربندی برنامه</span><h3>تنظیمات شعبه و عملیات</h3><p>مسیرهای ارسال، رفتار چاپ و اطلاعات این شعبه را از همین بخش مدیریت کنید.</p></div><span class="settings-branch-indicator">'+icon('route')+esc(branchName)+'</span></div>'+
      '<div class="settings-grid">'+
        '<div class="settings-main">'+
          '<section class="card settings-card" aria-labelledby="destinationsTitle"><div class="settings-card-heading"><span class="settings-card-symbol">'+icon('route')+'</span><div><h3 id="destinationsTitle">مقصدهای ارسال</h3><p>شهرهایی که این شعبه می‌تواند برای آن‌ها بارنامه صادر کند</p></div><span class="settings-counter">'+fmt(destinations.length)+' مقصد</span></div>'+
            destinationEditor+'<div id="destlist" class="destinations settings-destination-list" aria-live="polite"></div>'+destinationActions+
          '</section>'+
          '<section class="card settings-card" aria-labelledby="printSettingsTitle"><div class="settings-card-heading"><span class="settings-card-symbol is-green">'+icon('print')+'</span><div><h3 id="printSettingsTitle">چاپ فوری</h3><p>انتخاب کنید پس از کدام عملیات، پنجره چاپ باز شود</p></div></div>'+printCard+
            '<p class="settings-helper">چاپ فوری در این نسخه پنجره چاپ ویندوز یا مرورگر را باز می‌کند؛ چاپ بدون تأیید چاپگر هنوز فعال نیست.</p>'+ 
          '</section>'+
        '</div>'+
        '<aside class="settings-aside">'+
          '<section class="card settings-card" aria-labelledby="branchSettingsTitle"><div class="settings-card-heading"><span class="settings-card-symbol is-blue">'+icon('home')+'</span><div><h3 id="branchSettingsTitle">مشخصات شعبه</h3><p>اطلاعات شناسایی این سرور</p></div></div><div class="settings-detail-list">'+
             '<div><span>نام شعبه</span><strong>'+esc(branchName)+'</strong></div><div><span>شناسه ثابت شعبه</span><strong dir="ltr">'+esc(branchId)+'</strong></div><div><span>مدیریت مسیرها</span><strong class="settings-management-status">'+(central?'مرکزی':'محلی')+'</strong></div></div></section>'+
          '<section class="card settings-card" aria-labelledby="backupSettingsTitle"><div class="settings-card-heading"><span class="settings-card-symbol is-slate">'+icon('backup')+'</span><div><h3 id="backupSettingsTitle">پشتیبان‌گیری</h3><p>ذخیره نسخه‌ای از اطلاعات این شعبه</p></div></div><p class="settings-helper">فایل پشتیبان را در محلی امن و جدا از دستگاه اصلی نگهداری کنید.</p>'+backupButton+'</section>'+
          '<section class="card settings-card settings-about" aria-labelledby="aboutSettingsTitle"><div class="settings-card-heading"><span class="settings-card-symbol is-gold">'+icon('settings')+'</span><div><h3 id="aboutSettingsTitle">درباره برنامه</h3><p>اتوبنز وحدت · نسخه ۱.۵.۶ آزمایشی</p></div></div><div class="settings-developer"><span class="settings-developer-title">طراحی و برنامه‌نویسی</span><strong>سعید فداییان</strong><a href="https://www.saeidpix.ir" target="_blank" rel="noopener noreferrer" dir="ltr">www.saeidpix.ir</a><a href="tel:09126862669" dir="ltr">09126862669</a></div></section>'+
        '</aside>'+
      '</div>'+
    '</div>';
  set(html);
  renderDest();
};
