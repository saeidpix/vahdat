# -*- coding: utf-8 -*-
"""Hub/branch sync integration tests using only Python standard library.
Flask is not required for this focused replication test.
"""
import json
import pathlib
import sqlite3
import sys
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
sys.path.insert(0,str(pathlib.Path(__file__).parents[1]/'tools'))
import central_demo
import sync_engine as se

SCHEMA='''
CREATE TABLE IF NOT EXISTS waybills (
 id TEXT PRIMARY KEY, origin TEXT NOT NULL,destination TEXT NOT NULL,
 sender TEXT NOT NULL DEFAULT '',receiver TEXT NOT NULL DEFAULT '',phone TEXT NOT NULL DEFAULT '',
 pieces INTEGER NOT NULL DEFAULT 1,prepaid INTEGER NOT NULL DEFAULT 0,post_fare INTEGER NOT NULL DEFAULT 0,
 storage_fee INTEGER NOT NULL DEFAULT 0,other_fee INTEGER NOT NULL DEFAULT 0,total INTEGER NOT NULL DEFAULT 0,
 created_at INTEGER NOT NULL,received_at INTEGER,delivered_at INTEGER,delivered_to TEXT NOT NULL DEFAULT '',
 post_collected INTEGER NOT NULL DEFAULT 0,origin_here INTEGER NOT NULL DEFAULT 1,number INTEGER UNIQUE,
 sender_phone TEXT NOT NULL DEFAULT '',description TEXT NOT NULL DEFAULT '',manifest_id TEXT,
 pending_verification INTEGER NOT NULL DEFAULT 0,source_number INTEGER);
CREATE TABLE IF NOT EXISTS drivers(id TEXT PRIMARY KEY,first_name TEXT,last_name TEXT,mobile TEXT UNIQUE,
 enabled INTEGER NOT NULL DEFAULT 1,created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS manifests(id TEXT PRIMARY KEY,number INTEGER UNIQUE,driver_id TEXT,
 destination TEXT,created_at INTEGER,created_by TEXT,received_at INTEGER);
CREATE TABLE IF NOT EXISTS manifest_bills(manifest_id TEXT,waybill_id TEXT UNIQUE,PRIMARY KEY(manifest_id,waybill_id));
CREATE TABLE IF NOT EXISTS settlements(id TEXT PRIMARY KEY,manifest_id TEXT,side TEXT,cash INTEGER,
 passenger INTEGER,created_at INTEGER,created_by TEXT);
'''

class ManagedConnection(sqlite3.Connection):
    def __exit__(self, exc_type, exc, tb):
        try:return super().__exit__(exc_type, exc, tb)
        finally:self.close()

class SyncTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=pathlib.Path(self.temp.name)
        self.hub_db=str(self.root/'hub.sqlite3')
        central_demo.init_db(self.hub_db)
        self.server=ThreadingHTTPServer(('127.0.0.1',0),central_demo.handler_for(self.hub_db,{
            'tehran':('تهران','alpha-key-long-enough-for-testing-123456789'),
            'destination':('قائم‌شهر','beta-key-long-enough-for-testing-123456789')
        }))
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.addCleanup(self.server.server_close);self.addCleanup(self.server.shutdown)
        self.origin=self.make_branch('tehran','تهران','alpha-key-long-enough-for-testing-123456789')
        self.dest=self.make_branch('destination','قائم‌شهر','beta-key-long-enough-for-testing-123456789')
    def make_branch(self,branch_id,name,token):
        path=self.root/branch_id;path.mkdir()
        db=str(path/'db.sqlite3')
        c=sqlite3.connect(db)
        try:c.executescript(SCHEMA);se.migrate(c)
        finally:c.close()
        (path/'sync-config.json').write_text(json.dumps({
            'enabled':True,'branch_id':branch_id,'branch_name':name,
            'hub_url':'http://127.0.0.1:'+str(self.server.server_port), 'token':token
        },ensure_ascii=False),encoding='utf-8')
        def connect():
            c=sqlite3.connect(db,timeout=4,factory=ManagedConnection)
            c.row_factory=sqlite3.Row
            return c
        return connect,path
    def issue(self):
        conn,_=self.origin
        with conn() as c:
            c.execute('''INSERT INTO waybills(id,origin,destination,sender,receiver,phone,pieces,
               prepaid,post_fare,storage_fee,other_fee,total,created_at,number)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',(
                'VH-1762600000000-ABC123','تهران','قائم‌شهر','علی','رضا','09120000000',
                3,600000,400000,200000,0,1200000,1762600000000,187))
            se.queue_waybill(c,'VH-1762600000000-ABC123')
            c.commit()
    def dispatch(self):
        conn,_=self.origin
        with conn() as c:
            c.execute('INSERT INTO drivers(id,first_name,last_name,mobile,created_at) VALUES(?,?,?,?,?)',
                      ('D-001','علی','رضایی','09121231234',1762600000000))
            c.execute('INSERT INTO manifests(id,number,driver_id,destination,created_at) VALUES(?,?,?,?,?)',
                      ('M-001',1,'D-001','قائم‌شهر',1762600000100))
            c.execute('INSERT INTO manifest_bills(manifest_id,waybill_id) VALUES(?,?)',('M-001','VH-1762600000000-ABC123'))
            c.execute('UPDATE waybills SET manifest_id=? WHERE id=?',('M-001','VH-1762600000000-ABC123'))
            se.queue_manifest(c,'M-001');c.commit()
    def sync(self,branch):return se.sync_once(*branch)
    def test_issue_and_manifest_replicate_to_destination(self):
        self.issue();self.dispatch()
        a=self.sync(self.origin);self.assertTrue(a['ok'],a)
        b=self.sync(self.dest);self.assertTrue(b['ok'],b)
        c=self.dest[0]()
        try:
            row=c.execute('SELECT * FROM waybills').fetchone()
            self.assertEqual(row['id'],'VH-1762600000000-ABC123')
            self.assertEqual(row['source_number'],187)
            self.assertEqual(row['manifest_id'],'M-001')
            self.assertEqual(c.execute('SELECT COUNT(*) FROM drivers').fetchone()[0],1)
        finally:c.close()
        self.assertEqual(self.sync(self.dest)['received'],0)
    def test_receipt_flows_back_and_is_idempotent(self):
        self.issue();self.dispatch();self.sync(self.origin);self.sync(self.dest)
        with self.dest[0]() as c:
            c.execute('UPDATE waybills SET received_at=? WHERE id=?',(1762600000600,'VH-1762600000000-ABC123'))
            row=c.execute('SELECT * FROM waybills').fetchone()
            se.queue_received(c,row,row['received_at']);c.commit()
        self.assertTrue(self.sync(self.dest)['ok'])
        self.assertTrue(self.sync(self.origin)['ok'])
        with self.origin[0]() as c:
            self.assertEqual(c.execute('SELECT received_at FROM waybills').fetchone()[0],1762600000600)
        # Lost acknowledgement simulation: resend same ID; hub must not duplicate it.
        with self.dest[0]() as c:c.execute('UPDATE sync_outbox SET sent_at=NULL WHERE kind=?',('waybill_received',));c.commit()
        self.assertTrue(self.sync(self.dest)['ok'])
        c=sqlite3.connect(self.hub_db)
        try:self.assertEqual(c.execute("SELECT COUNT(*) FROM hub_events WHERE kind='waybill_received'").fetchone()[0],1)
        finally:c.close()
    def test_unknown_qr_stays_provisional_until_manifest_verifies(self):
        self.issue();self.dispatch()
        source=self.origin[0]()
        try:b=dict(source.execute('SELECT * FROM waybills').fetchone())
        finally:source.close()
        with self.dest[0]() as c:
            row,fresh=se.provisional_receive(c,'VHD1:demo',lambda _:b,'قائم‌شهر')
            self.assertTrue(fresh)
            self.assertEqual(row['pending_verification'],1)
            c.commit()
        self.sync(self.origin);self.sync(self.dest)
        with self.dest[0]() as c:
            self.assertEqual(c.execute('SELECT pending_verification FROM waybills').fetchone()[0],0)
            self.assertEqual(c.execute("SELECT COUNT(*) FROM sync_outbox WHERE kind='waybill_received'").fetchone()[0],1)
        self.sync(self.dest);self.sync(self.origin)
        with self.origin[0]() as c:
            self.assertIsNotNone(c.execute('SELECT received_at FROM waybills').fetchone()[0])
    def test_delivery_and_settlement_flow_back_to_origin(self):
        self.issue();self.dispatch();self.sync(self.origin);self.sync(self.dest)
        with self.dest[0]() as c:
            c.execute('INSERT INTO settlements(id,manifest_id,side,cash,passenger,created_at) VALUES(?,?,?,?,?,?)',
                      ('S-001','M-001','dest',120000,80000,1762600000700))
            se.queue_settlement(c,'S-001','تهران')
            c.execute('UPDATE waybills SET received_at=?,delivered_at=?,delivered_to=?,post_collected=? WHERE id=?',
                      (1762600000600,1762600000800,'رضا',400000,'VH-1762600000000-ABC123'))
            row=c.execute('SELECT * FROM waybills').fetchone()
            se.queue_received(c,row,row['received_at'])
            se.queue_delivered(c,row,row['delivered_at'],'رضا',400000)
            c.commit()
        self.assertTrue(self.sync(self.dest)['ok'])
        self.assertTrue(self.sync(self.origin)['ok'])
        with self.origin[0]() as c:
            b=c.execute('SELECT * FROM waybills').fetchone()
            self.assertEqual(b['delivered_to'],'رضا')
            self.assertEqual(b['post_collected'],400000)
            settlement=c.execute('SELECT * FROM settlements WHERE id=?',('S-001',)).fetchone()
            self.assertEqual((settlement['cash'],settlement['passenger']),(120000,80000))

    def test_modified_offline_qr_is_not_treated_as_verified(self):
        self.issue();self.dispatch()
        with self.origin[0]() as c:b=dict(c.execute('SELECT * FROM waybills').fetchone())
        forged=dict(b);forged['total']=999999
        with self.dest[0]() as c:
            se.provisional_receive(c,'VHD1:demo',lambda _:forged,'قائم‌شهر')
            c.commit()
        self.sync(self.origin);self.sync(self.dest)
        with self.dest[0]() as c:
            self.assertEqual(c.execute('SELECT pending_verification FROM waybills').fetchone()[0],1)
            self.assertGreater(c.execute('SELECT COUNT(*) FROM sync_conflicts').fetchone()[0],0)
            self.assertEqual(c.execute("SELECT COUNT(*) FROM sync_outbox WHERE kind='waybill_received'").fetchone()[0],0)

    def test_offline_does_not_lose_outbox(self):
        self.issue()
        cfg=self.origin[1]/'sync-config.json';j=json.loads(cfg.read_text());j['hub_url']='http://127.0.0.1:1'
        cfg.write_text(json.dumps(j,ensure_ascii=False),encoding='utf-8')
        res=self.sync(self.origin);self.assertFalse(res['ok'])
        with self.origin[0]() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM sync_outbox WHERE sent_at IS NULL').fetchone()[0],1)
        j['hub_url']='http://127.0.0.1:'+str(self.server.server_port)
        cfg.write_text(json.dumps(j,ensure_ascii=False),encoding='utf-8')
        self.assertTrue(self.sync(self.origin)['ok'])
        self.assertEqual(se.get_status(*self.origin)['pending'],0)
    def test_insecure_external_hub_rejected(self):
        cfg={'enabled':True,'hub_url':'http://example.org','branch_id':'tehran','branch_name':'تهران','token':'secret'}
        with self.assertRaises(ValueError):se.validate_config(cfg)

if __name__=='__main__':unittest.main()
