/* Vahdat 1.5.3-beta. Read-only printable report, sourced from one protected API snapshot. */
'use strict';
const $=id=>document.getElementById(id);
const digits=new Intl.NumberFormat('fa-IR',{useGrouping:true,maximumFractionDigits:0});
const fa=v=>digits.format(Number(v)||0);
const pt=v=>String(v==null?'':v).replace(/[0-9]/g,d=>'۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
const field=(id,value)=>{$(id).textContent=value==null?'—':String(value)};
const insertCells=(tr,values,numericIndices=[])=>{
  values.forEach((x,i)=>{const c=tr.insertCell();c.textContent=String(x==null?'—':x);if(numericIndices.includes(i))c.classList.add('num')});return tr;
};
function reportPeriod(r){
  if(r.mode==='all')return 'تمام تاریخ‌ها';
  if(r.mode==='range')return pt(r.from_date_jalali)+' تا '+pt(r.to_date_jalali)+' | ساعت '+pt(r.time_from)+' تا '+pt(r.time_to)+' به وقت تهران';
  return pt(r.date_jalali)+' | از ساعت '+pt(r.time_from)+' تا '+pt(r.time_to)+' به وقت تهران';
}
function addSummary(parent,label,amount,money=true){
  const el=document.createElement('div');el.className='summary-item';
  const a=document.createElement('span');a.className='label';a.textContent=label;
  const b=document.createElement('strong');b.className='amount';b.textContent=fa(amount)+(money?' تومان':'');
  el.append(a,b);parent.append(el);
}
function addOperation(label,value,money=false){
  const root=$('operations'),wrap=document.createElement('div');wrap.className='operation';
  const a=document.createElement('span');a.textContent=label;
  const b=document.createElement('strong');b.textContent=fa(value)+(money?' تومان':'');
  wrap.append(a,b);root.append(wrap);
}
function showReport(r){
  const t=r.totals||{};
  field('branch',r.branch_name||'نامشخص');field('range',reportPeriod(r));field('employee',r.employee_name||'همه کارمندان');
  field('operator',r.generated_by||'—');field('generatedAt',r.generated_at_fa||'—');
  const s=$('totals');s.replaceChildren();
  [['بارنامه صادرشده',t.issued,false],['جمع مبلغ بارنامه‌ها',t.total,true],
   ['جمع اصل کرایه',t.fare,true],['پیش‌کرایه',t.prepaid,true],
   ['پس‌کرایه',t.post_fare,true],['انبارداری',t.storage_fee,true],
   ['سایر هزینه‌ها',t.other_fee,true],['سهم رانندگان از کرایه',t.driver_share,true],
   ['سهم شرکت از کرایه',t.company_share,true]].forEach(x=>addSummary(s,x[0],x[1],x[2]));
  const items=r.items||[],tbody=$('detailRows');tbody.replaceChildren();
  const fragment=document.createDocumentFragment();
  for(let i=0;i<items.length;i++){
    const x=items[i];const tr=document.createElement('tr');
    const route=(x.origin||'')+' ← '+(x.destination||'');
    insertCells(tr,[fa(i+1),fa(x.number),x.created_at_fa||'',route,x.receiver||'—',fa(x.pieces),
      fa(x.prepaid),fa(x.post_fare),fa(x.storage_fee),fa(x.other_fee),fa(x.driver_share),fa(x.company_share),fa(x.total)],
      [0,1,5,6,7,8,9,10,11,12]);
    fragment.append(tr);
  }
  tbody.append(fragment);$('noRows').hidden=items.length!==0;
  const foot=$('detailFoot');foot.replaceChildren();
  const tr=document.createElement('tr');let label=document.createElement('td');label.colSpan=6;label.textContent='جمع مبلغ‌های ریز بارنامه‌ها';tr.append(label);
  [t.prepaid,t.post_fare,t.storage_fee,t.other_fee,t.driver_share,t.company_share,t.total].forEach(v=>{const td=document.createElement('td');td.textContent=fa(v);tr.append(td)});
  foot.append(tr);
  $('operations').replaceChildren();
  addOperation('محموله تحویل‌شده به راننده',t.handover_count);
  addOperation('محموله دریافت‌شده در مقصد',t.received_manifests);
  addOperation('تسویه نقدی / بانکی راننده',t.settled_cash,true);
  addOperation('تسویه از محل مسافر',t.settled_passenger,true);
  const h=$('hourRows');h.replaceChildren();
  if(!r.hourly||!r.hourly.length){const tr=document.createElement('tr');const c=tr.insertCell();c.colSpan=7;c.textContent='در این بازه، صدور بارنامه ثبت نشده است.';h.append(tr)}
  else r.hourly.forEach(x=>{const tr=document.createElement('tr');insertCells(tr,[pt(x.hour),fa(x.issued),fa(x.prepaid),fa(x.post_fare),fa(x.storage_fee),fa(x.other_fee),fa(x.total)],[1,2,3,4,5,6]);h.append(tr)});
  $('loading').hidden=true;$('report').hidden=false;$('printButton').disabled=false;
}
async function start(){
  const params=new URLSearchParams(location.search);
  const q=new URLSearchParams({mode:params.get('mode')||'today',date:params.get('date')||'',from_date:params.get('from_date')||'',to_date:params.get('to_date')||'',employee_id:params.get('employee_id')||'',from:params.get('from')||'00:00',to:params.get('to')||'23:59',include_items:'1'});
  try{
    const response=await fetch('/api/reports-v2?'+q.toString(),{credentials:'same-origin',cache:'no-store'});
    const kind=response.headers.get('Content-Type')||'';
    if(!kind.toLowerCase().includes('application/json')){
      throw Error('سرور به‌جای اطلاعات گزارش، پاسخ غیر JSON فرستاد (HTTP '+response.status+'). صفحه را دوباره باز کنید؛ اگر مشکل ادامه داشت، نسخه برنامه و گزارش خطا را بررسی کنید.');
    }
    let json;
    try{json=await response.json();}catch(_){throw Error('پاسخ JSON گزارش ناقص یا خراب است.');}
    if(!response.ok){
      if(response.status===401)throw Error('ابتدا در صفحه اصلی برنامه وارد حساب کاربری شوید.');
      if(response.status===403)throw Error('این حساب اجازه مشاهده گزارش مالی را ندارد.');
      throw Error(json.error||'دریافت اطلاعات گزارش ناموفق بود (HTTP '+response.status+').');
    }
    if(!json||!json.totals||!Array.isArray(json.items))throw Error('اطلاعات تفصیلی گزارش ناقص است.');
    showReport(json);
  }catch(error){$('loading').classList.add('error');$('loading').textContent=String(error.message||error)}
}
$('printButton').addEventListener('click',()=>window.print());
start();
