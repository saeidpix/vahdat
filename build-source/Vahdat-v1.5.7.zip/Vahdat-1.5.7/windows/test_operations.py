# -*- coding: utf-8 -*-
"""API regression tests for Windows 1.4: authentication, permissions and money flow."""
import os, pathlib, tempfile, unittest
import sys
sys.path.insert(0,str(pathlib.Path(__file__).parent))
import app as v

class OperationsTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        v.DATA=pathlib.Path(self.tmp.name);v.DB=v.DATA/'data.sqlite3'
        v.init();self.c=v.app.test_client()
        self.assertEqual(self.c.get('/api/waybills').status_code,401)
        r=self.c.post('/api/auth/bootstrap',json={'name':'مدیر','mobile':'09120000000','password':'SecurePass123!'})
        self.assertEqual(r.status_code,200,r.json)
        self.csrf=self.c.get('/api/auth/status').json['csrf']
    def post(self,path,**data):return self.c.post(path,json=data,headers={'X-CSRF-Token':self.csrf})
    def test_drivers_handover_settlement_and_barcode(self):
        r=self.post('/api/drivers',first_name='علی',last_name='رضایی',mobile='09121111111')
        self.assertEqual(r.status_code,201,r.json);driver=r.json['id']
        r=self.post('/api/waybills',destination='قائم‌شهر',sender='فرستنده',receiver='گیرنده',phone='09123333333',pieces=3,prepaid=600000,post_fare=400000,storage_fee=200000,other_fee=50000,sender_phone='09124444444',description='بار نمونه')
        self.assertEqual(r.status_code,201,r.json);bill=r.json['waybill'];bid=bill['id']
        self.assertEqual(bill['sender_phone'],'09124444444')
        self.assertEqual(bill['description'],'بار نمونه')
        self.assertIn('image/svg+xml',self.c.get('/api/barcode/'+bid).content_type)
        r=self.post('/api/manifests',driver_id=driver,destination='قائم‌شهر',waybill_ids=[bid])
        self.assertEqual(r.status_code,201,r.json)
        m=r.json['manifest'];mid=m['id']
        self.assertEqual(m['origin_share'],300000)
        self.assertEqual(m['dest_share'],200000)
        self.assertEqual(m['origin_remaining'],300000)
        self.assertEqual(self.post('/api/manifests',driver_id=driver,destination='قائم‌شهر',waybill_ids=[bid]).status_code,409)
        r=self.post('/api/manifests/'+mid+'/settlements',side='origin',cash=200000,passenger=100000)
        self.assertEqual(r.status_code,201,r.json)
        self.assertEqual(r.json['manifest']['origin_remaining'],0)
        self.assertEqual(self.post('/api/manifests/'+mid+'/settlements',side='origin',cash=1).status_code,409)
        self.assertEqual(self.post('/api/manifests/'+mid+'/settlements',side='dest',cash=150000,passenger=50000).status_code,201)
        r=self.post('/api/scan/receive',code=str(bill['number']))
        self.assertEqual(r.status_code,200,r.json)
        self.assertFalse(r.json['duplicate'])
        r=self.post('/api/scan/receive',code=str(bill['number']))
        self.assertTrue(r.json['duplicate'])
        m=self.c.get('/api/manifests/'+mid).json['manifest']
        self.assertIsNotNone(m['received_at'])
        report=self.c.get('/api/reports-v2?mode=all').json['totals']
        self.assertEqual(report['prepaid'],600000)
        self.assertEqual(report['post_fare'],400000)
        self.assertEqual(report['storage_fee'],200000)
        self.assertEqual(report['other_fee'],50000)
        self.assertEqual(report['driver_share'],500000)
        self.assertEqual(report['company_share'],500000)
        self.assertEqual(report['settled_cash'],350000)
        self.assertEqual(report['settled_passenger'],150000)
    def test_jalali_report_dates_and_boundaries(self):
        import datetime as dt
        # 1405/08/17 is 2026-11-08; verify timezone boundaries with +03:30.
        tz=dt.timezone(dt.timedelta(hours=3,minutes=30))
        b=self.post('/api/waybills',destination='قائم‌شهر',sender='آزمون',receiver='آزمون',
                    pieces=1,prepaid=400000,post_fare=200000,storage_fee=90000,other_fee=10000).json['waybill']
        with v.connect() as c:
            c.execute('UPDATE waybills SET created_at=? WHERE id=?',
                      (int(dt.datetime(2026,11,8,0,20,tzinfo=tz).timestamp()*1000),b['id']))
            c.commit()
        r=self.c.get('/api/reports-v2?mode=date&date=۱۴۰۵/۰۸/۱۷&from=00:00&to=00:30')
        self.assertEqual(r.status_code,200,r.json)
        self.assertEqual(r.json['date_jalali'],'1405/08/17')
        self.assertEqual(r.json['totals']['issued'],1)
        r=self.c.get('/api/reports-v2?mode=date&date=1405/08/17&from=00:21&to=23:59')
        self.assertEqual(r.status_code,200,r.json)
        self.assertEqual(r.json['totals']['issued'],0)
        self.assertEqual(self.c.get('/api/reports-v2?mode=date&date=1404/12/30').status_code,400)
        self.assertEqual(self.c.get('/api/reports-v2?mode=date&date=1403/12/30').status_code,200)
        self.assertEqual(self.c.get('/api/reports-v2?mode=today').status_code,200)
        self.assertIn('today_jalali',self.c.get('/api/reports-v2?mode=today').json)

    def test_user_roles_and_print_settings(self):
        r=self.post('/api/users',name='انباردار',mobile='09122222222',role='warehouse',password='GoodPassword111')
        self.assertEqual(r.status_code,201,r.json)
        self.assertEqual(self.post('/api/print-settings',on_issue=True,on_handover=False,on_receive=True).status_code,200)
        self.assertTrue(self.c.get('/api/print-settings').json['on_issue'])
        self.assertEqual(self.post('/api/users/'+self.c.get('/api/users').json['items'][0]['id']+'/change',role='viewer',enabled=False).status_code,409)
        self.assertEqual(self.c.get('/api/auth/status').json['authenticated'],True)
        self.assertEqual(self.post('/api/auth/logout').status_code,200)
        r=self.c.post('/api/auth/login',json={'mobile':'09122222222','password':'GoodPassword111'})
        self.assertEqual(r.status_code,200)
        self.csrf=self.c.get('/api/auth/status').json['csrf']
        self.assertEqual(self.c.get('/api/users').status_code,403)
        self.assertEqual(self.c.get('/api/drivers').status_code,200)
        self.assertEqual(self.post('/api/waybills',destination='قائم‌شهر').status_code,403)
        self.assertEqual(self.post('/api/print-settings',on_issue=False).status_code,403)
        self.assertEqual(self.post('/api/drivers',first_name='رضا',last_name='آ',mobile='09123334444').status_code,201)
    def test_custom_permissions_are_enforced_server_side(self):
        r=self.post('/api/users',name='کارمند محدود',mobile='09125555555',role='warehouse',
                    permissions=['drivers'],password='StrongPass12345')
        self.assertEqual(r.status_code,201,r.json)
        self.post('/api/auth/logout')
        r=self.c.post('/api/auth/login',json={'mobile':'09125555555','password':'StrongPass12345'})
        self.assertEqual(r.status_code,200)
        self.csrf=self.c.get('/api/auth/status').json['csrf']
        self.assertEqual(self.c.get('/api/drivers').status_code,200)
        self.assertEqual(self.c.get('/api/waybills').status_code,403)
        self.assertEqual(self.post('/api/waybills',destination='قائم‌شهر').status_code,403)
    def test_scan_rejects_undispatched_and_includes_qr(self):
        r=self.post('/api/waybills',destination='قائم‌شهر',prepaid=100000,post_fare=0)
        bid=r.json['waybill']['id']
        self.assertEqual(self.post('/api/scan/receive',code=str(r.json['waybill']['number'])).status_code,409)
        encoded=v.encode_qr(r.json['waybill'])
        lookup=self.post('/api/scan/lookup',code=encoded)
        self.assertEqual(lookup.status_code,200)
        self.assertEqual(lookup.json['waybill']['id'],bid)
        self.assertEqual(self.post('/api/scan/lookup',code='not-a-code').status_code,404)

if __name__=='__main__':unittest.main()
