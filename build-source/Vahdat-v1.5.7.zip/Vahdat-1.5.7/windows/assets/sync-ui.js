// An unobtrusive live sync indicator. UI is informative; only server controls syncing.
(function(){
  const style=document.createElement('style');
  style.textContent=`#vahdatSyncBadge{position:fixed;bottom:12px;left:12px;direction:rtl;z-index:9999;font:12px Vazirmatn,Tahoma,sans-serif;background:#fff;color:#24354b;padding:9px 12px;border:1px solid #d6e0e9;box-shadow:0 3px 14px #0001;border-radius:12px;max-width:280px}#vahdatSyncBadge[hidden]{display:none}#vahdatSyncBadge .dot{display:inline-block;border-radius:100%;width:8px;height:8px;margin-left:5px;background:#e1a837}#vahdatSyncBadge.online .dot{background:#16a34a}#vahdatSyncBadge.offline .dot{background:#e15e60}#vahdatSyncBadge small{display:block;color:#6b7280;font-size:10px;margin-top:3px}@media print{#vahdatSyncBadge{display:none!important}}`;
  document.head.appendChild(style);
  const el=document.createElement('div');el.id='vahdatSyncBadge';el.hidden=true;
  let latestCatalogTimestamp=null;
  document.addEventListener('DOMContentLoaded',()=>{(document.getElementById('mobileConnectionSlot')||document.body).appendChild(el)});
  async function refresh(){
    try{
      const response=await fetch('/api/sync/status',{credentials:'same-origin',cache:'no-store'});
      if(!response.ok){el.hidden=true;return}
      const s=await response.json();el.hidden=false;
      // Update future issue forms when destinations are changed in the central dashboard.
      // Do not redraw an open form: it might contain unsaved user input.
      if(s.catalog_updated_at && s.catalog_updated_at!==latestCatalogTimestamp){
        latestCatalogTimestamp=s.catalog_updated_at;
        try{const settingsResponse=await fetch('/api/settings',{credentials:'same-origin',cache:'no-store'});
          if(settingsResponse.ok&&window.state){window.state.settings=await settingsResponse.json();}}
        catch(_){/* use existing cached choices until the next refresh */}
      }
      let state=!s.enabled?'همگام‌سازی غیرفعال':s.last_error?'خطای همگام‌سازی':s.pending?'در انتظار ارسال':'همگام‌شده';
      el.className=s.last_error?'offline':s.enabled&&s.pending===0?'online':'';
      el.innerHTML='<span class="dot"></span><b>'+state+'</b> · '+esc(s.branch_name||'شعبه')+
        '<small>'+s.pending+' عملیات در صف'+(s.provisional?' · '+s.provisional+' دریافت موقت':'')+(s.conflicts?' · '+s.conflicts+' مغایرت':'')+(s.last_success?' · آخرین همگام‌سازی: '+new Date(s.last_success).toLocaleString('fa-IR',{timeZone:'Asia/Tehran',dateStyle:'short',timeStyle:'short'}):'')+'</small>';
      el.title=s.last_error||'';
    }catch(_){el.hidden=true}
  }
  setInterval(refresh,15000);document.addEventListener('DOMContentLoaded',refresh);
})();
