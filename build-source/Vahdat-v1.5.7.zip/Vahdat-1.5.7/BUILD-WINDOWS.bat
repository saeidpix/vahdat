@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD-WINDOWS.ps1"
if errorlevel 1 (
  echo.
  echo ERROR: Windows build did not finish. See the error above.
  pause
  exit /b 1
)
echo.
echo Build finished. See the dist folder.
pause
