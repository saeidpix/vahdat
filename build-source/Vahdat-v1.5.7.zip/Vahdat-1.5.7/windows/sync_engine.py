# -*- coding: utf-8 -*-
"""Persistent offline-first replication between a branch server and the company hub.

V1.5 beta sync protocol: events are idempotent, ordered and durable on the local SSD.
The hub is not required for issuing or scanning waybills. Remote incoming data is
applied inside a single transaction together with the pull cursor.
"""
import json
import os
import pathlib
import sqlite3
import threading
import time
import uuid
from urllib import request as urlrequest, parse as urlparse, error as urlerror

EVENT_TYPES = {'waybill_issued', 'manifest_created', 'waybill_received', 'waybill_delivered', 'settlement_created'}
_SYNC_LOCK = threading.Lock()
_SYNC_STATUS = {'running': False, 'last_error': '', 'last_success': None}


def config_file(data_path):
    return pathlib.Path(os.environ.get('VAHDAT_SYNC_CONFIG', str(pathlib.Path(data_path)/'sync-config.json')))


def load_config(data_path):
    fn=config_file(data_path)
    if not fn.is_file():
        return dict(enabled=False, branch_id='tehran', branch_name='تهران', hub_url='', token='')
    config=json.loads(fn.read_text(encoding='utf-8'))
    config.setdefault('enabled', False)
    config.setdefault('branch_id', 'tehran')
    config.setdefault('branch_name', 'تهران')
    config.setdefault('hub_url', '')
    config.setdefault('token', '')
    return config


def validate_config(cfg):
    if not cfg.get('enabled'):return False
    u=str(cfg.get('hub_url', '')).rstrip('/')
    parsed=urlparse.urlparse(u)
    if parsed.scheme != 'https' and not (parsed.scheme == 'http' and parsed.hostname in ('localhost','127.0.0.1')):
        raise ValueError('نشانی مرکز باید HTTPS باشد. HTTP فقط برای شبیه‌ساز روی همین کامپیوتر مجاز است.')
    if not cfg.get('token') or not cfg.get('branch_id') or not cfg.get('branch_name'):
        raise ValueError('کد شعبه، نام شعبه و کلید ارتباط با مرکز باید تنظیم شوند.')
    return True


def now():return int(time.time()*1000)


def migrate(c):
    cols={x[1] for x in c.execute('PRAGMA table_info(waybills)')}
    if 'pending_verification' not in cols:
        c.execute('ALTER TABLE waybills ADD COLUMN pending_verification INTEGER NOT NULL DEFAULT 0')
    if 'source_number' not in cols:
        c.execute('ALTER TABLE waybills ADD COLUMN source_number INTEGER')
    c.executescript('''
    CREATE TABLE IF NOT EXISTS sync_outbox (
       event_id TEXT PRIMARY KEY, kind TEXT NOT NULL, target TEXT NOT NULL,
       payload TEXT NOT NULL, happened_at INTEGER NOT NULL, sent_at INTEGER);
    CREATE INDEX IF NOT EXISTS idx_outbox_pending ON sync_outbox(sent_at,happened_at);
    CREATE TABLE IF NOT EXISTS sync_inbox (
       event_id TEXT PRIMARY KEY, hub_sequence INTEGER NOT NULL UNIQUE, received_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS sync_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS sync_conflicts (
       id TEXT PRIMARY KEY, event_id TEXT NOT NULL UNIQUE, reason TEXT NOT NULL,
       payload TEXT NOT NULL, happened_at INTEGER NOT NULL);
    INSERT OR IGNORE INTO sync_meta(key,value) VALUES('cursor','0');
    INSERT OR IGNORE INTO sync_meta(key,value) VALUES('catalog_ready','0');
    CREATE TABLE IF NOT EXISTS sync_branch_catalog (
       branch_id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE,
       allowed_destination INTEGER NOT NULL DEFAULT 0, last_updated_at INTEGER NOT NULL);
    ''')
    c.commit()


def permitted_destinations(c, cfg):
    # None means use manually configured choices until the first successful central catalog.
    if not cfg.get('enabled'):
        return None
    r=c.execute("SELECT value FROM sync_meta WHERE key='catalog_ready'").fetchone()
    if not r or r[0]!='1':
        return None
    return [x[0] for x in c.execute('SELECT name FROM sync_branch_catalog WHERE allowed_destination=1 ORDER BY name').fetchall()]


def branch_target(c, value):
    # Resolve Persian destination to stable branch ID while accepting older queued names.
    r=c.execute('SELECT branch_id FROM sync_branch_catalog WHERE name=? OR branch_id=?',
                (str(value),str(value))).fetchone()
    return str(r[0]) if r else str(value)


def refresh_catalog(connect,cfg):
    # Replace destination permission cache atomically; a network failure leaves the old one intact.
    catalog=_request(cfg,'GET','/api/v1/branches/sync/catalog')
    source=catalog.get('branch',{})
    if source.get('id')!=cfg['branch_id'] or source.get('name')!=cfg['branch_name']:
        raise ValueError('هویت شعبه در مرکز با تنظیمات محلی مطابقت ندارد.')
    destinations=catalog.get('destinations',[])
    peers=catalog.get('peers',[])
    if not isinstance(destinations,list) or not isinstance(peers,list):
        raise ValueError('Central branch catalog is invalid')
    allowed={str(v['id']) for v in destinations}
    all_peers={str(v['id']):str(v['name']) for v in destinations+peers}
    if len(all_peers)>500:raise ValueError('Central catalog too large')
    t=now()
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        c.execute('DELETE FROM sync_branch_catalog')
        c.executemany('INSERT INTO sync_branch_catalog(branch_id,name,allowed_destination,last_updated_at) VALUES(?,?,?,?)',
                      [(id,name,int(id in allowed),t) for id,name in all_peers.items()])
        c.execute("INSERT OR REPLACE INTO sync_meta(key,value) VALUES('catalog_ready','1')")
        c.execute("INSERT OR REPLACE INTO sync_meta(key,value) VALUES('catalog_updated_at',?)",(str(t),))
        c.commit()
    return len(allowed)


def enqueue(c, kind, target, payload, happened_at=None):
    if kind not in EVENT_TYPES:raise ValueError('Unknown sync event type')
    event_id='E-'+uuid.uuid4().hex
    c.execute('INSERT INTO sync_outbox(event_id,kind,target,payload,happened_at) VALUES(?,?,?,?,?)',
              (event_id,kind,branch_target(c,target),json.dumps(payload,ensure_ascii=False,separators=(',',':')),happened_at or now()))
    return event_id


def queue_waybill(c, ident):
    b=c.execute('SELECT * FROM waybills WHERE id=?',(ident,)).fetchone()
    if b and b['origin_here']:
        enqueue(c,'waybill_issued',b['destination'],{'waybill':dict(b)})


def queue_manifest(c, manifest_id):
    m=c.execute('SELECT * FROM manifests WHERE id=?',(manifest_id,)).fetchone()
    if not m:return
    driver=c.execute('SELECT * FROM drivers WHERE id=?',(m['driver_id'],)).fetchone()
    bills=[dict(x) for x in c.execute('''SELECT w.* FROM manifest_bills mb
                  JOIN waybills w ON w.id=mb.waybill_id WHERE mb.manifest_id=?''',(manifest_id,))]
    enqueue(c,'manifest_created',m['destination'],
            {'manifest':dict(m),'driver':dict(driver),'waybills':bills})


def queue_received(c, b, received_at):
    enqueue(c,'waybill_received',b['origin'],{'waybill_id':b['id'],'received_at':int(received_at),
                  'manifest_id':b['manifest_id'],'destination':b['destination']})


def queue_delivered(c, b, delivered_at, person, collected):
    enqueue(c,'waybill_delivered',b['origin'],{'waybill_id':b['id'],
            'delivered_at':int(delivered_at),'person':str(person),'collected':int(collected)})


def queue_settlement(c, ident, target):
    r=c.execute('SELECT * FROM settlements WHERE id=?',(ident,)).fetchone()
    if r:enqueue(c,'settlement_created',target,{'settlement':dict(r)})


def _new_number(c, table):
    return c.execute('SELECT COALESCE(MAX(number),0)+1 FROM '+table).fetchone()[0]


def _import_waybill(c, b, origin_branch):
    """Never overwrite a locally received/delivered waybill from remote snapshots."""
    original_id=str(b.get('id',''))
    if not original_id.startswith('VH-'):raise ValueError('Invalid waybill ID')
    existing=c.execute('SELECT * FROM waybills WHERE id=?',(original_id,)).fetchone()
    if existing:
        # A QR provisional record can only be confirmed by an exact canonical match.
        if existing['pending_verification'] and not all(str(existing[k])==str(b[k])
                      for k in ('origin','destination','sender','receiver','phone','pieces','prepaid','post_fare','storage_fee','other_fee','total','created_at')):
            raise ValueError('Provisional QR data differs from hub data')
        if existing['pending_verification']:
            c.execute('UPDATE waybills SET sender_phone=?,description=?,source_number=? WHERE id=?',
                      (b.get('sender_phone',''),b.get('description',''),b.get('number'),original_id))
        return
    cols=('id','origin','destination','sender','receiver','phone','pieces','prepaid',
          'post_fare','storage_fee','other_fee','total','created_at','received_at',
          'delivered_at','delivered_to','post_collected','origin_here','number',
          'sender_phone','description','manifest_id','pending_verification','source_number')
    values={k:b.get(k) for k in cols}
    values.update(number=_new_number(c,'waybills'),source_number=b.get('number'),
                  received_at=None,delivered_at=None,delivered_to='',post_collected=0,
                  origin_here=0,manifest_id=None,pending_verification=0)
    c.execute('INSERT INTO waybills('+','.join(cols)+') VALUES('+','.join('?' for _ in cols)+')',
              tuple(values.get(k) for k in cols))


def _manifest(c, payload, origin_branch):
    m=payload['manifest'];driver=payload['driver'];bills=payload['waybills']
    if not isinstance(bills,list) or not 1<=len(bills)<=400:raise ValueError('Invalid manifest bill count')
    # A driver can be represented by a global identifier across branches.
    dr=c.execute('SELECT id FROM drivers WHERE id=?',(driver['id'],)).fetchone()
    if not dr:
        mobile=driver['mobile']
        duplicate=c.execute('SELECT id FROM drivers WHERE mobile=?',(mobile,)).fetchone()
        if duplicate and duplicate['id']!=driver['id']:
            raise ValueError('Driver mobile belongs to a different local record')
        c.execute('INSERT INTO drivers(id,first_name,last_name,mobile,enabled,created_at) VALUES(?,?,?,?,?,?)',
                  (driver['id'],driver['first_name'],driver['last_name'],mobile,driver.get('enabled',1),driver['created_at']))
    for b in bills:
        if b['destination']!=m['destination'] or b['origin']!=origin_branch:
            raise ValueError('Manifest routing or origin mismatch')
        _import_waybill(c,b,origin_branch)
    exists=c.execute('SELECT id FROM manifests WHERE id=?',(m['id'],)).fetchone()
    if not exists:
        c.execute('INSERT INTO manifests(id,number,driver_id,destination,created_at,created_by,received_at) VALUES(?,?,?,?,?,?,?)',
                  (m['id'],_new_number(c,'manifests'),driver['id'],m['destination'],m['created_at'],None,None))
    for b in bills:
        c.execute('INSERT OR IGNORE INTO manifest_bills(manifest_id,waybill_id) VALUES(?,?)',(m['id'],b['id']))
        previous=c.execute('SELECT pending_verification,received_at FROM waybills WHERE id=?',(b['id'],)).fetchone()
        c.execute('UPDATE waybills SET manifest_id=?,pending_verification=0 WHERE id=?',(m['id'],b['id']))
        if previous['pending_verification'] and previous['received_at']:
            # Receipt was scanned offline before a hub-confirmed manifest appeared.
            confirmed=c.execute('SELECT * FROM waybills WHERE id=?',(b['id'],)).fetchone()
            queue_received(c,confirmed,previous['received_at'])
    remaining=c.execute('''SELECT COUNT(*) FROM manifest_bills mb JOIN waybills w ON mb.waybill_id=w.id
         WHERE mb.manifest_id=? AND w.received_at IS NULL''',(m['id'],)).fetchone()[0]
    if not remaining:
        earliest=c.execute('''SELECT MAX(w.received_at) FROM manifest_bills mb
                JOIN waybills w ON mb.waybill_id=w.id WHERE mb.manifest_id=?''',(m['id'],)).fetchone()[0]
        c.execute('UPDATE manifests SET received_at=COALESCE(received_at,?) WHERE id=?',(earliest,m['id']))


def apply_event(c, ev, branch_name):
    typ=ev['kind'];p=ev['payload'];source=str(ev['source_branch'])
    if typ=='waybill_issued':
        b=p['waybill']
        if b['destination']!=branch_name or b['origin']!=source:raise ValueError('Invalid waybill route')
        _import_waybill(c,b,source)
    elif typ=='manifest_created':
        if p['manifest']['destination']!=branch_name:raise ValueError('Not addressed to this branch')
        _manifest(c,p,source)
    elif typ=='waybill_received':
        r=c.execute('SELECT * FROM waybills WHERE id=?',(p['waybill_id'],)).fetchone()
        if not r:raise ValueError('Receipt for an unknown waybill')
        if r['origin']!=branch_name or r['destination']!=source:raise ValueError('Receipt route mismatch')
        c.execute('UPDATE waybills SET received_at=COALESCE(received_at,?) WHERE id=?',
                  (int(p['received_at']),r['id']))
    elif typ=='waybill_delivered':
        r=c.execute('SELECT * FROM waybills WHERE id=?',(p['waybill_id'],)).fetchone()
        if not r or r['origin']!=branch_name or r['destination']!=source:raise ValueError('Delivery route mismatch')
        c.execute('''UPDATE waybills SET delivered_at=COALESCE(delivered_at,?),
          delivered_to=CASE WHEN delivered_at IS NULL THEN ? ELSE delivered_to END,
          post_collected=CASE WHEN delivered_at IS NULL THEN ? ELSE post_collected END WHERE id=?''',
                  (int(p['delivered_at']),p['person'],int(p['collected']),r['id']))
    elif typ=='settlement_created':
        s=p['settlement']
        if not c.execute('SELECT 1 FROM manifests WHERE id=?',(s['manifest_id'],)).fetchone():
            raise ValueError('Settlement for an unknown manifest')
        c.execute('INSERT OR IGNORE INTO settlements(id,manifest_id,side,cash,passenger,created_at,created_by) VALUES(?,?,?,?,?,?,?)',
                  (s['id'],s['manifest_id'],s['side'],s['cash'],s['passenger'],s['created_at'],None))
    else:raise ValueError('Unknown event type')


def provisional_receive(c, code, decoder, branch_name):
    """Accept an unknown QR offline as *provisional*, not a verified destination receipt."""
    b=decoder(code)
    if b['destination']!=branch_name:raise ValueError('این بارنامه متعلق به این شعبه نیست.')
    row=c.execute('SELECT * FROM waybills WHERE id=?',(b['id'],)).fetchone()
    if row:return row,False
    cols=('id','origin','destination','sender','receiver','phone','pieces','prepaid','post_fare',
          'storage_fee','other_fee','total','created_at','received_at','delivered_at',
          'delivered_to','post_collected','origin_here','number','pending_verification')
    t=now();b.update(received_at=t,number=_new_number(c,'waybills'),pending_verification=1)
    c.execute('INSERT INTO waybills('+','.join(cols)+') VALUES('+','.join('?' for _ in cols)+')',
              tuple(b.get(k) for k in cols))
    return c.execute('SELECT * FROM waybills WHERE id=?',(b['id'],)).fetchone(),True


def _request(cfg,method,endpoint,data=None):
    base=cfg['hub_url'].rstrip('/')
    headers={'Authorization':'Bearer '+str(cfg['token']),'X-Vahdat-Branch':str(cfg['branch_id']),
             'Accept':'application/json'}
    raw=None
    if data is not None:
        raw=json.dumps(data,ensure_ascii=False,separators=(',',':')).encode('utf-8')
        headers['Content-Type']='application/json'
    req=urlrequest.Request(base+endpoint,data=raw,headers=headers,method=method)
    with urlrequest.urlopen(req,timeout=7) as resp:
        body=resp.read(2_500_000)
        return json.loads(body.decode('utf-8'))


def get_status(connect,data_path):
    cfg=load_config(data_path)
    with connect() as c:
        pending=c.execute('SELECT COUNT(*) FROM sync_outbox WHERE sent_at IS NULL').fetchone()[0]
        conflicts=c.execute('SELECT COUNT(*) FROM sync_conflicts').fetchone()[0]
        provisional=c.execute('SELECT COUNT(*) FROM waybills WHERE pending_verification=1').fetchone()[0]
        cursor=int(c.execute("SELECT value FROM sync_meta WHERE key='cursor'").fetchone()[0])
        cat=c.execute("SELECT value FROM sync_meta WHERE key='catalog_updated_at'").fetchone()
    return dict(enabled=bool(cfg['enabled']),branch_name=cfg['branch_name'],branch_id=cfg['branch_id'],
                pending=pending,conflicts=conflicts,provisional=provisional,cursor=cursor,
                catalog_updated_at=(int(cat[0]) if cat else None),
                running=_SYNC_STATUS['running'],last_success=_SYNC_STATUS['last_success'],
                last_error=_SYNC_STATUS['last_error'])


def sync_once(connect,data_path):
    if not _SYNC_LOCK.acquire(blocking=False):return {'busy':True}
    _SYNC_STATUS['running']=True
    try:
        cfg=load_config(data_path)
        if not validate_config(cfg):return {'enabled':False}
        try:
            refresh_catalog(connect,cfg)
        except urlerror.HTTPError as exc:
            if exc.code!=404:raise  # legacy two-branch simulator has no catalog endpoint
        with connect() as c:
            rows=c.execute('''SELECT event_id,kind,target,payload,happened_at FROM sync_outbox
                     WHERE sent_at IS NULL ORDER BY happened_at,event_id LIMIT 100''').fetchall()
        batch=[dict(id=r['event_id'],kind=r['kind'],target=r['target'],payload=json.loads(r['payload']),
                    created_at=r['happened_at']) for r in rows]
        if batch:
            result=_request(cfg,'POST','/api/v1/branches/sync/push',{'events':batch})
            accepted=set(result.get('accepted',[]))
            if not accepted.issubset(set(x['id'] for x in batch)) or accepted!=set(x['id'] for x in batch):
                raise ValueError('Hub did not acknowledge all submitted events')
            with connect() as c:
                c.executemany('UPDATE sync_outbox SET sent_at=? WHERE event_id=?',[(now(),x) for x in accepted]);c.commit()
        with connect() as c:cursor=int(c.execute("SELECT value FROM sync_meta WHERE key='cursor'").fetchone()[0])
        incoming=_request(cfg,'GET','/api/v1/branches/sync/pull?cursor='+str(cursor)+'&limit=200')
        events=incoming['events']
        with connect() as c:
            c.execute('BEGIN IMMEDIATE')
            for ev in events:
                seq=int(ev['sequence']);eid=str(ev['id'])
                if seq<=cursor:continue
                if not c.execute('SELECT 1 FROM sync_inbox WHERE event_id=?',(eid,)).fetchone():
                    try:
                        c.execute('SAVEPOINT apply_event')
                        apply_event(c,ev,cfg['branch_name'])
                        c.execute('RELEASE SAVEPOINT apply_event')
                    except Exception as exc:
                        c.execute('ROLLBACK TO SAVEPOINT apply_event')
                        c.execute('RELEASE SAVEPOINT apply_event')
                        c.execute('INSERT OR IGNORE INTO sync_conflicts(id,event_id,reason,payload,happened_at) VALUES(?,?,?,?,?)',
                                  ('C-'+uuid.uuid4().hex,eid,str(exc)[:500],json.dumps(ev,ensure_ascii=False),now()))
                    c.execute('INSERT INTO sync_inbox(event_id,hub_sequence,received_at) VALUES(?,?,?)',(eid,seq,now()))
                cursor=seq
            if int(incoming.get('next_cursor',cursor))>cursor:
                # Hub may advance across unrelated events not delivered to this branch.
                cursor=int(incoming['next_cursor'])
            c.execute('UPDATE sync_meta SET value=? WHERE key=?',(str(cursor),'cursor'))
            c.commit()
        # Heartbeat is advisory; older hub versions can return 404 without blocking sync.
        with connect() as c:
            pending=c.execute('SELECT COUNT(*) FROM sync_outbox WHERE sent_at IS NULL').fetchone()[0]
            conflicts=c.execute('SELECT COUNT(*) FROM sync_conflicts').fetchone()[0]
            provisional=c.execute('SELECT COUNT(*) FROM waybills WHERE pending_verification=1').fetchone()[0]
        try:
            _request(cfg,'POST','/api/v1/branches/sync/heartbeat',
                     dict(pending=pending,conflicts=conflicts,provisional=provisional,version='1.5.6-beta'))
        except urlerror.HTTPError as exc:
            if exc.code!=404:raise
        _SYNC_STATUS.update(last_success=now(),last_error='')
        return dict(ok=True,sent=len(batch),received=len(events),cursor=cursor)
    except Exception as exc:
        _SYNC_STATUS['last_error']=str(exc)[:500]
        return dict(ok=False,error=str(exc)[:500])
    finally:
        _SYNC_STATUS['running']=False
        _SYNC_LOCK.release()


def start_worker(connect,data_path,interval=25):
    def worker():
        while True:
            sync_once(connect,data_path)
            time.sleep(interval)
    threading.Thread(target=worker,name='VahdatSyncWorker',daemon=True).start()
