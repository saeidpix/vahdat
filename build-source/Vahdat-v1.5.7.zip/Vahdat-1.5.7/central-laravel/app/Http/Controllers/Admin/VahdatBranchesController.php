<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

/** Explicit authenticated owner-only management; no access to ticket-sales tables. */
final class VahdatBranchesController extends Controller
{
    private function assertManager(Request $request): void
    {
        $user = $request->user();
        $authorizedIds = config('vahdat-branches.admin_user_ids', []);
        abort_unless($user && in_array((string) $user->getAuthIdentifier(), $authorizedIds, true),
            403, 'مدیریت شعبه‌ها فقط برای مدیر کل فعال است.');
    }

    private function rows(): array
    {
        $branches = DB::table('vahdat_sync_branches')->orderBy('name')->get();
        $today = now('Asia/Tehran')->startOfDay()->getTimestampMs();
        $routes = DB::table('vahdat_sync_routes')->where('enabled', true)
            ->get(['origin_id', 'destination_id'])->groupBy('origin_id');
        // Aggregate in SQL rather than running several queries per branch on shared hosting.
        $pending = DB::table('vahdat_sync_events as e')
            ->join('vahdat_sync_branches as b', 'b.id', '=', 'e.target_branch_id')
            ->whereColumn('e.sequence', '>', 'b.last_ack_cursor')
            ->selectRaw('e.target_branch_id, COUNT(*) as count')
            ->groupBy('e.target_branch_id')->pluck('count', 'target_branch_id');
        $daily = DB::table('vahdat_sync_events')
            ->where('happened_at', '>=', $today)
            ->whereIn('kind', ['waybill_issued', 'waybill_received'])
            ->selectRaw('source_branch, kind, COUNT(*) as count')
            ->groupBy('source_branch', 'kind')->get()
            ->groupBy('source_branch');
        // Central verified shipment projection, not a sum of event messages (which may be retried).
        $verified = DB::table('vahdat_sync_waybill_tracking')->where('verified_origin', true);
        $sentToday = (clone $verified)->where('issued_at', '>=', $today)
            ->selectRaw('origin_branch_id, COUNT(*) as total')
            ->groupBy('origin_branch_id')->pluck('total', 'origin_branch_id');
        $expected = (clone $verified)->whereIn('status', ['issued', 'in_transit'])
            ->selectRaw('destination_branch_id, COUNT(*) as total')
            ->groupBy('destination_branch_id')->pluck('total', 'destination_branch_id');
        $transit = (clone $verified)->where('status', 'in_transit')
            ->selectRaw('destination_branch_id, COUNT(*) as total')
            ->groupBy('destination_branch_id')->pluck('total', 'destination_branch_id');
        $receivedToday = (clone $verified)->where('received_at', '>=', $today)
            ->selectRaw('destination_branch_id, COUNT(*) as total')
            ->groupBy('destination_branch_id')->pluck('total', 'destination_branch_id');
        $rows = [];
        foreach ($branches as $branch) {
            $stats = $daily->get($branch->id, collect());
            $issued = $stats->firstWhere('kind', 'waybill_issued');
            $received = $stats->firstWhere('kind', 'waybill_received');
            $rows[] = [
                'branch' => $branch,
                'allowed' => ($routes->get($branch->id) ?? collect())->pluck('destination_id')->all(),
                'online' => (bool) $branch->enabled && $branch->last_seen_at &&
                    abs(now()->diffInSeconds($branch->last_seen_at, false)) <= 100,
                'pending_incoming' => (int) $pending->get($branch->id, 0),
                'issued_today' => (int) ($issued->count ?? 0),
                'received_today' => (int) ($received->count ?? 0),
                'shipments_sent_today' => (int) $sentToday->get($branch->id, 0),
                'shipments_expected' => (int) $expected->get($branch->id, 0),
                'shipments_in_transit' => (int) $transit->get($branch->id, 0),
                'shipments_received_today' => (int) $receivedToday->get($branch->id, 0),
            ];
        }
        return $rows;
    }

    public function index(Request $request): View
    {
        $this->assertManager($request);
        $rows = $this->rows();
        return view('admin.vahdat-branches', [
            'rows' => $rows,
            'branches' => array_map(fn($x) => $x['branch'], $rows),
            'total' => count($rows),
            'onlineCount' => count(array_filter($rows, fn($x) => $x['online'])),
            'totalPending' => array_sum(array_map(fn($x) => $x['pending_incoming'] + (int)($x['branch']->pending_outbox ?? 0), $rows)),
        ]);
    }

    public function status(Request $request): JsonResponse
    {
        $this->assertManager($request);
        $rows = $this->rows();
        return response()->json(['branches' => array_map(fn($r) => [
            'id' => $r['branch']->id, 'name' => $r['branch']->name,
            'enabled' => (bool)$r['branch']->enabled, 'online' => $r['online'],
            'last_seen_at' => $r['branch']->last_seen_at,
            'pending_outbox' => $r['branch']->pending_outbox,
            'pending_incoming' => $r['pending_incoming'],
            'conflicts' => $r['branch']->conflicts,
            'shipments_sent_today' => $r['shipments_sent_today'],
            'shipments_expected' => $r['shipments_expected'],
            'shipments_in_transit' => $r['shipments_in_transit'],
            'shipments_received_today' => $r['shipments_received_today'],
        ], $rows)]);
    }

    public function store(Request $request): RedirectResponse
    {
        $this->assertManager($request);
        $v = $request->validate([
            'id' => ['required', 'string', 'regex:/^[a-z][a-z0-9_-]{1,47}$/', 'unique:vahdat_sync_branches,id'],
            'name' => ['required', 'string', 'max:180', 'unique:vahdat_sync_branches,name'],
        ]);
        $name = trim($v['name']);
        if ($name === '') return back()->withErrors(['name' => 'نام شعبه لازم است.'])->withInput();
        $token = bin2hex(random_bytes(32));
        DB::table('vahdat_sync_branches')->insert([
            'id' => $v['id'], 'name' => $name, 'token_sha256' => hash('sha256', $token),
            'enabled' => true, 'created_at' => now(), 'updated_at' => now(),
        ]);
        // Secret shown ONCE; store only on the actual branch server, never in an exported report.
        return redirect()->route('vahdat.branches.index')
            ->with('branch_notice', 'شعبه ثبت شد. کلید ارتباط را همین حالا در محل امن ثبت کنید.')
            ->with('new_branch_secret', ['id' => $v['id'], 'token' => $token]);
    }

    public function update(Request $request, string $id): RedirectResponse
    {
        $this->assertManager($request);
        $v = $request->validate([
            'name' => ['required', 'string', 'max:180', Rule::unique('vahdat_sync_branches', 'name')->ignore($id, 'id')],
            'enabled' => ['required', Rule::in(['0', '1'])],
        ]);
        $name = trim($v['name']);
        if ($name === '') return back()->withErrors(['name' => 'نام شعبه لازم است.']);
        DB::transaction(function () use ($id, $name, $v) {
            $branch = DB::table('vahdat_sync_branches')->where('id', $id)->lockForUpdate()->first();
            abort_unless($branch, 404);
            if ($branch->name !== $name) {
                $hasHistory = DB::table('vahdat_sync_events')
                    ->where('source_branch', $id)->orWhere('target_branch_id', $id)
                    ->orWhere('target', $branch->name)->exists();
                if ($hasHistory) throw \Illuminate\Validation\ValidationException::withMessages([
                    'name' => 'نام شعبه پس از ثبت بارنامه قابل تغییر نیست؛ شناسه ثابت می‌ماند. برای اصلاح نام با مدیر فنی هماهنگ کنید.',
                ]);
            }
            DB::table('vahdat_sync_branches')->where('id', $id)->update([
                'name' => $name, 'enabled' => $v['enabled'] === '1', 'updated_at' => now(),
            ]);
        });
        return back()->with('branch_notice', 'تنظیمات شعبه ذخیره شد.');
    }

    public function routes(Request $request, string $id): RedirectResponse
    {
        $this->assertManager($request);
        $v = Validator::make($request->all(), [
            'destinations' => ['sometimes', 'array', 'max:200'],
            'destinations.*' => ['required', 'string', 'max:48', 'distinct'],
        ])->validate();
        $selected = array_values(array_unique($v['destinations'] ?? []));
        if (in_array($id, $selected, true)) return back()->withErrors(['destinations' => 'یک شعبه نمی‌تواند مقصد خودش باشد.']);
        DB::transaction(function () use ($id, $selected) {
            abort_unless(DB::table('vahdat_sync_branches')->where('id', $id)->lockForUpdate()->exists(), 404);
            $existing = DB::table('vahdat_sync_branches')->where('enabled', true)
                ->whereIn('id', $selected)->pluck('id')->all();
            if (count($existing) !== count($selected))
                throw \Illuminate\Validation\ValidationException::withMessages([
                    'destinations' => 'یک یا چند شعبه مقصد موجود نیست یا غیرفعال است.',
                ]);
            // Retain disabled rows as history so in-flight return acknowledgements can complete.
            DB::table('vahdat_sync_routes')->where('origin_id', $id)->update(['enabled' => false, 'updated_at' => now()]);
            foreach ($selected as $destId) {
                DB::table('vahdat_sync_routes')->updateOrInsert(
                    ['origin_id' => $id, 'destination_id' => $destId],
                    ['enabled' => true, 'updated_at' => now(), 'created_at' => now()]
                );
            }
        });
        return back()->with('branch_notice', 'مقصدهای مجاز ثبت شدند. در اولین ارتباط به شعبه ارسال می‌شوند.');
    }

    public function rotate(Request $request, string $id): RedirectResponse
    {
        $this->assertManager($request);
        $token = bin2hex(random_bytes(32));
        $changed = DB::table('vahdat_sync_branches')->where('id', $id)->update([
            'token_sha256' => hash('sha256', $token),
            'token_rotated_at' => now(), 'updated_at' => now(),
        ]);
        abort_unless($changed, 404);
        return back()->with('branch_notice', 'کلید شعبه تغییر کرد؛ کلید قبلی فوراً باطل است.')
            ->with('new_branch_secret', ['id' => $id, 'token' => $token]);
    }
}
