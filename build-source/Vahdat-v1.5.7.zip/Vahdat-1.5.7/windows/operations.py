# -*- coding: utf-8 -*-
"""Operational extensions for Vahdat Windows v1.4.0-beta.

Schema additions are additive; legacy waybill identifiers, QR encoding and amounts survive.
"""
import datetime as dt
import hashlib
import hmac
import json
import os
import re
import secrets
import sqlite3
import threading
import time
import uuid
import io
import report_excel
import sync_engine
from functools import wraps
from flask import request, jsonify, session, g, send_file

ROLE_PERMS={
    'admin': {'issue','drivers','handover','receive','settle','list','reports','users','settings','backup'},
    'issuance': {'issue','list','drivers'},
    'warehouse': {'drivers','handover','receive','list'},
    'accountant': {'list','settle','reports'},
    'viewer': {'list'},
}
PERMISSIONS=sorted(ROLE_PERMS['admin'])
ROLES=['admin','issuance','warehouse','accountant','viewer']
_login_attempts={}
_login_lock=threading.Lock()

def migrate(c):
    existing={row[1] for row in c.execute('PRAGMA table_info(waybills)')}
    for name,typ in [('sender_phone','TEXT NOT NULL DEFAULT \'\''),
                     ('description','TEXT NOT NULL DEFAULT \'\''),
                     ('manifest_id','TEXT')]:
        if name not in existing:c.execute(f'ALTER TABLE waybills ADD COLUMN {name} {typ}')
    c.executescript('''
      CREATE TABLE IF NOT EXISTS drivers (
        id TEXT PRIMARY KEY, first_name TEXT NOT NULL, last_name TEXT NOT NULL,
        mobile TEXT NOT NULL UNIQUE, enabled INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY, name TEXT NOT NULL, mobile TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL, role TEXT NOT NULL, permissions_json TEXT,
        enabled INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS manifests (
        id TEXT PRIMARY KEY, number INTEGER NOT NULL UNIQUE, driver_id TEXT NOT NULL REFERENCES drivers(id),
        destination TEXT NOT NULL, created_at INTEGER NOT NULL, created_by TEXT,
        received_at INTEGER);
      CREATE TABLE IF NOT EXISTS manifest_bills (
        manifest_id TEXT NOT NULL REFERENCES manifests(id), waybill_id TEXT NOT NULL UNIQUE,
        PRIMARY KEY(manifest_id,waybill_id));
      CREATE TABLE IF NOT EXISTS settlements (
        id TEXT PRIMARY KEY, manifest_id TEXT NOT NULL REFERENCES manifests(id),
        side TEXT NOT NULL CHECK(side IN ('origin','dest')),
        cash INTEGER NOT NULL DEFAULT 0 CHECK(cash>=0),
        passenger INTEGER NOT NULL DEFAULT 0 CHECK(passenger>=0),
        created_at INTEGER NOT NULL, created_by TEXT);
      CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT, at INTEGER NOT NULL,
        user_id TEXT, action TEXT NOT NULL, subject TEXT, payload TEXT NOT NULL DEFAULT '{}');
      CREATE INDEX IF NOT EXISTS idx_settlement_manifest ON settlements(manifest_id);
      CREATE INDEX IF NOT EXISTS idx_manifest_driver ON manifests(driver_id);
    ''')
    bill_columns={row[1] for row in c.execute('PRAGMA table_info(waybills)')}
    if 'created_by' not in bill_columns:
        c.execute('ALTER TABLE waybills ADD COLUMN created_by TEXT')
    c.execute('CREATE INDEX IF NOT EXISTS idx_waybill_issuer_date ON waybills(created_by,created_at)')
    manifest_columns={row[1] for row in c.execute('PRAGMA table_info(manifests)')}
    if 'received_by' not in manifest_columns:
        c.execute('ALTER TABLE manifests ADD COLUMN received_by TEXT')
    user_columns={row[1] for row in c.execute('PRAGMA table_info(users)')}
    if 'permissions_json' not in user_columns:
        c.execute('ALTER TABLE users ADD COLUMN permissions_json TEXT')
    c.execute("INSERT OR IGNORE INTO settings(name,value) VALUES('print_settings',?)",
              (json.dumps({'on_issue':False,'on_handover':False,'on_receive':False}),))
    c.execute('PRAGMA user_version=2')
    c.commit()

def password_hash(raw):
    salt=os.urandom(16)
    key=hashlib.pbkdf2_hmac('sha256',raw.encode('utf-8'),salt,360000)
    return 'pbkdf2-sha256$360000$'+salt.hex()+'$'+key.hex()

def check_password(raw,stored):
    try:
        algo,iterations,salt,key=stored.split('$')
        if algo!='pbkdf2-sha256':return False
        candidate=hashlib.pbkdf2_hmac('sha256',raw.encode('utf-8'),bytes.fromhex(salt),int(iterations))
        return hmac.compare_digest(candidate,bytes.fromhex(key))
    except Exception:return False

def normalize_mobile(x):
    x=str(x or '').translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩','01234567890123456789'))
    return re.sub(r'\D','',x)

def now():return int(time.time()*1000)

def audit(c, action, subject='', payload=None):
    c.execute('INSERT INTO audit_log(at,user_id,action,subject,payload) VALUES(?,?,?,?,?)',
              (now(),session.get('uid'),action,subject,json.dumps(payload or {},ensure_ascii=False)))

def register(app,connect,bill,shamsi,local_date,parse_amount,decode_qr,data_path):
    def out(msg,status=400):return jsonify(error=msg),status
    def who(c):
        uid=session.get('uid')
        return c.execute('SELECT * FROM users WHERE id=? AND enabled=1',(uid,)).fetchone() if uid else None
    def permissions(c):
        u=who(c)
        if not u:return set()
        if u['role']=='admin':return ROLE_PERMS['admin']
        raw=u['permissions_json']
        if raw is None:return ROLE_PERMS.get(u['role'],set())
        try:return set(json.loads(raw)).intersection(PERMISSIONS)
        except Exception:return set()
    def require(c,p):
        return p in permissions(c)
    def settings_get(c,k,default=None):
        r=c.execute('SELECT value FROM settings WHERE name=?',(k,)).fetchone()
        return json.loads(r['value']) if r else default
    def protected(p):
        def deco(fn):
            @wraps(fn)
            def wrapper(*args,**kwargs):
                with connect() as c:
                    if not require(c,p):return out('دسترسی به این عملیات مجاز نیست.',403)
                return fn(*args,**kwargs)
            return wrapper
        return deco

    @app.before_request
    def enforce_auth():
        p=request.path
        if not p.startswith('/api/') or p in ('/api/health','/api/auth/status','/api/auth/bootstrap','/api/auth/login'):
            return
        with connect() as c:
            u=who(c)
            if u is None:return out('ابتدا وارد برنامه شوید.',401)
            g.current_user={'id':u['id'],'name':u['name'],'role':u['role']}
            # Server-side permission check, including all old endpoints.
            perm='list'
            if p.startswith('/api/auth/'):
                return None
            if p.startswith('/api/users'):perm='users'
            elif p.startswith('/api/drivers'):perm='drivers'
            elif p.startswith('/api/manifests'):
                if p.endswith('/settlements') or '/settlements/' in p:perm='settle'
                elif request.method=='POST' and p.endswith('/receive'):perm='receive'
                elif request.method=='POST':perm='handover'
                else:perm='list'
            elif p.startswith('/api/scan'):perm='receive' if request.method=='POST' else 'list'
            elif p.startswith('/api/sync'):
                perm='settings' if request.method=='POST' else 'list'
            elif p.startswith('/api/reports') or p.startswith('/api/report-employees'):perm='reports'
            elif p.startswith('/api/backup'):perm='backup'
            elif p.startswith('/api/settings'):
                perm='list' if request.method=='GET' else 'settings'
            elif p.startswith('/api/print-settings'):perm='settings'
            elif p.startswith('/api/import') or p.endswith('/receive') or p.endswith('/deliver'):perm='receive'
            elif p=='/api/waybills' and request.method=='POST':perm='issue'
            elif p.startswith('/api/waybills') or p.startswith('/api/qr/') or p.startswith('/api/barcode/'):perm='list'
            if not require(c,perm):return out('دسترسی به این بخش مجاز نیست.',403)
            if request.method not in ('GET','HEAD','OPTIONS'):
                csrf=request.headers.get('X-CSRF-Token','')
                if not csrf or not hmac.compare_digest(csrf,session.get('csrf','')):
                    return out('توکن امنیتی درخواست نامعتبر است.',403)

    @app.get('/api/auth/status')
    def auth_status():
        with connect() as c:
            count=c.execute('SELECT COUNT(*) FROM users').fetchone()[0]
            u=who(c)
            print_settings=settings_get(c,'print_settings',{}) if u else {}
            user_permissions=sorted(permissions(c)) if u else []
        return jsonify(print_settings=print_settings,needs_setup=(count==0),authenticated=bool(u),user=(dict(id=u['id'],name=u['name'],role=u['role']) if u else None),
                       permissions=user_permissions,csrf=session.get('csrf') if u else None)

    @app.post('/api/auth/bootstrap')
    def bootstrap():
        d=request.get_json(silent=True) or {}
        name=str(d.get('name','')).strip()[:120];mobile=normalize_mobile(d.get('mobile'));pwd=str(d.get('password',''))
        if not name or len(mobile)!=11 or not mobile.startswith('09') or len(pwd)<10:return out('نام، موبایل معتبر و رمز حداقل ده کاراکتری لازم است.')
        with connect() as c:
            c.execute('BEGIN IMMEDIATE')
            if c.execute('SELECT 1 FROM users LIMIT 1').fetchone():return out('مدیر سیستم قبلاً تعریف شده است.',409)
            uid='U-'+uuid.uuid4().hex[:12]
            c.execute('INSERT INTO users(id,name,mobile,password_hash,role,created_at) VALUES(?,?,?,?,?,?)',
                      (uid,name,mobile,password_hash(pwd),'admin',now()))
            audit(c,'BOOTSTRAP',uid)
            c.commit()
        session.clear();session['uid']=uid;session['csrf']=secrets.token_urlsafe(32)
        return jsonify(ok=True)

    @app.post('/api/auth/login')
    def login():
        d=request.get_json(silent=True) or {}
        mobile=normalize_mobile(d.get('mobile'));pwd=str(d.get('password',''))
        with _login_lock:
            t=time.monotonic();attempts=[x for x in _login_attempts.get(mobile,[]) if t-x<600]
            if len(attempts)>=7:return out('تلاش‌های ورود زیاد است؛ ده دقیقه بعد دوباره امتحان کنید.',429)
            _login_attempts[mobile]=attempts
        with connect() as c:u=c.execute('SELECT * FROM users WHERE mobile=? AND enabled=1',(mobile,)).fetchone()
        if not u or not check_password(pwd,u['password_hash']):
            with _login_lock:_login_attempts.setdefault(mobile,[]).append(time.monotonic())
            return out('شماره موبایل یا رمز عبور اشتباه است.',401)
        with _login_lock:_login_attempts.pop(mobile,None)
        session.clear();session['uid']=u['id'];session['csrf']=secrets.token_urlsafe(32)
        return jsonify(ok=True)

    @app.post('/api/auth/logout')
    def logout():session.clear();return jsonify(ok=True)

    @app.get('/api/users')
    @protected('users')
    def users():
        with connect() as c:rows=c.execute('SELECT id,name,mobile,role,enabled,permissions_json FROM users ORDER BY created_at').fetchall()
        items=[]
        for x in rows:
            d=dict(x);raw=d.pop('permissions_json');d['custom']=raw is not None
            d['permissions']=sorted(json.loads(raw) if raw is not None else ROLE_PERMS[d['role']]);items.append(d)
        return jsonify(items=items,roles=ROLES,role_permissions={k:sorted(v) for k,v in ROLE_PERMS.items()})

    @app.post('/api/users')
    @protected('users')
    def add_user():
        d=request.get_json(silent=True) or {};name=str(d.get('name','')).strip()[:120]
        mobile=normalize_mobile(d.get('mobile'));role=str(d.get('role',''));pwd=str(d.get('password',''))
        if not name or len(mobile)!=11 or not mobile.startswith('09') or role not in ROLE_PERMS or len(pwd)<10:
            return out('نام، شماره موبایل، نقش و رمز حداقل ده کاراکتری لازم است.')
        perms=d.get('permissions',None)
        if perms is not None and (not isinstance(perms,list) or any(x not in PERMISSIONS for x in perms)):
            return out('دسترسی‌های انتخابی نامعتبر هستند.')
        encoded=json.dumps(sorted(set(perms))) if perms is not None and role!='admin' else None
        uid='U-'+uuid.uuid4().hex[:12]
        try:
            with connect() as c:
                c.execute('INSERT INTO users(id,name,mobile,password_hash,role,permissions_json,created_at) VALUES(?,?,?,?,?,?,?)',
                          (uid,name,mobile,password_hash(pwd),role,encoded,now()))
                audit(c,'USER_ADD',uid,{'role':role});c.commit()
        except sqlite3.IntegrityError:return out('شماره موبایل قبلاً ثبت شده است.',409)
        return jsonify(ok=True,id=uid),201

    @app.post('/api/users/<uid>/change')
    @protected('users')
    def change_user(uid):
        d=request.get_json(silent=True) or {};role=str(d.get('role',''));enabled=bool(d.get('enabled',True));pwd=str(d.get('password',''))
        if role not in ROLE_PERMS:return out('نقش نامعتبر است.')
        if pwd and len(pwd)<10:return out('رمز جدید حداقل ده کاراکتر باشد.')
        custom=d.get('permissions',None)
        if custom is not None and (not isinstance(custom,list) or any(x not in PERMISSIONS for x in custom)):
            return out('سطح دسترسی نامعتبر است.')
        with connect() as c:
            c.execute('BEGIN IMMEDIATE')
            row=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()
            if row is None:return out('کاربر پیدا نشد.',404)
            if row['role']=='admin' and (role!='admin' or not enabled):
                if c.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND enabled=1").fetchone()[0]<=1:
                    return out('آخرین مدیر فعال را نمی‌توان غیرفعال کرد.',409)
            if uid==session.get('uid') and not enabled:return out('نمی‌توان حساب فعلی را غیرفعال کرد.',409)
            encoded=json.dumps(sorted(set(custom))) if custom is not None and role!='admin' else None
            c.execute('UPDATE users SET role=?,enabled=?,permissions_json=? WHERE id=?',(role,int(enabled),encoded,uid))
            if pwd:c.execute('UPDATE users SET password_hash=? WHERE id=?',(password_hash(pwd),uid))
            audit(c,'USER_CHANGE',uid,{'role':role,'enabled':enabled});c.commit()
        return jsonify(ok=True)

    @app.get('/api/drivers')
    @protected('drivers')
    def drivers():
        with connect() as c:r=c.execute('SELECT id,first_name,last_name,mobile,enabled FROM drivers ORDER BY first_name,last_name').fetchall()
        return jsonify(items=[dict(x) for x in r])

    @app.post('/api/drivers')
    @protected('drivers')
    def add_driver():
        d=request.get_json(silent=True) or {};first=str(d.get('first_name','')).strip()[:90];last=str(d.get('last_name','')).strip()[:90];mobile=normalize_mobile(d.get('mobile'))
        if not first or not last or len(mobile)!=11 or not mobile.startswith('09'):return out('نام، نام خانوادگی و موبایل معتبر لازم است.')
        ident='D-'+uuid.uuid4().hex[:12]
        try:
            with connect() as c:
                c.execute('INSERT INTO drivers(id,first_name,last_name,mobile,created_at) VALUES(?,?,?,?,?)',(ident,first,last,mobile,now()))
                audit(c,'DRIVER_ADD',ident);c.commit()
        except sqlite3.IntegrityError:return out('راننده‌ای با این موبایل قبلاً ثبت شده است.',409)
        return jsonify(ok=True,id=ident),201

    def get_manifest(c,m):
        r=c.execute('''SELECT m.*,d.first_name,d.last_name,d.mobile FROM manifests m
                       JOIN drivers d ON d.id=m.driver_id WHERE m.id=?''',(m,)).fetchone()
        if r is None:return None
        b=[bill(x) for x in c.execute('''SELECT w.* FROM manifest_bills mb JOIN waybills w ON w.id=mb.waybill_id
                                         WHERE mb.manifest_id=? ORDER BY w.number''',(m,)).fetchall()]
        origin=sum(x['prepaid'] for x in b)//2;dest=sum(x['post_fare'] for x in b)//2
        paid={'origin_cash':0,'origin_passenger':0,'dest_cash':0,'dest_passenger':0}
        for p in c.execute('SELECT side,cash,passenger FROM settlements WHERE manifest_id=?',(m,)):
            paid[p['side']+'_cash']+=p['cash'];paid[p['side']+'_passenger']+=p['passenger']
        return dict(**dict(r),bills=b,waybill_count=len(b),piece_count=sum(x['pieces'] for x in b),
                    origin_share=origin,dest_share=dest,paid=paid,
                    origin_remaining=origin-paid['origin_cash']-paid['origin_passenger'],
                    dest_remaining=dest-paid['dest_cash']-paid['dest_passenger'])

    @app.get('/api/manifests')
    @protected('list')
    def manifests():
        with connect() as c:
            ids=[x['id'] for x in c.execute('SELECT id FROM manifests ORDER BY created_at DESC LIMIT 200').fetchall()]
            items=[get_manifest(c,k) for k in ids]
        return jsonify(items=items)

    @app.get('/api/manifests/<mid>')
    @protected('list')
    def manifest_detail(mid):
        with connect() as c:m=get_manifest(c,mid)
        return jsonify(manifest=m) if m else out('محموله پیدا نشد.',404)

    @app.post('/api/manifests')
    @protected('handover')
    def new_manifest():
        d=request.get_json(silent=True) or {};driver=str(d.get('driver_id',''));dest=str(d.get('destination','')).strip()[:180]
        ids=list(dict.fromkeys(str(x) for x in (d.get('waybill_ids') or [])))
        if not ids or len(ids)>400 or not dest:return out('مقصد و حداقل یک بارنامه لازم است.')
        with connect() as c:
            c.execute('BEGIN IMMEDIATE')
            if not c.execute('SELECT 1 FROM drivers WHERE id=? AND enabled=1',(driver,)).fetchone():return out('راننده معتبر نیست.',404)
            placeholders=','.join('?' for _ in ids)
            rows=c.execute('SELECT * FROM waybills WHERE id IN ('+placeholders+')',ids).fetchall()
            if len(rows)!=len(ids) or any(x['destination']!=dest or x['received_at'] is not None or x['manifest_id'] for x in rows):
                return out('بعضی بارنامه‌ها موجود نیستند، مقصد متفاوت دارند یا قبلاً تحویل شده‌اند.',409)
            if any(x['prepaid']%2 or x['post_fare']%2 for x in rows):return out('کرایه باید زوج باشد تا سهم پنجاه درصدی دقیق محاسبه شود.',409)
            mid='M-'+uuid.uuid4().hex[:14]
            number=c.execute('SELECT COALESCE(MAX(number),0)+1 FROM manifests').fetchone()[0]
            c.execute('INSERT INTO manifests(id,number,driver_id,destination,created_at,created_by) VALUES(?,?,?,?,?,?)',
                      (mid,number,driver,dest,now(),session.get('uid')))
            for wid in ids:
                c.execute('INSERT INTO manifest_bills(manifest_id,waybill_id) VALUES(?,?)',(mid,wid))
                c.execute('UPDATE waybills SET manifest_id=? WHERE id=?',(mid,wid))
            audit(c,'HANDOVER',mid,{'bill_ids':ids,'driver_id':driver})
            sync_engine.queue_manifest(c,mid)
            c.commit()
            result=get_manifest(c,mid)
        return jsonify(manifest=result),201

    def lookup_code(c,code):
        code=str(code or '').strip()
        if code.startswith('VHD1:'):
            # use existing decoder after checking the embedded id
            try:wid=decode_qr(code)['id']
            except Exception:return None
            return c.execute('SELECT * FROM waybills WHERE id=?',(wid,)).fetchone()
        numeric=normalize_mobile(code.replace('*',''))
        if code.startswith('VH-'):return c.execute('SELECT * FROM waybills WHERE id=?',(code,)).fetchone()
        if numeric:
            matches=c.execute('''SELECT * FROM waybills WHERE CAST(number AS TEXT)=?
              OR CAST(source_number AS TEXT)=? LIMIT 2''',(numeric,numeric)).fetchall()
            return matches[0] if len(matches)==1 else None
        return None

    @app.post('/api/scan/lookup')
    @protected('list')
    def scan_lookup():
        d=request.get_json(silent=True) or {}
        with connect() as c:r=lookup_code(c,d.get('code',''))
        return jsonify(waybill=bill(r)) if r else out('بارنامه پیدا نشد.',404)

    @app.post('/api/scan/receive')
    @protected('receive')
    def scan_receive():
        d=request.get_json(silent=True) or {}
        with connect() as c:
            c.execute('BEGIN IMMEDIATE')
            r=lookup_code(c,d.get('code',''))
            if r is None and str(d.get('code','')).startswith('VHD1:'):
                try:
                    branch=sync_engine.load_config(data_path())['branch_name']
                    r,fresh=sync_engine.provisional_receive(c,str(d['code']),decode_qr,branch)
                except Exception as exc:return out(str(exc),422)
                audit(c,'RECEIVE_PROVISIONAL',r['id'],{'verified':False})
                c.commit()
                return jsonify(ok=True,duplicate=not fresh,provisional=True,waybill=bill(r))
            if r is None:return out('بارنامه پیدا نشد.',404)
            if r['received_at'] is not None:return jsonify(ok=True,duplicate=True,provisional=bool(r['pending_verification']),waybill=bill(r))
            if not r['manifest_id']:return out('بارنامه هنوز به راننده تحویل نشده است.',409)
            c.execute('UPDATE waybills SET received_at=? WHERE id=?',(now(),r['id']))
            left=c.execute('''SELECT COUNT(*) FROM manifest_bills mb JOIN waybills w ON w.id=mb.waybill_id
                         WHERE mb.manifest_id=? AND w.received_at IS NULL''',(r['manifest_id'],)).fetchone()[0]
            if not left:c.execute('UPDATE manifests SET received_at=?,received_by=? WHERE id=? AND received_at IS NULL',(now(),session.get('uid'),r['manifest_id']))
            audit(c,'RECEIVE_SCAN',r['id'],{'manifest_id':r['manifest_id']})
            if r['origin_here']==0 and not r['pending_verification']:
                updated=c.execute('SELECT * FROM waybills WHERE id=?',(r['id'],)).fetchone()
                sync_engine.queue_received(c,updated,updated['received_at'])
            c.commit()
            updated=c.execute('SELECT * FROM waybills WHERE id=?',(r['id'],)).fetchone()
        return jsonify(ok=True,duplicate=False,waybill=bill(updated))

    @app.post('/api/manifests/<mid>/settlements')
    @protected('settle')
    def settle(mid):
        d=request.get_json(silent=True) or {};side=str(d.get('side',''))
        if side not in ('origin','dest'):return out('طرف تسویه معتبر نیست.')
        cash=parse_amount(d.get('cash'));passenger=parse_amount(d.get('passenger'))
        if cash+passenger<=0:return out('حداقل یک مبلغ تسویه وارد کنید.')
        with connect() as c:
            c.execute('BEGIN IMMEDIATE')
            m=get_manifest(c,mid)
            if not m:return out('محموله پیدا نشد.',404)
            remaining=m['origin_remaining' if side=='origin' else 'dest_remaining']
            if cash+passenger>remaining:return out('مبلغ پرداخت بیش از مانده سهم راننده است.',409)
            ident='S-'+uuid.uuid4().hex[:14]
            c.execute('INSERT INTO settlements(id,manifest_id,side,cash,passenger,created_at,created_by) VALUES(?,?,?,?,?,?,?)',
                      (ident,mid,side,cash,passenger,now(),session.get('uid')))
            audit(c,'SETTLE',mid,{'side':side,'cash':cash,'passenger':passenger})
            branch=sync_engine.load_config(data_path())['branch_name']
            dest=m['destination']
            target=(dest if branch!=dest else (m['bills'][0]['origin'] if m['bills'] else branch))
            sync_engine.queue_settlement(c,ident,target)
            c.commit()
            m=get_manifest(c,mid)
        return jsonify(manifest=m),201

    @app.get('/api/print-settings')
    @protected('settings')
    def get_print_settings():
        with connect() as c:v=settings_get(c,'print_settings',{})
        return jsonify(**v)

    @app.post('/api/print-settings')
    @protected('settings')
    def set_print_settings():
        d=request.get_json(silent=True) or {};v={k:bool(d.get(k,False)) for k in ('on_issue','on_handover','on_receive')}
        with connect() as c:
            c.execute('INSERT OR REPLACE INTO settings(name,value) VALUES(?,?)',('print_settings',json.dumps(v)))
            audit(c,'PRINT_SETTINGS','',v);c.commit()
        return jsonify(**v)

    def _jalali_to_gregorian(text,tz):
        value=str(text or '').translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩','01234567890123456789')).strip()
        match=re.fullmatch(r'(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})',value)
        if not match:raise ValueError('تاریخ شمسی را به صورت ۱۴۰۵/۰۸/۱۷ وارد کنید.')
        y,m,d=(int(v) for v in match.groups())
        if not 1300<=y<=1600 or not 1<=m<=12 or not 1<=d<=31:
            raise ValueError('تاریخ شمسی معتبر نیست.')
        newyear=None
        for off in range(9):
            candidate=dt.date(y+621,3,17)+dt.timedelta(days=off)
            millis=int(dt.datetime.combine(candidate,dt.time(12),tzinfo=tz).timestamp()*1000)
            if local_date(millis)[:3]==(y,1,1):newyear=candidate;break
        if newyear is None:raise ValueError('سال شمسی پشتیبانی نمی‌شود.')
        days=((m-1)*31 if m<=6 else 186+(m-7)*30)+d-1
        chosen=newyear+dt.timedelta(days=days)
        millis=int(dt.datetime.combine(chosen,dt.time(12),tzinfo=tz).timestamp()*1000)
        if local_date(millis)[:3]!=(y,m,d):raise ValueError('این روز در تقویم شمسی وجود ندارد.')
        return chosen,f'{y:04}/{m:02}/{d:02}'

    def _build_report(force_items=False):
        mode=request.args.get('mode','today')
        if mode not in ('all','today','date','range'):return out('فیلتر گزارش نامعتبر است.')
        include_items=force_items or request.args.get('include_items','0')=='1'
        employee_id=str(request.args.get('employee_id','')).strip()
        tz=dt.timezone(dt.timedelta(hours=3,minutes=30))
        today_local=dt.datetime.now(tz).date()
        jy,jm,jd=local_date(int(dt.datetime.combine(today_local,dt.time(12),tzinfo=tz).timestamp()*1000))[:3]
        today_jalali=f'{jy:04}/{jm:02}/{jd:02}'
        try:
            if mode=='date':
                first,first_fa=_jalali_to_gregorian(request.args.get('date',''),tz)
                last,last_fa=first,first_fa
            elif mode=='range':
                first,first_fa=_jalali_to_gregorian(request.args.get('from_date',''),tz)
                last,last_fa=_jalali_to_gregorian(request.args.get('to_date',''),tz)
                if first>last:raise ValueError('تاریخ پایان نباید قبل از تاریخ شروع باشد.')
            elif mode=='all':
                first=last=None
                first_fa=last_fa=''
            else:
                first=last=today_local
                first_fa=last_fa=today_jalali
            t1=dt.time.fromisoformat(request.args.get('from','00:00'))
            t2=dt.time.fromisoformat(request.args.get('to','23:59'))
            if first==last and t1>t2 and mode!='all':raise ValueError('ساعت پایان قبل از شروع است.')
            if first is not None:
                low=int(dt.datetime.combine(first,t1,tzinfo=tz).timestamp()*1000)
                high=int(dt.datetime.combine(last,t2,tzinfo=tz).timestamp()*1000)+59999
            else:low=high=None
        except (ValueError,OverflowError) as exc:
            return out(str(exc) or 'تاریخ یا ساعت نامعتبر است.')
        with connect() as c:
            employee_name='همه کارمندان'
            if employee_id:
                if employee_id=='unassigned':employee_name='کارمند ثبت‌نشده (بارنامه‌های قدیمی)'
                else:
                    record=c.execute('SELECT name FROM users WHERE id=?',(employee_id,)).fetchone()
                    if record is None:return out('کارمند انتخاب‌شده یافت نشد.',400)
                    employee_name=record['name']
            where=['w.origin_here=1'];params=[]
            if low is not None:where.append('w.created_at BETWEEN ? AND ?');params.extend([low,high])
            if employee_id=='unassigned':where.append("(w.created_by IS NULL OR w.created_by='')")
            elif employee_id:where.append('w.created_by=?');params.append(employee_id)
            rows=c.execute("SELECT w.*,COALESCE(u.name,'کارمند ثبت‌نشده') AS issuer_name FROM waybills w LEFT JOIN users u ON u.id=w.created_by WHERE "+' AND '.join(where)+' ORDER BY w.created_at,w.id',params).fetchall()
            operations_where=''
            if employee_id=='unassigned':operations_where=" AND (created_by IS NULL OR created_by='')"
            elif employee_id:operations_where=' AND created_by=?'
            args=[employee_id] if employee_id and employee_id!='unassigned' else []
            manifests=c.execute('SELECT * FROM manifests WHERE 1=1'+operations_where,args).fetchall()
            settlements=c.execute('SELECT * FROM settlements WHERE 1=1'+operations_where,args).fetchall()
            if employee_id:
                rx=(" AND (received_by IS NULL OR received_by='')" if employee_id=='unassigned' else ' AND received_by=?')
                received=c.execute('SELECT received_at FROM manifests WHERE received_at IS NOT NULL'+rx,args).fetchall()
            else:received=c.execute('SELECT received_at FROM manifests WHERE received_at IS NOT NULL').fetchall()
        numeric_fields=('prepaid','post_fare','storage_fee','other_fee','total')
        totals={key:sum(int(row[key]) for row in rows) for key in numeric_fields}
        fare=totals['prepaid']+totals['post_fare']
        driver_share=sum((int(row['prepaid'])+int(row['post_fare']))//2 for row in rows)
        totals.update(issued=len(rows),fare=fare,driver_share=driver_share,company_share=fare-driver_share)
        hourly={}
        for row in rows:
            row_date=dt.datetime.fromtimestamp(row['created_at']/1000,tz)
            hour=row_date.strftime('%H:00')
            if mode=='range':
                y,m,d=local_date(row['created_at'])[:3]
                hour=f'{y:04}/{m:02}/{d:02} {hour}'
            h=hourly.setdefault(hour,dict(hour=hour,issued=0,prepaid=0,post_fare=0,storage_fee=0,other_fee=0,total=0))
            h['issued']+=1
            for key in numeric_fields:h[key]+=int(row[key])
        def inside(timestamp):return timestamp is not None and (low is None or low<=timestamp<=high)
        totals['handover_count']=sum(1 for x in manifests if inside(x['created_at']))
        totals['received_manifests']=sum(1 for x in received if inside(x['received_at']))
        totals['settled_cash']=sum(int(x['cash']) for x in settlements if inside(x['created_at']))
        totals['settled_passenger']=sum(int(x['passenger']) for x in settlements if inside(x['created_at']))
        result=dict(totals=totals,hourly=sorted(hourly.values(),key=lambda x:x['hour']),
            date_jalali=first_fa or today_jalali,from_date_jalali=first_fa,to_date_jalali=last_fa,
            today_jalali=today_jalali,mode=mode,time_from=t1.strftime('%H:%M'),time_to=t2.strftime('%H:%M'),
            employee_id=employee_id,employee_name=employee_name)
        if include_items:
            items=[]
            for row in rows:
                pre=int(row['prepaid']);post=int(row['post_fare']);driver=(pre+post)//2
                items.append(dict(number=row['number'],created_at_fa=shamsi(row['created_at']),
                    origin=row['origin'],destination=row['destination'],sender=row['sender'],receiver=row['receiver'],
                    pieces=row['pieces'],prepaid=pre,post_fare=post,storage_fee=row['storage_fee'],
                    other_fee=row['other_fee'],driver_share=driver,company_share=pre+post-driver,
                    total=row['total'],created_by_name=row['issuer_name']))
            result['items']=items
            result['branch_name']=sync_engine.load_config(data_path()).get('branch_name','')
            result['generated_at_fa']=shamsi(now())
            result['generated_by']=(getattr(g,'current_user',{}) or {}).get('name','')
            result['report_scope']='بارنامه‌های صادرشده در این شعبه؛ مبلغ‌های ثبت‌شده، نه لزوماً وجه وصول‌شده'
        return result

    @app.get('/api/report-employees')
    @protected('reports')
    def report_employees():
        with connect() as c:
            rows=c.execute('SELECT id,name,enabled FROM users ORDER BY name,id').fetchall()
        return jsonify(items=[dict(r) for r in rows])

    @app.get('/api/reports-v2')
    @protected('reports')
    def reports_v2():
        data=_build_report()
        return data if isinstance(data,tuple) else jsonify(**data)

    @app.get('/api/reports/export.xlsx')
    @protected('reports')
    def export_financial_report():
        # Shared source of truth with on-screen and printable reports.
        # Never trust the client to provide totals or rows.
        data=_build_report(force_items=True)
        if isinstance(data,tuple):return data
        binary=report_excel.build_xlsx(data)
        name='Vahdat-Financial-'+(data['from_date_jalali'] or 'All').replace('/','-')+'.xlsx'
        return send_file(io.BytesIO(binary),as_attachment=True,download_name=name,
          mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
