@echo off
chcp 65001 >nul
pushd "%~dp0windows"
where py >nul 2>nul
if not errorlevel 1 (
  py -3.11 -m unittest test_sync test_branches_155 -v
) else (
  python -m unittest test_sync test_branches_155 -v
)
popd
pause
