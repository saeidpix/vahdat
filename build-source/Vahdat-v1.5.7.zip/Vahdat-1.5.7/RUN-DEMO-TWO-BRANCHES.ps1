# Windows PowerShell 5.1; development/test PC ONLY. Does not touch real cPanel or ticket SQL Server.
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$py=Join-Path $root '.venv\Scripts\python.exe'
if(-not (Test-Path $py)) { throw 'First run START-WINDOWS.bat once to create the Python environment and install dependencies.' }
& $py (Join-Path $root 'tools\prepare_demo.py')
if($LASTEXITCODE -ne 0){throw 'Demo setup failed'}
$data=Join-Path $root 'tools\demo-data'
$hubArgs='"'+(Join-Path $root 'tools\central_demo.py')+'" --db "'+(Join-Path $data 'hub.sqlite3')+'" --port 18885 --tehran-token alpha-key-long-enough-for-testing-123456789 --destination-token beta-key-long-enough-for-testing-123456789'
$hub=Start-Process -FilePath $py -WorkingDirectory $root -ArgumentList $hubArgs -PassThru
Start-Sleep -Seconds 1
$oldData=$env:PROGRAMDATA;$oldPort=$env:VAHDAT_PORT
try {
    $env:PROGRAMDATA=Join-Path $data 'tehran';$env:VAHDAT_PORT='8765'
    $tehran=Start-Process -FilePath $py -WorkingDirectory $root -ArgumentList ('"'+(Join-Path $root 'windows\app.py')+'"') -PassThru
    $env:PROGRAMDATA=Join-Path $data 'destination';$env:VAHDAT_PORT='8766'
    $dest=Start-Process -FilePath $py -WorkingDirectory $root -ArgumentList ('"'+(Join-Path $root 'windows\app.py')+'"') -PassThru
} finally { $env:PROGRAMDATA=$oldData;$env:VAHDAT_PORT=$oldPort }
Write-Host 'Demo Tehran: http://127.0.0.1:8765' -ForegroundColor Green
Write-Host 'Demo Destination: http://127.0.0.1:8766' -ForegroundColor Green
Write-Host 'Hub: local HTTP test simulator on 127.0.0.1:18885 (not for production)' -ForegroundColor Yellow
Write-Host ('Process IDs: hub='+$hub.Id+' tehran='+$tehran.Id+' destination='+$dest.Id)
Write-Host 'To simulate disconnection, stop ONLY the hub PID; the branch apps remain operational.'
Write-Host 'This script does NOT modify the real Windows Server 2019 machines.'
