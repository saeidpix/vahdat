<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('vahdat_sync_waybill_tracking', function (Blueprint $table) {
            $table->string('waybill_id', 90)->primary();
            $table->string('origin_branch_id', 48);
            $table->string('destination_branch_id', 48);
            $table->string('status', 24)->default('issued');
            $table->boolean('verified_origin')->default(false);
            $table->string('manifest_id', 90)->nullable();
            $table->string('driver_name', 180)->nullable();
            $table->unsignedBigInteger('issued_at')->nullable();
            $table->unsignedBigInteger('handover_at')->nullable();
            $table->unsignedBigInteger('received_at')->nullable();
            $table->unsignedBigInteger('delivered_at')->nullable();
            $table->timestamps();
            $table->index(['origin_branch_id', 'issued_at'], 'vahdat_tracking_origin_date');
            $table->index(['destination_branch_id', 'status'], 'vahdat_tracking_dest_status');
            $table->index(['destination_branch_id', 'received_at'], 'vahdat_tracking_dest_received');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('vahdat_sync_waybill_tracking');
    }
};
