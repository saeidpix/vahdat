# -*- coding: utf-8 -*-
"""Dependency-free and spreadsheet-safe XLSX export for a filtered financial snapshot.

All user-supplied values are inline strings, never Excel formulas. Only our own
SUM expressions are formulas; sums use the same already-filtered source rows.
"""
import io
import re
import zipfile
from xml.sax.saxutils import escape

MIME='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
PACK='http://schemas.openxmlformats.org/package/2006/relationships'

def clean(value):
    s=str('' if value is None else value)
    return ''.join(ch for ch in s if ch=='\t' or ch=='\n' or ch=='\r' or ord(ch)>=32)

def text_cell(col,row,value,style=0):
    val=escape(clean(value))
    return f'<c r="{col}{row}" s="{style}" t="inlineStr"><is><t xml:space="preserve">{val}</t></is></c>'

def num_cell(col,row,value,style=2,formula=None):
    n=int(value or 0)
    f=f'<f>{escape(formula)}</f>' if formula else ''
    return f'<c r="{col}{row}" s="{style}">{f}<v>{n}</v></c>'

def column_letter(number):
    letters=''
    while number:
        number,rem=divmod(number-1,26)
        letters=chr(65+rem)+letters
    return letters

def sheet_xml(rows,widths,header_row=None,freeze_rows=0,auto_filter=None,landscape=False):
    maxcol=max((len(r) for r in rows),default=1)
    height=len(rows)
    views=f'<sheetViews><sheetView workbookViewId="0" rightToLeft="1">'
    if freeze_rows:views+=f'<pane ySplit="{freeze_rows}" topLeftCell="A{freeze_rows+1}" activePane="bottomLeft" state="frozen"/>'
    views+='</sheetView></sheetViews>'
    cols='<cols>'+''.join(f'<col min="{i}" max="{i}" width="{width}" customWidth="1"/>' for i,width in enumerate(widths,1))+'</cols>'
    bits=[]
    for ridx,items in enumerate(rows,1):
        cells=[]
        for ci,item in enumerate(items,1):
            col=column_letter(ci)
            value,style,formula=item if isinstance(item,tuple) else (item,0,None)
            if isinstance(value,(int,float)) and not isinstance(value,bool):cells.append(num_cell(col,ridx,value,style or 2,formula))
            else:cells.append(text_cell(col,ridx,value,style))
        bits.append(f'<row r="{ridx}"'+(f' ht="25" customHeight="1"' if header_row==ridx else '')+'>'+''.join(cells)+'</row>')
    dim=f'A1:{column_letter(maxcol)}{height or 1}'
    x=f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="{NS}"><dimension ref="{dim}"/>{views}{cols}<sheetData>{"".join(bits)}</sheetData>'
    if auto_filter:x+=f'<autoFilter ref="{auto_filter}"/>'
    x+='<pageMargins left="0.25" right="0.25" top="0.4" bottom="0.4" header="0.2" footer="0.2"/>'
    x+='<pageSetup orientation="'+('landscape' if landscape else 'portrait')+'" paperSize="9" fitToWidth="1" fitToHeight="0"/>'
    x+='</worksheet>'
    return x.encode('utf-8')

def row(*items):return list(items)

def build_xlsx(report):
    t=report['totals'];items=report.get('items',[])
    date_label=('تمام تاریخ‌ها' if report['mode']=='all' else
        (report['from_date_jalali']+' تا '+report['to_date_jalali'] if report['mode']=='range' else report['date_jalali']))
    period=date_label if report['mode']=='all' else date_label+' | '+report['time_from']+' تا '+report['time_to']+' به وقت تهران'
    meta=[row('اتوبنز وحدت — گزارش مالی'),row('شعبه',report.get('branch_name','')),
          row('دوره گزارش',period),row('فیلتر کارمند',report.get('employee_name','همه کارمندان')),
          row('تهیه‌کننده',report.get('generated_by','')),row('زمان تهیه',report.get('generated_at_fa','')),
          row('مبنای گزارش','صدور بارنامه؛ مبالغ ثبت‌شده لزوماً وجه وصول‌شده نیستند'),row('', ''),
          row('عنوان','مقدار (تومان، مگر تعداد)')]
    for label,key in [('بارنامه صادرشده','issued'),('جمع مبلغ بارنامه‌ها','total'),('اصل کرایه','fare'),
                      ('پیش‌کرایه','prepaid'),('پس‌کرایه','post_fare'),('انبارداری','storage_fee'),
                      ('سایر هزینه‌ها','other_fee'),('سهم راننده از اصل کرایه','driver_share'),
                      ('سهم شرکت از اصل کرایه','company_share'),('تحویل به راننده','handover_count'),
                      ('دریافت مقصد','received_manifests'),('تسویه نقدی راننده','settled_cash'),
                      ('تسویه از محل مسافر','settled_passenger')]:
        meta.append([(label,0,None),(t.get(key,0),2,None)])
    meta.append(row('توجه','کارمند صادرکننده بارنامه برای سوابق قدیمی ممکن است مشخص نباشد.'))
    details=[row('اتوبنز وحدت — ریز بارنامه‌ها'),row('شعبه',report.get('branch_name','')),
             row('دوره',period),row('کارمند',report.get('employee_name','همه کارمندان'))]
    columns=['ردیف','شماره بارنامه','تاریخ و ساعت صدور','مبدأ','مقصد','فرستنده','گیرنده','تعداد بسته',
             'پیش‌کرایه','پس‌کرایه','انبارداری','سایر هزینه‌ها','سهم راننده','سهم شرکت','جمع بارنامه','کارمند صادرکننده']
    details.append([(x,1,None) for x in columns])
    for i,x in enumerate(items,1):
        vals=[i,x.get('number') or 0,x.get('created_at_fa',''),x.get('origin',''),x.get('destination',''),
              x.get('sender',''),x.get('receiver',''),x.get('pieces',0),x.get('prepaid',0),
              x.get('post_fare',0),x.get('storage_fee',0),x.get('other_fee',0),
              x.get('driver_share',0),x.get('company_share',0),x.get('total',0),x.get('created_by_name','')]
        details.append([(v,2,None) if isinstance(v,(int,float)) else (v,0,None) for v in vals])
    first,last=6,5+len(items)
    footer=[]
    totals_by_column={8:'pieces',9:'prepaid',10:'post_fare',11:'storage_fee',12:'other_fee',13:'driver_share',14:'company_share',15:'total'}
    for i in range(1,len(columns)+1):
        if i==1:footer.append(('جمع',3,None))
        elif i in totals_by_column:
            name=totals_by_column[i]
            cached=sum(int(x.get(name,0)) for x in items) if name=='pieces' else t.get(name,0)
            letter=column_letter(i)
            footer.append((int(cached),3,f'SUM({letter}{first}:{letter}{last})' if items else None))
        else:footer.append(('',3,None))
    details.append(footer)
    hours=[row('اتوبنز وحدت — گزارش ساعت صدور'),row('دوره',period),row('کارمند',report.get('employee_name','همه کارمندان')),
           row(''),[(v,1,None) for v in ('روز و ساعت تهران','تعداد بارنامه','پیش‌کرایه','پس‌کرایه','انبارداری','سایر هزینه‌ها','جمع بارنامه')]]
    for x in report.get('hourly',[]):hours.append([(x['hour'],0,None)]+[(int(x.get(k,0)),2,None) for k in ('issued','prepaid','post_fare','storage_fee','other_fee','total')])
    if not report.get('hourly'):hours.append(row('در این بازه بارنامه‌ای صادر نشده است.'))
    xml_parts=[sheet_xml(meta,[39,38],header_row=9),
               sheet_xml(details,[9,17,27,19,19,25,25,14,17,17,17,17,17,17,18,26],header_row=5,freeze_rows=5,auto_filter=f'A5:P{max(5,5+len(items))}',landscape=True),
               sheet_xml(hours,[26,18,20,20,20,20,23],header_row=5,freeze_rows=5,auto_filter=f'A5:G{max(5,len(hours))}')]
    styles=f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="{NS}">
    <fonts count="3"><font><sz val="11"/><name val="Tahoma"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Tahoma"/></font><font><b/><sz val="11"/><name val="Tahoma"/></font></fonts>
    <fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF19395A"/><bgColor indexed="64"/></patternFill></fill></fills>
    <borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
    <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
    <cellXfs count="5"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFill="1" applyFont="1"/><xf numFmtId="3" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="3" fontId="2" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0"/></cellXfs>
    <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'''
    workbook=f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="{NS}" xmlns:r="{REL}"><bookViews><workbookView/></bookViews><sheets><sheet name="خلاصه" sheetId="1" r:id="rId1"/><sheet name="ریز بارنامه‌ها" sheetId="2" r:id="rId2"/><sheet name="گزارش ساعتی" sheetId="3" r:id="rId3"/></sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>'''
    rels=f'''<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="{PACK}"><Relationship Id="rId1" Type="{REL}/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="{REL}/worksheet" Target="worksheets/sheet2.xml"/><Relationship Id="rId3" Type="{REL}/worksheet" Target="worksheets/sheet3.xml"/><Relationship Id="rId4" Type="{REL}/styles" Target="styles.xml"/></Relationships>'''
    root_rels=f'''<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="{PACK}"><Relationship Id="rId1" Type="{REL}/officeDocument" Target="xl/workbook.xml"/></Relationships>'''
    types='''<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'''+''.join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(1,4))+'</Types>'
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for n,b in {'[Content_Types].xml':types,'_rels/.rels':root_rels,'xl/workbook.xml':workbook,'xl/_rels/workbook.xml.rels':rels,'xl/styles.xml':styles,**{f'xl/worksheets/sheet{i}.xml':v for i,v in enumerate(xml_parts,1)}}.items():z.writestr(n,b)
    return out.getvalue()
